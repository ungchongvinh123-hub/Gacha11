package com.thieuhuoikynnguyen.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
