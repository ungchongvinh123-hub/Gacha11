# ART PIPELINE — Model nhân vật 2D toàn thân

> Mục tiêu: game gacha anime theo lượt. Art là **asset nhét vào sau cùng**,
> code đã chừa sẵn chỗ. Tài liệu này là hợp đồng giữa code và team art.

---

## 1. Có 2 loại ảnh cho 1 nhân vật

| Loại | Dùng ở đâu | Kích thước gợi ý | Định dạng |
|---|---|---|---|
| `art` (chân dung vuông) | Roster, gacha, đội hình, skill detail | 256×256 → 512×512 | PNG nền trong suốt, mặt + vai |
| `bodyArt` (toàn thân) | MÀN CHIẾN ĐẤU (model chính) | 512×768 (3:4) | PNG nền trong suốt, full-body |

Nếu chưa có `bodyArt`, game tự dùng `art` để vẽ trong trận (không vỡ).

### Quy ước file
```
public/sprites/characters/{id}.png   ← chân dung (đang dùng)
public/units/characters/{id}/body.png ← toàn thân (thay vào CHAR_BODY_ART trong src/game/art.ts)
public/sprites/enemies/{id}.png
public/units/enemies/{id}/body.png
```
**Chỉ sửa 1 dòng trong `src/game/art.ts`** là game dùng ảnh mới ở mọi màn hình — không đụng code khác.

---

## 2. Animation: chọn 1 trong 2 trường phái

### A) Frame-based (chuỗi ảnh) — như JRPG cổ điển
Mỗi trạng thái = 1 file (hoặc 1 sheet nhiều frame):

```
public/units/characters/{id}/idle_0.png   idle_1.png   idle_2.png     (2-4 frame)
                              attack_0..2  (vung đòn)
                              cast_0..2    (phép/buff)
                              hit_0.png    (lùi lại / nhăn mặt)
                              die_0.png    (ngã)
```

**Code đã sẵn:** engine phát event `action | dmg | dot | effect | died` theo đúng
thứ tự kể trên; component `UnitFigure` (src/components/UnitFigure.tsx) đã có khung
`hitCount`/`lungeCount` để cắm player frame vào (thay phần `<img>` hiện tại bằng
vòng lặp frame theo thời gian).

### B) Skeletal 2D (rig xương) — chuẩn gacha anime hiện đại
- **Spine** / **DragonBones**: rig cho nhân vật di chuyển trong trận, nhân vật
  vung kiếm, bị đẩy lùi, ngã — 1 bộ art + rig sinh ra MỌI animation.
- **Live2D**: chủ yếu cho chân dung đứng thoại / màn hình triệu hồi (tóc bay,
  mắt chớp, ngực thở).
- Lưu rig dạng `.skel/.json + atlas` trong `public/rigs/characters/{id}/`, rồi
  đổi component render bằng player lib (spine-web / pixi). **Engine chiến đấu
  không cần sửa** vì nó thuần logic.

> Gợi ý quy trình tối ưu cho waifu game: **Body = Spine rig** (battle),
> **Chân dung triệu hồi/roster = Live2D** — đúng chuẩn game gacha lớn.

---

## 3. Bảng trạng thái (state machine) đã có sẵn trong code

| Sự kiện engine | Trạng thái figure | Gợi ý animation |
|---|---|---|
| `{t:'phase'}` | idle | đứng hít thở, tóc/váy lay nhẹ |
| `{t:'action', kind:'attack'}` | attack | lao tới, vung tay/vũ khí |
| `{t:'action', kind:'skill'}` | cast | giơ tay, tụ khí theo màu hệ |
| `{t:'dmg'}` | hit | giật lùi, rung, flash trắng |
| `{t:'dot'}` + effect | hurt/burn/poison... | nhuốm màu overlay (lửa/độc) |
| `died` (hp=0) | die | ngã xuống, mờ dần |
| `{t:'effect'}` freeze/shock | stunned | đóng băng / co giật |

UnitFigure hiện tự chạy bản "CSS proxy": idle nhún, lao tới khi hành động,
rung + flash khi trúng đòn, xám mờ khi chết + overlay lửa/băng/độc/sét —
để bạn CẢM NHẬN được nhịp trận đấu ngay từ bây giờ.

---

## 4. Checklist khi thêm 1 nhân vật mới (bên code)
1. Thêm 1 dòng vào `src/game/data/characters.ts` (stats theo class/rarity).
2. Skill tree tự sinh 20 skill (deterministic) — không cần làm tay.
3. (Art) Thêm dòng `id: "/sprites/characters/id.png"` vào `CHAR_ART` trong `src/game/art.ts`.
4. (Art full-body) Thêm dòng vào `CHAR_BODY_ART` trỏ tới `body.png`.

## 5. Ngân sách art cho bản phát hành (gợi ý)
- 30 tướng × (1 chân dung + 1 body rig) — làm theo đợt, ưu tiên SSR → SR → R.
- ~14 loại quái + 3 boss.
- Nền chiến trường theo vùng (đang có 1 ảnh dùng chung).
- VFX skill (đạn phép, lửa, băng...) — layer sau cùng.
