# ĐÓNG GÓI APK MÀN HÌNH NGANG — HƯỚNG DẪN TỪNG BƯỚC

> Game chạy bằng **server + PostgreSQL** (tiến trình/tướng/trang bị không lưu local
> để chống hack). Vì vậy APK hoạt động theo 1 trong 2 chế độ dưới đây.

---

## CHẾ ĐỘ 1 — APK nạp từ backend đã deploy (KHÔNG làm được trong sandbox này)

Sandbox không có Java/Gradle/Android SDK nên **không thể sinh file .apk tại đây**.
Bạn phải build trên máy mình. Các bước:

### 1. Chuẩn bị backend có địa chỉ cố định
- Link preview e2b chỉ sống trong 1 lượt chat → **KHÔNG dùng được**.
- Deploy backend Next.js này lên nơi có URL ổn định (Vercel/Render/Fly + Postgres cloud), rồi mở file:

```
capacitor.config.ts  →  bỏ comment khối `server.url` và điền URL thật:
  server: { url: "https://ten-mien-cua-ban.com", cleartext: true }
```

### 2. Build web + đồng bộ vào project Android
```bash
# (tuỳ chọn) build web
npx cap sync android
```

### 3. Mở bằng Android Studio & build APK
```bash
# trên máy có Android Studio:
cd android
./gradlew assembleDebug
```
File APK nằm tại: `android/app/build/outputs/apk/debug/app-debug.apk`
- Cài vào máy: bật "Cài đặt từ nguồn không xác định", chạy `adb install app-debug.apk` hoặc kéo thả.
- Đã ép `screenOrientation="sensorLandscape"` trong `AndroidManifest.xml` → app **tự khóa ngang**.

---

## CHẾ ĐỘ 2 — APK chạy UI tĩnh offline (CHỈ xem giao diện, không chơi được trọn vẹn)

Nếu chỉ muốn test giao diện/hoạt ảnh ngoại tuyến:
```bash
npx cap sync android      # webDir hiện trỏ "out" — cần bản export tĩnh
```
> Lưu ý: bản export tĩnh không có API/DB → màn hình tải sẽ báo lỗi dữ liệu.
> Chế độ này chỉ hữu ích khi sau này tách UI demo thuần.

---

## TEST NHANH NGAY TRÊN ĐIỆN THOẠI (không cần APK)

Mở **preview** bằng Chrome/Safari trên điện thoại:
1. Mở link preview (https).
2. Xoay ngang — nếu đang dọc, game tự hiện màn hình **"Xoay ngang điện thoại"**.
3. Dùng tính năng "Thêm vào màn hình chính" (Add to Home Screen) → chạy toàn màn hình
   kiểu app (đã có `viewport-fit=cover` + safe-area để không đè notch).

---

## CẤU HÌNH ĐÃ SẴN TRONG DỰ ÁN

| Thành phần | Trạng thái |
|---|---|
| `android/` (Capacitor) | ✅ đã sinh, `screenOrientation="sensorLandscape"` |
| `capacitor.config.ts` | ✅ appId/name/landscape — chờ bạn điền `server.url` |
| Safe-area notch | ✅ CSS `env(safe-area-inset-*)` + `viewport-fit=cover` |
| Nhắc xoay ngang | ✅ overlay tự hiện khi cầm dọc trên mobile |
| Orientation app | Webview khóa `sensorLandscape` khi build APK |

---

## LƯU Ý KHI BUILD LẦN ĐẦU TRÊN MÁY BẠN
- Cài **Android Studio** (bản mới nhất) → SDK Platform 34+, Build Tools.
- `android/` đã có gradle wrapper — Android Studio tự tải phần còn lại.
- Nếu đổi `appId` sau khi phát hành lần đầu, phải đổi tên gói trước khi lên store.
