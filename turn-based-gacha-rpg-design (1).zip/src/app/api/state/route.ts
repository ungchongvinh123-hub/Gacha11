import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { players, characters, items } from "@/db/schema";
import { CHAR_MAP, STARTER_IDS } from "@/game/data/characters";
import { defaultLoadout } from "@/game/data/skills";
import type { CharacterInstance, GameState, ItemInstance } from "@/game/types";

export const dynamic = "force-dynamic";

async function ensurePlayer(): Promise<typeof players.$inferSelect> {
  const rows = await db.select().from(players).limit(1);
  if (rows.length > 0) return rows[0];

  const [p] = await db
    .insert(players)
    .values({ name: "Triệu Hồi Sư", gold: 2500, gems: 2000, team: [], cleared: [] })
    .returning();

  // starter pack: 1 tank, 1 attacker, 1 support + trang bị khởi đầu
  const starterCharIds: number[] = [];
  for (const defId of STARTER_IDS) {
    const def = CHAR_MAP.get(defId)!;
    const loadout = defaultLoadout(def);
    const skillLevels: Record<string, number> = {};
    for (const sid of loadout) skillLevels[sid] = 1;
    const [c] = await db
      .insert(characters)
      .values({ playerId: p.id, defId, level: 1, exp: 0, spentPoints: 0, skillLevels, loadout })
      .returning();
    starterCharIds.push(c.id);
  }

  const starterItems: [string, number][] = [
    ["w_tnk_r1", starterCharIds[0]],
    ["w_atk_r1", starterCharIds[1]],
    ["w_sup_r1", starterCharIds[2]],
    ["j_r1", starterCharIds[0]],
  ];
  for (const [defId, equippedBy] of starterItems) {
    await db.insert(items).values({ playerId: p.id, defId, equippedBy });
  }

  const [updated] = await db.update(players).set({ team: starterCharIds }).where(eq(players.id, p.id)).returning();
  return updated;
}

export async function GET() {
  try {
    const player = await ensurePlayer();
    const charRows = await db.select().from(characters).where(eq(characters.playerId, player.id));
    const itemRows = await db.select().from(items).where(eq(items.playerId, player.id));

    const state: GameState = {
      player: {
        id: player.id,
        name: player.name,
        gold: player.gold,
        gems: player.gems,
        team: player.team,
        cleared: player.cleared,
      },
      characters: charRows.map(
        (c): CharacterInstance => ({
          id: c.id,
          defId: c.defId,
          level: c.level,
          exp: c.exp,
          spentPoints: c.spentPoints,
          skillLevels: c.skillLevels ?? {},
          loadout: c.loadout ?? [],
        }),
      ),
      items: itemRows.map(
        (i): ItemInstance => ({ id: i.id, defId: i.defId, equippedBy: i.equippedBy, level: i.level }),
      ),
    };
    return NextResponse.json(state);
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "server error" }, { status: 500 });
  }
}
