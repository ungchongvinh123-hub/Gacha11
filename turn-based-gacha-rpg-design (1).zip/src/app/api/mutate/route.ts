import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { players, characters, items } from "@/db/schema";
import { CHAR_MAP, gachaPoolByRarity } from "@/game/data/characters";
import { ITEM_MAP, rollItemDefId } from "@/game/data/items";
import { STAGE_MAP } from "@/game/data/enemies";
import { defaultLoadout } from "@/game/data/skills";
import { pointsAvailable, skillLearnCost } from "@/game/engine/stats";
import { expForLevel, GACHA_COST, GACHA_RATES, MAX_LEVEL, MAX_LOADOUT, MAX_SKILL_LEVEL } from "@/game/types";
import type { Rarity } from "@/game/types";

export const dynamic = "force-dynamic";

function err(msg: string, status = 400) {
  return NextResponse.json({ error: msg }, { status });
}

async function getPlayer() {
  const rows = await db.select().from(players).limit(1);
  if (rows.length === 0) throw new Error("no player");
  return rows[0];
}

async function getChar(charId: number, playerId: number) {
  const rows = await db
    .select()
    .from(characters)
    .where(and(eq(characters.id, charId), eq(characters.playerId, playerId)))
    .limit(1);
  return rows[0] ?? null;
}

function pickRarity(rand: () => number): Rarity {
  const r = rand();
  if (r < GACHA_RATES.SSR) return "SSR";
  if (r < GACHA_RATES.SSR + GACHA_RATES.SR) return "SR";
  return "R";
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const type = String(body.type ?? "");
    const player = await getPlayer();

    // ============================== GACHA ==================================
    if (type === "gacha") {
      const count = body.count === 10 ? 10 : 1;
      const cost = GACHA_COST * count;
      if (player.gems < cost) return err(`Không đủ ngọc (cần ${cost})`);

      const pools = gachaPoolByRarity();
      const ownedCounts = new Map<string, number>();
      const existing = await db.select().from(characters).where(eq(characters.playerId, player.id));
      for (const c of existing) ownedCounts.set(c.defId, (ownedCounts.get(c.defId) ?? 0) + 1);

      const results: { defId: string; rarity: Rarity; isDupe: boolean; newId: number }[] = [];
      let gotSrPlus = false;
      const rarities: Rarity[] = [];
      for (let i = 0; i < count; i++) {
        const r = pickRarity(Math.random);
        if (r !== "R") gotSrPlus = true;
        rarities.push(r);
      }
      // bảo hiểm: mười lần chắc chắn có ít nhất 1 SR+
      if (count === 10 && !gotSrPlus) rarities[9] = "SR";

      for (const r of rarities) {
        const pool = pools[r];
        const def = pool[Math.floor(Math.random() * pool.length)];
        const loadout = defaultLoadout(def);
        const skillLevels: Record<string, number> = {};
        for (const sid of loadout) skillLevels[sid] = 1;
        const [c] = await db
          .insert(characters)
          .values({ playerId: player.id, defId: def.id, level: 1, exp: 0, spentPoints: 0, skillLevels, loadout })
          .returning();
        results.push({ defId: def.id, rarity: r, isDupe: (ownedCounts.get(def.id) ?? 0) > 0, newId: c.id });
        ownedCounts.set(def.id, (ownedCounts.get(def.id) ?? 0) + 1);
      }

      await db.update(players).set({ gems: player.gems - cost }).where(eq(players.id, player.id));
      return NextResponse.json({ results, gemsLeft: player.gems - cost });
    }

    // ============================ LEARN SKILL ==============================
    if (type === "learnSkill") {
      const charId = Number(body.charId);
      const skillId = String(body.skillId ?? "");
      const c = await getChar(charId, player.id);
      if (!c) return err("Không tìm thấy nhân vật");
      const def = CHAR_MAP.get(c.defId);
      if (!def) return err("Dữ liệu nhân vật lỗi");
      const skill = def.skills.find((s) => s.id === skillId);
      if (!skill) return err("Kỹ năng không tồn tại");
      const cur = c.skillLevels?.[skillId] ?? 0;
      if (cur >= MAX_SKILL_LEVEL) return err("Kỹ năng đã tối đa");
      const cost = skillLearnCost(cur + 1, skill.tier);
      const avail = pointsAvailable({ id: c.id, defId: c.defId, level: c.level, exp: c.exp, spentPoints: c.spentPoints, skillLevels: c.skillLevels ?? {}, loadout: c.loadout ?? [] });
      if (avail < cost.points) return err(`Thiếu điểm kỹ năng (cần ${cost.points}) — lên cấp để nhận thêm`);
      if (player.gold < cost.gold) return err(`Không đủ vàng (cần ${cost.gold})`);

      const skillLevels = { ...(c.skillLevels ?? {}), [skillId]: cur + 1 };
      await db
        .update(characters)
        .set({ skillLevels, spentPoints: c.spentPoints + cost.points })
        .where(eq(characters.id, c.id));
      await db.update(players).set({ gold: player.gold - cost.gold }).where(eq(players.id, player.id));
      return NextResponse.json({ ok: true, newLevel: cur + 1 });
    }

    // ============================ SET LOADOUT ==============================
    if (type === "setLoadout") {
      const charId = Number(body.charId);
      const loadout = (body.loadout as string[] | undefined) ?? [];
      const c = await getChar(charId, player.id);
      if (!c) return err("Không tìm thấy nhân vật");
      const def = CHAR_MAP.get(c.defId);
      if (!def) return err("Dữ liệu nhân vật lỗi");
      if (loadout.length > MAX_LOADOUT) return err(`Chỉ được mang tối đa ${MAX_LOADOUT} kỹ năng`);
      const uniq = new Set(loadout);
      if (uniq.size !== loadout.length) return err("Kỹ năng bị trùng");
      for (const sid of loadout) {
        const learned = (c.skillLevels?.[sid] ?? 0) > 0;
        const exists = def.skills.some((s) => s.id === sid);
        if (!exists) return err("Kỹ năng không thuộc nhân vật này");
        if (!learned) return err("Chỉ mang được kỹ năng đã học");
      }
      await db.update(characters).set({ loadout }).where(eq(characters.id, c.id));
      return NextResponse.json({ ok: true });
    }

    // ============================== EQUIP ==================================
    if (type === "equip") {
      const itemId = Number(body.itemId);
      const charId = Number(body.charId);
      const itemRows = await db
        .select()
        .from(items)
        .where(and(eq(items.id, itemId), eq(items.playerId, player.id)))
        .limit(1);
      const item = itemRows[0];
      if (!item) return err("Không tìm thấy trang bị");
      const c = await getChar(charId, player.id);
      if (!c) return err("Không tìm thấy nhân vật");
      const charDef = CHAR_MAP.get(c.defId);
      const itemDef = ITEM_MAP.get(item.defId);
      if (!charDef || !itemDef) return err("Dữ liệu lỗi");
      if (itemDef.cls && itemDef.cls !== charDef.classId)
        return err(`Trang bị này chỉ dành cho class khác — ${charDef.name} không dùng được`);

      // tháo món cùng slot đang mặc (nếu có)
      const wearing = await db
        .select()
        .from(items)
        .where(and(eq(items.equippedBy, c.id), eq(items.playerId, player.id)));
      for (const w of wearing) {
        const wd = ITEM_MAP.get(w.defId);
        if (wd && wd.slot === itemDef.slot && w.id !== itemId) {
          await db.update(items).set({ equippedBy: null }).where(eq(items.id, w.id));
        }
      }
      if (item.equippedBy && item.equippedBy !== c.id) {
        // đang mặc trên nhân vật khác -> chuyển
      }
      await db.update(items).set({ equippedBy: c.id }).where(eq(items.id, itemId));
      return NextResponse.json({ ok: true });
    }

    if (type === "unequip") {
      const itemId = Number(body.itemId);
      const itemRows = await db
        .select()
        .from(items)
        .where(and(eq(items.id, itemId), eq(items.playerId, player.id)))
        .limit(1);
      if (!itemRows[0]) return err("Không tìm thấy trang bị");
      await db.update(items).set({ equippedBy: null }).where(eq(items.id, itemId));
      return NextResponse.json({ ok: true });
    }

    // ============================== TEAM ===================================
    if (type === "setTeam") {
      const ids = (body.ids as number[] | undefined) ?? [];
      if (ids.length > 5) return err("Đội hình tối đa 5 ngưởi");
      const uniq = new Set(ids);
      if (uniq.size !== ids.length) return err("Nhân vật bị trùng");
      for (const id of ids) {
        const c = await getChar(Number(id), player.id);
        if (!c) return err("Nhân vật không hợp lệ");
      }
      await db.update(players).set({ team: ids.map(Number) }).where(eq(players.id, player.id));
      return NextResponse.json({ ok: true });
    }

    // ========================== BATTLE RESULT ==============================
    if (type === "battleResult") {
      const stageId = String(body.stageId ?? "");
      const victory = Boolean(body.victory);
      const participants = ((body.participants as number[]) ?? []).map(Number).slice(0, 5);
      const stage = STAGE_MAP.get(stageId);
      if (!stage) return err("Ải không tồn tại");

      const charRows = await db.select().from(characters).where(eq(characters.playerId, player.id));
      const owned = new Set(charRows.map((c) => c.id));
      const validParticipants = participants.filter((id) => owned.has(id));

      // EXP cho ngưởi tham chiến
      const baseExp = victory ? stage.exp : Math.round(stage.exp * 0.25);
      const levelups: { id: number; from: number; to: number }[] = [];
      for (const id of validParticipants) {
        const c = charRows.find((x) => x.id === id)!;
        let { level, exp } = c;
        if (level >= MAX_LEVEL) continue;
        exp += baseExp;
        const before = level;
        while (level < MAX_LEVEL && exp >= expForLevel(level)) {
          exp -= expForLevel(level);
          level++;
        }
        if (level >= MAX_LEVEL) exp = 0;
        if (level > before) levelups.push({ id, from: before, to: level });
        await db.update(characters).set({ level, exp }).where(eq(characters.id, id));
      }

      // thưởng vàng/ngọc/đồ
      let goldGain = 0;
      let gemsGain = 0;
      const dropped: string[] = [];
      const newCleared = [...player.cleared];
      if (victory) {
        goldGain = Math.round(stage.gold * (0.9 + Math.random() * 0.3));
        if (!player.cleared.includes(stageId)) {
          gemsGain += stage.gemsFirst;
          newCleared.push(stageId);
        }
        if (Math.random() < 0.25) gemsGain += 40;
        for (let r = 0; r < stage.dropRolls; r++) {
          if (Math.random() < 0.6) {
            const defId = rollItemDefId(stage.rarityW, Math.random);
            if (defId) {
              await db.insert(items).values({ playerId: player.id, defId, equippedBy: null });
              dropped.push(defId);
            }
          }
        }
      } else {
        goldGain = Math.round(stage.gold * 0.15);
      }

      await db
        .update(players)
        .set({ gold: player.gold + goldGain, gems: player.gems + gemsGain, cleared: newCleared })
        .where(eq(players.id, player.id));

      return NextResponse.json({
        ok: true,
        victory,
        exp: baseExp,
        goldGain,
        gemsGain,
        dropped,
        levelups,
        participants: validParticipants,
      });
    }

    // ========================== UPGRADE ITEM ===============================
    if (type === "upgradeItem") {
      const itemId = Number(body.itemId);
      const itemRows = await db
        .select()
        .from(items)
        .where(and(eq(items.id, itemId), eq(items.playerId, player.id)))
        .limit(1);
      const item = itemRows[0];
      if (!item) return err("Không tìm thấy trang bị");
      const d = ITEM_MAP.get(item.defId);
      if (!d) return err("Dữ liệu trang bị lỗi");

      const curLv = item.level;
      if (curLv >= 15) return err("Trang bị đã đạt cấp cường hóa tối đa (+15)");

      // Kiểm tra giới hạn cấp độ tương ứng ("nâng cấp trang bị ở các lv tương ứng mới nâng đc")
      if (item.equippedBy) {
        const char = await getChar(item.equippedBy, player.id);
        if (char) {
          if (curLv + 1 > char.level) {
            return err(`Cấp cường hóa (+${curLv + 1}) không thể vượt quá cấp độ tướng đang mặc (Lv.${char.level})!`);
          }
        }
      } else {
        if (curLv >= 3) {
          return err("Trang bị tự do chỉ nâng tối đa được +3. Hãy lắp vào tướng có cấp tương ứng để tiếp tục cường hóa!");
        }
      }

      // Chi phí vàng theo độ hiếm và cấp độ
      const baseCost = d.rarity === "SSR" ? 2200 : d.rarity === "SR" ? 1100 : 500;
      const cost = Math.round(baseCost * (1 + curLv * 0.45));
      if (player.gold < cost) return err(`Không đủ vàng để cường hóa (Cần ${cost.toLocaleString()} vàng)`);

      await db
        .update(items)
        .set({ level: curLv + 1 })
        .where(eq(items.id, item.id));

      await db
        .update(players)
        .set({ gold: player.gold - cost })
        .where(eq(players.id, player.id));

      return NextResponse.json({ ok: true, newLevel: curLv + 1 });
    }

    // ============================ BUY SHOP =================================
    if (type === "buyItem") {
      const itemId = String(body.itemId);
      const price = Number(body.price);
      
      const d = ITEM_MAP.get(itemId);
      if (!d) return err("Vật phẩm không tồn tại");
      if (player.gold < price) return err(`Không đủ vàng (Cần ${price.toLocaleString()} vàng)`);

      await db.insert(items).values({
        playerId: player.id,
        defId: itemId,
        equippedBy: null,
        level: 0,
      });

      await db
        .update(players)
        .set({ gold: player.gold - price })
        .where(eq(players.id, player.id));

      return NextResponse.json({ ok: true });
    }

    if (type === "buyGems") {
      const price = Number(body.price);
      const gemsGain = Number(body.gemsGain);

      if (player.gold < price) return err(`Không đủ vàng (Cần ${price.toLocaleString()} vàng)`);

      await db
        .update(players)
        .set({ gold: player.gold - price, gems: player.gems + gemsGain })
        .where(eq(players.id, player.id));

      return NextResponse.json({ ok: true });
    }

    return err("unknown mutation " + type, 404);
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "server error" }, { status: 500 });
  }
}
