import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Be_Vietnam_Pro } from "next/font/google";
import "./globals.css";

const font = Be_Vietnam_Pro({
  subsets: ["latin", "vietnamese"],
  weight: ["400", "500", "600", "700", "800", "900"],
});

export const metadata: Metadata = {
  title: "Triệu Hồi Kỷ Nguyên — Gacha Turn-based RPG",
  description: "Game gacha đánh theo lượt: 3 class, skill tree, trang bị, chinh phục Ma Vương.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover", // cho phép kéo dài ra sau notch — dùng kèm safe-area CSS
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="vi">
      <body className={`${font.className} bg-[#0b0e1a] text-slate-100 antialiased`}>{children}</body>
    </html>
  );
}
