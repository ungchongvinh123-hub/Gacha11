// ============================================================================
// Skill templates + bộ sinh skill tree (20 kỹ năng / nhân vật, deterministic)
// ============================================================================
import type {
  ClassId,
  EffectType,
  Element,
  QteKind,
  SkillDef,
  SkillEffectDef,
  SkillTarget,
  SkillType,
  EFFECT_LABEL as _EL,
} from "../types";
import { DEFAULT_KIT_SIZE, EFFECT_LABEL, MAX_LOADOUT } from "../types";

const r2 = (n: number) => Math.round(n * 100) / 100;

// deterministic rng ----------------------------------------------------------
export function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// 5-level scaling helpers -----------------------------------------------------
const sc = (b: number, f = [1, 1.18, 1.38, 1.6, 1.85]) => f.map((x) => r2(b * x));
const ch = (b: number) => [b, b + 0.06, b + 0.12, b + 0.18, b + 0.25].map((x) => Math.min(0.99, r2(x)));
const fl = (b: number) => [b, b, b, b, b];
const gr = (b: number, step: number) => [b, b + step, b + step * 2, b + step * 3, b + step * 4].map(r2);

const eff = (type: EffectType, chance: number[], turns: number[], power: number[]): SkillEffectDef => ({
  type,
  chance,
  turns,
  power,
});

// element word cho tên kỹ năng vật lý -----------------------------------------
export const ELEM_WORD: Record<Element, string> = {
  fire: "Viêm",
  ice: "Hàn Băng",
  nature: "Mộc Linh",
  thunder: "Lôi",
  holy: "Thánh Quang",
  dark: "Ám",
  neutral: "Thiết",
};

// Kỹ năng gây hiệu ứng theo hệ của nhân vật ----------------------------------
export const ELEMENT_HIT: Partial<Record<Element, string>> = {
  fire: "burnHit",
  ice: "frostHit",
  nature: "poisonHit",
  thunder: "shockHit",
  dark: "drain",
};

interface Tpl {
  key: string;
  type: SkillType;
  target: SkillTarget;
  icon: string;
  tier: 0 | 1 | 2;
  elem?: Element; // hệ của hiệu ứng; undefined = theo hệ nhân vật
  cost: number; // chi phí xúc xắc cơ bản (giảm khi lên cấp skill)
  qte?: QteKind; // chỉ một số skill có QTE — loại khớp bản chất skill
  power?: number[];
  hits?: number;
  splashPower?: number;
  pierce?: number;
  effects?: SkillEffectDef[];
  special?: SkillDef["special"];
  name: (w: string) => string;
  w: Record<ClassId, number>; // trọng số theo class (0 = không xuất hiện)
}

const ALL = 1;

export const TEMPLATES: Tpl[] = [
  // ------------------------------ SÁT THƯƠNG -------------------------------
  { key: "slash", type: "damage", target: "enemy", icon: "sword", tier: 0, cost: 1, power: sc(1.5), name: (w) => `${w} Trảm`, w: { tank: ALL, attacker: ALL, support: 1 } },
  { key: "heavy", type: "damage", target: "enemy", icon: "axe", tier: 0, cost: 3, power: sc(2.4), name: (w) => `${w} Phá Kích`, qte: "charge", w: { tank: 1, attacker: 1.6, support: 0.4 } },
  { key: "flurry", type: "damage", target: "enemy", icon: "swords", tier: 0, cost: 3, power: sc(0.8), hits: 3, name: (w) => `${w} Liên Kích`, qte: "tap", w: { tank: 0.5, attacker: 1.5, support: 0.4 } },
  { key: "aoe", type: "damage", target: "enemies", icon: "wind", tier: 1, cost: 4, power: sc(0.9), name: (w) => `${w} Oanh Tạc`, qte: "tap", w: { tank: 0.6, attacker: 1.6, support: 0.8 } },
  { key: "splash", type: "damage", target: "enemy", icon: "tornado", tier: 0, cost: 2, power: sc(1.35), splashPower: 0.7, name: (w) => `${w} Khuếch Tán`, w: { tank: 1, attacker: 1.4, support: 0.8 } },
  { key: "pierce", type: "damage", target: "enemy", icon: "crosshair", tier: 0, cost: 2, power: sc(1.55), pierce: 0.5, name: (w) => `${w} Xuyên Kích`, w: { tank: 0.6, attacker: 1.5, support: 0.4 } },
  { key: "execute", type: "damage", target: "enemy", icon: "skull", tier: 1, cost: 4, power: sc(1.35), special: "execute", name: (w) => `${w} Đoạn Mệnh`, qte: "charge", w: { tank: 0.3, attacker: 1.4, support: 0.1 } },
  { key: "drain", type: "damage", target: "enemy", icon: "syringe", tier: 1, cost: 3, power: sc(1.4), special: "lifesteal", elem: "dark", name: () => `Hấp Huyết Thuật`, qte: "connect", w: { tank: 0.6, attacker: 1.1, support: 0.3 } },

  // --------------------- SÁT THƯƠNG + HIỆU ỨNG ĐƠN --------------------------
  { key: "burnHit", type: "damage", target: "enemy", icon: "flame", tier: 1, cost: 2, power: sc(1.15), elem: "fire", name: () => `Hỏa Diễm Thiêu Kích`, effects: [eff("burn", ch(0.8), [2, 2, 3, 3, 4], sc(0.32))], qte: "charge", w: { tank: 0.7, attacker: 1.3, support: 0.5 } },
  { key: "frostHit", type: "damage", target: "enemy", icon: "snowflake", tier: 1, cost: 3, power: sc(1.05), elem: "ice", name: () => `Băng Phong Kích`, effects: [eff("freeze", ch(0.5), fl(1), fl(1))], w: { tank: 0.8, attacker: 1.1, support: 0.9 } },
  { key: "poisonHit", type: "damage", target: "enemy", icon: "biohazard", tier: 1, cost: 2, power: sc(0.95), elem: "nature", name: () => `Kịch Độc Kích`, effects: [eff("poison", ch(0.85), [2, 3, 3, 4, 4], sc(0.2))], w: { tank: 0.7, attacker: 1.2, support: 0.6 } },
  { key: "shockHit", type: "damage", target: "enemy", icon: "zap", tier: 1, cost: 3, power: sc(1.1), elem: "thunder", name: () => `Lôi Điện Kích`, effects: [eff("shock", ch(0.5), fl(2), fl(1))], w: { tank: 0.6, attacker: 1.2, support: 0.8 } },
  { key: "sunder", type: "damage", target: "enemy", icon: "hammer", tier: 0, cost: 1, power: sc(1.2), name: (w) => `Phá Giáp ${w}`, effects: [eff("defDown", ch(0.8), fl(2), gr(0.2, 0.05))], w: { tank: 1.2, attacker: 0.9, support: 0.3 } },
  { key: "weaken", type: "debuff", target: "enemy", icon: "feather", tier: 0, cost: 1, power: sc(0.9), name: () => `Nhược Thể Chú`, effects: [eff("atkDown", ch(0.85), fl(2), gr(0.2, 0.05))], w: { tank: 0.6, attacker: 0.6, support: 1 } },

  // --------------------- SÁT THƯƠNG DIỆN RỘNG + DEBUFF ----------------------
  { key: "meteor", type: "damage", target: "enemies", icon: "bomb", tier: 2, cost: 5, power: sc(0.75), elem: "fire", name: () => `Thiên Thạch Giáng Lâm`, effects: [eff("burn", ch(0.55), [2, 2, 3, 3, 4], sc(0.26))], qte: "charge", w: { tank: 0.3, attacker: 0.9, support: 0.4 } },
  { key: "blizzard", type: "damage", target: "enemies", icon: "snowflake", tier: 2, cost: 5, power: sc(0.65), elem: "ice", name: () => `Bạo Tuyết Phong Sát`, effects: [eff("freeze", ch(0.32), fl(1), fl(1))], qte: "connect", w: { tank: 0.3, attacker: 0.7, support: 0.6 } },
  { key: "plague", type: "damage", target: "enemies", icon: "bug", tier: 2, cost: 5, power: sc(0.6), elem: "nature", name: () => `Ôn Dịch Lan Tràn`, effects: [eff("poison", ch(0.6), [3, 3, 3, 4, 4], sc(0.17))], qte: "tap", w: { tank: 0.3, attacker: 0.8, support: 0.5 } },
  { key: "storm", type: "damage", target: "enemies", icon: "cloud-lightning", tier: 2, cost: 5, power: sc(0.68), elem: "thunder", name: () => `Thiên Lôi Loạn Vũ`, effects: [eff("shock", ch(0.3), fl(2), fl(1))], qte: "tap", w: { tank: 0.2, attacker: 0.8, support: 0.5 } },

  // -------------------------------- HỒI MÁU ---------------------------------
  { key: "heal", type: "heal", target: "ally", icon: "heart", tier: 0, cost: 2, power: sc(2.7), name: () => "Lời Cầu Nguyện", w: { tank: 0.4, attacker: 0, support: 2.2 } },
  { key: "healAll", type: "heal", target: "allies", icon: "heart-pulse", tier: 1, cost: 4, power: sc(1.4), name: () => `Tán Dương Sinh Mệnh`, w: { tank: 0.1, attacker: 0, support: 1.4 } },
  { key: "regen", type: "heal", target: "ally", icon: "sprout", tier: 0, cost: 2, power: fl(0), special: "regen", name: () => `Sức Sống Tái Sinh`, effects: [eff("regen", fl(1), fl(3), sc(0.95))], w: { tank: 0.5, attacker: 0, support: 1.6 } },
  { key: "cleanseT", type: "heal", target: "ally", icon: "sparkles", tier: 0, cost: 1, power: sc(1.3), special: "cleanse", name: () => `Thanh Tẩy`, w: { tank: 0.4, attacker: 0, support: 1.8 } },
  { key: "panacea", type: "heal", target: "allies", icon: "wand-2", tier: 2, cost: 6, power: sc(0.9), special: "cleanse", name: () => `Vạn Dược Thần Thánh`, w: { tank: 0, attacker: 0, support: 0.8 } },

  // --------------------------------- BUFF -----------------------------------
  { key: "buffAtk", type: "buff", target: "ally", icon: "chevrons-up", tier: 0, cost: 1, power: fl(0), name: () => `Chiến Khí Bùng Nổ`, effects: [eff("atkUp", fl(1), fl(3), gr(0.3, 0.06))], w: { tank: 0.5, attacker: 0.3, support: 1.5 } },
  { key: "buffDef", type: "buff", target: "ally", icon: "shield", tier: 0, cost: 1, power: fl(0), name: () => `Thạch Bích Hộ Thể`, effects: [eff("defUp", fl(1), fl(3), gr(0.3, 0.06))], w: { tank: 1.2, attacker: 0.2, support: 1.2 } },
  { key: "warcry", type: "buff", target: "allies", icon: "megaphone", tier: 1, cost: 4, power: fl(0), name: () => `Hò Reo Chiến Trận`, effects: [eff("atkUp", fl(1), fl(2), gr(0.22, 0.05))], w: { tank: 0.4, attacker: 0.1, support: 1.2 } },
  { key: "bulwark", type: "buff", target: "allies", icon: "castle", tier: 1, cost: 4, power: fl(0), name: () => `Bất Động Minh Vương`, effects: [eff("defUp", fl(1), fl(2), gr(0.22, 0.05))], w: { tank: 1, attacker: 0.1, support: 1 } },

  // ------------------------------ ĐỠ ĐÒN / ĐẶC BIỆT --------------------------
  { key: "taunt", type: "buff", target: "self", icon: "flag", tier: 0, cost: 1, power: fl(0), special: "taunt", name: () => `Khiêu Khích`, effects: [eff("taunt", fl(1), fl(2), fl(1)), eff("defUp", fl(1), fl(2), gr(0.3, 0.07))], w: { tank: 2.4, attacker: 0, support: 0 } },
  { key: "shieldWall", type: "special", target: "ally", icon: "shield-half", tier: 1, cost: 3, power: fl(0), special: "shield", name: () => `Thuẫn Bích`, effects: [eff("shield", fl(1), fl(2), sc(2.3))], qte: "connect", w: { tank: 1.6, attacker: 0, support: 0.9 } },
  { key: "revive", type: "special", target: "deadAlly", icon: "cross", tier: 2, cost: 6, power: gr(0.4, 0.08), special: "revive", name: () => `Phép Tái Sinh`, qte: "connect", w: { tank: 0, attacker: 0, support: 0.6 } },
];

const TPL_MAP = new Map(TEMPLATES.map((t) => [t.key, t]));

// instantiate 1 template thành SkillDef cho nhân vật --------------------------
function instantiate(
  t: Tpl,
  char: { id: string; classId: ClassId; element: Element },
  rand: () => number,
): SkillDef {
  const powJit = 0.92 + rand() * 0.16;
  const element = t.elem ?? char.element;
  // class hiệu chỉnh: tank/support gây damage thấp hơn attacker
  const clsMul = t.type === "damage" ? (char.classId === "attacker" ? 1 : char.classId === "tank" ? 0.8 : 0.72) : 1;
  const boostMul = t.type === "heal" || t.key === "shieldWall" ? (char.classId === "support" ? 1.15 : 1) : 1;
  return {
    id: `${char.id}:${t.key}`,
    key: t.key,
    name: t.name(ELEM_WORD[element]),
    type: t.type,
    target: t.target,
    icon: t.icon,
    element,
    tier: t.tier,
    cost: [0, 1, 2, 3, 4].map((i) => Math.max(1, (t.cost ?? 3) - i)),
    qte: t.qte,
    power: (t.power ?? fl(0)).map((p) => r2(p * powJit * clsMul * boostMul)),
    hits: t.hits,
    splashPower: t.splashPower,
    pierce: t.pierce,
    effects: t.effects?.map((e) => ({
      ...e,
      power: e.power.map((p) => r2(p * powJit * boostMul)),
    })),
    special: t.special,
  };
}

// sinh skill tree deterministic theo id nhân vật ------------------------------
// size mặc định = DEFAULT_KIT_SIZE (20). Mở rộng tương lai: gọi buildKit(char, 25)
// để tạo tướng 25 skill — UI skill tree tự render theo def.skills.length.
export function buildKit(
  char: { id: string; classId: ClassId; element: Element; rarity: string },
  size: number = DEFAULT_KIT_SIZE,
): SkillDef[] {
  const rand = mulberry32(hashStr("kit:" + char.id));
  const pool = TEMPLATES.filter((t) => t.w[char.classId] > 0);
  const chosen: Tpl[] = [];
  const take = (key: string) => {
    const t = TPL_MAP.get(key);
    if (t && pool.includes(t) && !chosen.includes(t)) chosen.push(t);
  };

  take("slash");
  if (char.classId === "tank") {
    take("taunt");
    take("shieldWall");
    take("sunder");
  } else if (char.classId === "attacker") {
    take("heavy");
    take("flurry");
    take("aoe");
    take(ELEMENT_HIT[char.element] ?? "pierce");
  } else {
    take("heal");
    take(rand() < 0.5 ? "healAll" : "regen");
    take("cleanseT");
    take(ELEMENT_HIT[char.element] ?? "frostHit");
  }

  // sample có trọng số cho đến khi đủ `size` kỹ năng
  while (chosen.length < size) {
    const remaining = pool.filter((t) => !chosen.includes(t));
    if (remaining.length === 0) break;
    const weights = remaining.map((t) => {
      let w = t.w[char.classId];
      if (t.elem && t.elem === char.element) w *= 3;
      if (t.tier === 2) w *= char.rarity === "SSR" ? 1 : char.rarity === "SR" ? 0.35 : 0.08;
      if (t.tier === 1) w *= 0.9;
      return w;
    });
    let sum = weights.reduce((a, b) => a + b, 0);
    let roll = rand() * sum;
    let idx = 0;
    for (; idx < remaining.length - 1; idx++) {
      roll -= weights[idx];
      if (roll <= 0) break;
    }
    chosen.push(remaining[idx]);
  }

  // đảm bảo số kỹ năng gây sát thương tối thiểu (mọi class đều có đòn đánh)
  const minDmg = char.classId === "attacker" ? 10 : char.classId === "tank" ? 5 : 6;
  const isDmg = (t: Tpl) => t.type === "damage";
  const protect = (t: Tpl) =>
    t.key === "taunt" || t.key === "heal" || t.key === "shieldWall" || t.key === "cleanseT";
  let guard = 0;
  while (chosen.filter(isDmg).length < minDmg && guard++ < 50) {
    const swapOut = chosen.find((t) => !isDmg(t) && !protect(t) && t.key !== "slash");
    const swapIn = pool.find((t) => isDmg(t) && !chosen.includes(t));
    if (!swapOut || !swapIn) break;
    chosen[chosen.indexOf(swapOut)] = swapIn;
  }

  const kit = chosen.slice(0, size).map((t) => instantiate(t, char, rand));
  // tên bí kỹ cho tier-2 đầu tiên
  const ult = kit.find((s) => s.tier === 2);
  if (ult) ult.name = `${ult.name} · Bí Kỹ`;
  return kit;
}

// kỹ năng đơn lẻ từ key (dùng cho quái) --------------------------------------
export function skillFromKey(key: string, owner: { id: string; classId: ClassId; element: Element }): SkillDef {
  const t = TPL_MAP.get(key);
  if (!t) throw new Error("unknown skill " + key);
  return instantiate(t, owner, mulberry32(hashStr("es:" + owner.id + key)));
}

// mô tả kỹ năng theo cấp ------------------------------------------------------
const pct = (n: number) => Math.round(n * 100);

export function describeSkill(s: SkillDef, lv: number): string {
  const i = Math.max(0, Math.min(4, lv - 1));
  const parts: string[] = [];
  const tgt =
    s.target === "enemies"
      ? "toàn bộ địch"
      : s.target === "allies"
        ? "toàn đội"
        : s.target === "self"
          ? "bản thân"
          : s.target === "deadAlly"
            ? "1 đồng minh đã ngã"
            : s.target === "ally"
              ? "1 đồng minh"
              : "1 kẻ địch";
  const p = s.power[i] ?? 0;

  if (s.special === "revive") {
    parts.push(`Hồi sinh ${tgt} với ${pct(p)}% máu tối đa`);
  } else {
    if (p > 0 && s.type === "damage") {
      let d = `Gây sát thương bằng ${pct(p)}% Tấn công lên ${tgt}`;
      if (s.hits && s.hits > 1) d += ` (${s.hits} đòn liên tiếp)`;
      parts.push(d);
    }
    if (p > 0 && (s.type === "heal" || s.special === "cleanse" || s.special === "manaGift")) {
      if (s.type === "heal" || s.special === "cleanse") parts.push(`Hồi máu bằng ${pct(p)}% Tấn công cho ${tgt}`);
      if (s.special === "manaGift") parts.push(`Hồi ${pct(p)}% mana tối đa cho ${tgt}`);
    }
    if (s.type === "debuff" && p > 0) parts.push(`Gây sát thương bằng ${pct(p)}% Tấn công lên ${tgt}`);
  }
  if (s.special === "lifesteal") parts.push(`Hút máu bằng 60% sát thương gây ra`);
  if (s.special === "execute") parts.push(`Sát thương x1.8 nếu mục tiêu dưới 40% máu`);
  if (s.special === "taunt") parts.push(`Ép kẻ địch tấn công bản thân`);
  if (s.special === "cleanse") parts.push(`Giải toàn bộ hiệu ứng xấu cho ${tgt}`);
  if (s.pierce) parts.push(`Bỏ qua ${pct(s.pierce)}% phòng thủ`);
  if (s.splashPower) parts.push(`Lan ${pct(s.splashPower)}% sát thương sang mục tiêu kề bên`);

  for (const e of s.effects ?? []) {
    const c = Math.round(e.chance[i] * 100);
    const t = e.turns[i];
    const pw = e.power[i];
    const label = EFFECT_LABEL[e.type as keyof typeof EFFECT_LABEL];
    let strength = "";
    if (e.type === "burn" || e.type === "poison" || e.type === "regen")
      strength = `, bằng ${pct(pw)}% Tấn công mỗi lượt`;
    else if (e.type === "shield") strength = ` hấp thụ bằng ${pct(pw)}% Tấn công`;
    else if (e.type === "atkUp" || e.type === "defUp" || e.type === "atkDown" || e.type === "defDown" || e.type === "manaRegenUp" || e.type === "maxManaUp")
      strength = ` ${pct(pw)}%`;
    const chanceTxt = c >= 100 ? "" : ` (${c}% tỉ lệ)`;
    parts.push(`Gây ${label} ${t} lượt${strength}${chanceTxt}`);
  }
  parts.push(`Cần ${s.cost[i]} điểm xúc xắc`);
  return parts.join(". ") + ".";
}

// loadout mặc định khi triệu hồi ----------------------------------------------
export function defaultLoadout(def: { classId: ClassId; skills: SkillDef[] }): string[] {
  const find = (key: string) => def.skills.find((s) => s.key === key)?.id;
  const out: string[] = [];
  const push = (id?: string) => {
    if (id && !out.includes(id)) out.push(id);
  };
  push(find("slash"));
  if (def.classId === "tank") {
    push(find("taunt"));
    push(find("shieldWall") ?? find("sunder") ?? find("heavy"));
  } else if (def.classId === "attacker") {
    push(find("heavy"));
    push(find("aoe") ?? find("flurry"));
  } else {
    push(find("heal"));
    push(find("healAll") ?? find("regen") ?? find("buffAtk"));
  }
  // Ưu tiên thêm skill chi phí nhỏ (đề phòng xúc xắc ra ít điểm) + skill mạnh (cost>=6)
  const rest = def.skills.filter((s) => !out.includes(s.id));
  const cheap = rest.filter((s) => s.cost[0] <= 2);
  const strong = rest.filter((s) => s.cost[0] >= 6);
  for (const s of [...cheap, ...strong, ...rest]) push(s.id);
  return out.slice(0, MAX_LOADOUT);
}
