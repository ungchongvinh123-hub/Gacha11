// ============================================================================
// Trang bị — vũ khí / giáp theo class, trang sức dùng chung
// Đã mở rộng số lượng vật phẩm (35+) và thêm tính năng đặc biệt (Passives)
// ============================================================================
import type { ClassId, ItemDef, ItemSlot, Rarity, StatBonus, ItemPassive } from "../types";

interface Row {
  id: string;
  name: string;
  slot: ItemSlot;
  cls: ClassId | null;
  rarity: Rarity;
  stats: StatBonus;
  icon: string;
  passives?: ItemPassive[];
}

const ITEMS: Row[] = [
  // ----------------------- VŨ KHÍ: TẤN CÔNG (Kiếm, Đao, Cung...) -----------------
  { id: "w_atk_r1",  name: "Kiếm Tân Binh",     slot: "weapon", cls: "attacker", rarity: "R",   stats: { atk: 8 }, icon: "sword" },
  { id: "w_atk_r2",  name: "Cung Săn Mỏ",       slot: "weapon", cls: "attacker", rarity: "R",   stats: { atk: 6, crit: 0.02 }, icon: "target" },
  { id: "w_atk_sr1", name: "Song Nhận Ma Pháp", slot: "weapon", cls: "attacker", rarity: "SR",  stats: { atk: 14, crit: 0.03 }, icon: "swords",
    passives: [{ type: "extraDie", value: 1, desc: "Thêm 1 cơ hội roll xúc xắc cao hơn (mana tối đa 6)" }]
  },
  { id: "w_atk_sr2", name: "Đại Cung Phong Sát",slot: "weapon", cls: "attacker", rarity: "SR",  stats: { atk: 16, critDmg: 0.18 }, icon: "crosshair",
    passives: [{ type: "executeThreshold", value: 0.05, desc: "Kết liễu ngay quái dưới 5% máu" }]
  },
  { id: "w_atk_ssr1",name: "Long Nha Kiếm",     slot: "weapon", cls: "attacker", rarity: "SSR", stats: { atk: 28, crit: 0.05, atkPct: 0.08 }, icon: "sword",
    passives: [
      { type: "healOnKill", value: 0.15, desc: "Hồi 15% HP tối đa khi hạ gục quái" },
      { type: "executeThreshold", value: 0.04, desc: "Kết liễu quái dưới 4% máu" },
    ]
  },
  { id: "w_atk_ssr2",name: "Chu Tước Thánh Cung",slot: "weapon", cls: "attacker", rarity: "SSR", stats: { atk: 24, crit: 0.04, critDmg: 0.3 }, icon: "target",
    passives: [{ type: "elementOnSkill", value: 0.35, desc: "35% tỉ lệ gây Thiêu Đốt khi dùng kỹ năng" }]
  },
  { id: "w_atk_ssr3",name: "Ma Đao Diệt Hồn",   slot: "weapon", cls: "attacker", rarity: "SSR", stats: { atk: 32, crit: 0.07 }, icon: "skull",
    passives: [{ type: "executeThreshold", value: 0.08, desc: "Kết liễu ngay quái dưới 8% máu" }]
  },

  // ----------------------- VŨ KHÍ: ĐỠ ĐÒN (KHIÊN) ----------------------------
  { id: "w_tnk_r1",  name: "Khiên Gỗ",          slot: "weapon", cls: "tank", rarity: "R",   stats: { def: 8, hp: 25 }, icon: "shield" },
  { id: "w_tnk_r2",  name: "Thuẫn Sắt",         slot: "weapon", cls: "tank", rarity: "R",   stats: { def: 11 }, icon: "shield" },
  { id: "w_tnk_sr1", name: "Khiên Tháp Cự Thạch",slot: "weapon", cls: "tank", rarity: "SR",  stats: { def: 17, hp: 70 }, icon: "shield",
    passives: [{ type: "healOnKill", value: 0.06, desc: "Hồi 6% HP tối đa khi hạ gục quái" }]
  },
  { id: "w_tnk_sr2", name: "Khiên Bích Chướng",  slot: "weapon", cls: "tank", rarity: "SR",  stats: { def: 14, effectRes: 0.06 }, icon: "shield-half",
    passives: [{ type: "extraDie", value: 1, desc: "Thêm 1 cơ hội roll xúc xắc cao hơn (mana tối đa 6)" }]
  },
  { id: "w_tnk_ssr1",name: "Thần Thuẫn Aegis",  slot: "weapon", cls: "tank", rarity: "SSR", stats: { def: 27, hp: 170, hpPct: 0.06 }, icon: "shield",
    passives: [
      { type: "healOnKill", value: 0.12, desc: "Hồi 12% HP tối đa khi hạ gục quái" },
      { type: "extraDie", value: 1, desc: "Thêm 1 cơ hội roll xúc xắc cao hơn (mana tối đa 6)" },
    ]
  },
  { id: "w_tnk_ssr2",name: "Long Lân Thuẫn",    slot: "weapon", cls: "tank", rarity: "SSR", stats: { def: 30, effectRes: 0.1 }, icon: "shield-half",
    passives: [{ type: "elementOnSkill", value: 0.25, desc: "25% tỉ lệ gây Tê Liệt lên kẻ tấn công" }]
  },
  { id: "w_tnk_ssr3",name: "Trấn Thiên Hải Thuẫn",slot: "weapon", cls: "tank", rarity: "SSR", stats: { def: 35, hp: 220 }, icon: "castle",
    passives: [{ type: "extraDie", value: 1, desc: "Thêm 1 cơ hội roll xúc xắc cao hơn (mana tối đa 6)" }]
  },

  // ----------------------- VŨ KHÍ: HỒI MÁU/PHÉP (TRƯỢNG) ----------------------
  { id: "w_sup_r1",  name: "Trượng Lục",        slot: "weapon", cls: "support", rarity: "R",   stats: { atk: 5, }, icon: "wand" },
  { id: "w_sup_r2",  name: "Trượng Gai Nhọn",   slot: "weapon", cls: "support", rarity: "R",   stats: { atk: 8 }, icon: "wand" },
  { id: "w_sup_sr1", name: "Nguyệt Trượng",     slot: "weapon", cls: "support", rarity: "SR",  stats: { atk: 13, }, icon: "wand-2",
    passives: [{ type: "extraDie", value: 1, desc: "Thêm 1 cơ hội roll xúc xắc cao hơn (mana tối đa 6)" }]
  },
  { id: "w_sup_sr2", name: "Trượng Tịnh Thổ",   slot: "weapon", cls: "support", rarity: "SR",  stats: { atk: 11, hp: 55 }, icon: "wand",
    passives: [{ type: "healOnKill", value: 0.08, desc: "Hồi 8% HP khi hạ gục quái" }]
  },
  { id: "w_sup_ssr1",name: "Thái Dương Trượng", slot: "weapon", cls: "support", rarity: "SSR", stats: { atk: 23, }, icon: "wand-2",
    passives: [{ type: "extraDie", value: 1, desc: "Thêm 1 cơ hội roll xúc xắc cao hơn (mana tối đa 6)" }]
  },
  { id: "w_sup_ssr2",name: "Hắc Diệu Pháp Trượng",slot: "weapon", cls: "support", rarity: "SSR", stats: { atk: 19, atkPct: 0.1 }, icon: "wand",
    passives: [{ type: "elementOnSkill", value: 0.3, desc: "30% tỉ lệ gây Đóng Băng khi dùng kỹ năng" }]
  },
  { id: "w_sup_ssr3",name: "Mộc Linh Tiên Trượng",slot: "weapon", cls: "support", rarity: "SSR", stats: { atk: 22, hp: 120, }, icon: "sprout",
    passives: [{ type: "healOnKill", value: 0.15, desc: "Hồi 15% HP tối đa khi hạ gục quái" }]
  },

  // ------------------------------ GIÁP ---------------------------------------
  { id: "a_tnk_r",   name: "Trọng Giáp",        slot: "armor", cls: "tank", rarity: "R",    stats: { def: 10, hp: 40 }, icon: "shirt" },
  { id: "a_tnk_sr",  name: "Giáp Huyền Thiết",  slot: "armor", cls: "tank", rarity: "SR",   stats: { def: 17, hp: 90, effectRes: 0.04 }, icon: "shirt" },
  { id: "a_tnk_ssr", name: "Thiên Thạch Giáp",  slot: "armor", cls: "tank", rarity: "SSR",  stats: { def: 28, hp: 160, hpPct: 0.08 }, icon: "shirt",
    passives: [{ type: "healOnKill", value: 0.08, desc: "Hồi 8% HP tối đa khi hạ gục kẻ địch" }]
  },
  { id: "a_tnk_ssr2",name: "Hoàng Kim Chiến Giáp",slot: "armor", cls: "tank", rarity: "SSR",  stats: { def: 32, hp: 180, effectRes: 0.08 }, icon: "crown",
    passives: [{ type: "extraDie", value: 1, desc: "Thêm 1 cơ hội roll xúc xắc cao hơn (mana tối đa 6)" }]
  },

  { id: "a_atk_r",   name: "Võ Phục",           slot: "armor", cls: "attacker", rarity: "R",   stats: { def: 6, atk: 4 }, icon: "shirt" },
  { id: "a_atk_sr",  name: "Ảnh Bộ Y",          slot: "armor", cls: "attacker", rarity: "SR",  stats: { def: 10, atk: 8, crit: 0.02 }, icon: "shirt" },
  { id: "a_atk_ssr", name: "Thần Tốc Chiến Y",  slot: "armor", cls: "attacker", rarity: "SSR", stats: { def: 15, atk: 15, crit: 0.04, critDmg: 0.15 }, icon: "shirt",
    passives: [{ type: "executeThreshold", value: 0.06, desc: "Kết liễu ngay quái dưới 6% máu" }]
  },
  { id: "a_atk_ssr2",name: "Mộng Diệp Dạ Hành Y",slot: "armor", cls: "attacker", rarity: "SSR", stats: { def: 13, atk: 18, crit: 0.05 }, icon: "moon",
    passives: [{ type: "healOnKill", value: 0.1, desc: "Hồi 10% HP tối đa khi hạ gục quái" }]
  },

  { id: "a_sup_r",   name: "Pháp Bào",          slot: "armor", cls: "support", rarity: "R",   stats: { def: 7, }, icon: "shirt" },
  { id: "a_sup_sr",  name: "Tinh Không Bào",    slot: "armor", cls: "support", rarity: "SR",  stats: { def: 11, effectRes: 0.05 }, icon: "shirt" },
  { id: "a_sup_ssr", name: "Thánh Quang Miện Bào",slot: "armor", cls: "support", rarity: "SSR", stats: { def: 16, hp: 90 }, icon: "shirt",
    passives: [{ type: "extraDie", value: 1, desc: "Thêm 1 cơ hội roll xúc xắc cao hơn (mana tối đa 6)" }]
  },
  { id: "a_sup_ssr2",name: "Pháp Y Vạn Thủy",    slot: "armor", cls: "support", rarity: "SSR", stats: { def: 14, }, icon: "droplets",
    passives: [{ type: "healOnKill", value: 0.1, desc: "Hồi 10% HP khi tiêu diệt kẻ địch" }]
  },

  // --------------------------- TRANG SỨC (CHUNG) ------------------------------
  { id: "j_r1",  name: "Nhẫn Đồng",          slot: "accessory", cls: null, rarity: "R",   stats: { hp: 35 }, icon: "gem" },
  { id: "j_r2",  name: "Dây Chuyền Đá",      slot: "accessory", cls: null, rarity: "R",   stats: { def: 6 }, icon: "gem" },
  { id: "j_r3",  name: "Bùa Lá Non",         slot: "accessory", cls: null, rarity: "R",   stats: { effectRes: 0.05 }, icon: "gem" },
  { id: "j_r4",  name: "Vòng Sắt",           slot: "accessory", cls: null, rarity: "R",   stats: { atk: 5 }, icon: "gem" },
  
  { id: "j_sr1", name: "Nhẫn Ma Lực",        slot: "accessory", cls: null, rarity: "SR",  stats: { }, icon: "gem",
    passives: [{ type: "extraDie", value: 1, desc: "Thêm 1 cơ hội roll xúc xắc cao hơn (mana tối đa 6)" }]
  },
  { id: "j_sr2", name: "Vòng Ngọc Bích",     slot: "accessory", cls: null, rarity: "SR",  stats: { hpPct: 0.08 }, icon: "gem" },
  { id: "j_sr3", name: "Bùa Trừ Tà",         slot: "accessory", cls: null, rarity: "SR",  stats: { effectRes: 0.1 }, icon: "gem" },
  { id: "j_sr4", name: "Chuỗi Chiến Binh",   slot: "accessory", cls: null, rarity: "SR",  stats: { atk: 8, crit: 0.03 }, icon: "gem" },
  { id: "j_sr5", name: "Nhẫn Huyết Thạch",   slot: "accessory", cls: null, rarity: "SR",  stats: { hp: 50, atk: 4 }, icon: "gem",
    passives: [{ type: "healOnKill", value: 0.05, desc: "Hồi 5% HP tối đa khi hạ gục quái" }]
  },

  { id: "j_ssr1",name: "Ngọc Tứ Linh",       slot: "accessory", cls: null, rarity: "SSR", stats: { atk: 9, def: 9, hpPct: 0.08 }, icon: "gem",
    passives: [
      { type: "healOnKill", value: 0.1, desc: "Hồi 10% HP tối đa khi tiêu diệt kẻ địch" },
      { type: "elementOnSkill", value: 0.15, desc: "15% tỉ lệ gây hiệu ứng theo hệ khi dùng kỹ năng" },
    ]
  },
  { id: "j_ssr2",name: "Nhẫn Chí Mạng",      slot: "accessory", cls: null, rarity: "SSR", stats: { crit: 0.08, critDmg: 0.2 }, icon: "gem",
    passives: [{ type: "executeThreshold", value: 0.05, desc: "Kết liễu ngay quái dưới 5% máu" }]
  },
  { id: "j_ssr3",name: "Thánh Bùa Hộ Mệnh",  slot: "accessory", cls: null, rarity: "SSR", stats: { effectRes: 0.14, }, icon: "gem",
    passives: [{ type: "extraDie", value: 1, desc: "Thêm 1 cơ hội roll xúc xắc cao hơn (mana tối đa 6)" }]
  },
  { id: "j_ssr4",name: "Dây Chuyền Long Hồn", slot: "accessory", cls: null, rarity: "SSR", stats: { atk: 12, hp: 100 }, icon: "crown",
    passives: [{ type: "elementOnSkill", value: 0.2, desc: "20% tỉ lệ đóng băng mục tiêu khi ra kỹ năng" }]
  },
];

export const ITEM_DEFS: ItemDef[] = ITEMS.map((item) => ({
  id: item.id,
  name: item.name,
  slot: item.slot,
  cls: item.cls,
  rarity: item.rarity,
  stats: item.stats,
  icon: item.icon,
  passives: item.passives,
}));

export const ITEM_MAP = new Map(ITEM_DEFS.map((i) => [i.id, i]));

export function itemDef(id: string): ItemDef {
  const d = ITEM_MAP.get(id);
  if (!d) throw new Error("unknown item " + id);
  return d;
}

// rơi đồ: chọn rarity theo trọng số rồi chọn đều trong pool --------------------
export function rollItemDefId(weights: [number, number, number], rand: () => number): string | null {
  const [wr, wsr, wssr] = weights;
  const total = wr + wsr + wssr;
  if (total <= 0) return null;
  let roll = rand() * total;
  const rarity: Rarity = roll < wr ? "R" : (roll -= wr) < wsr ? "SR" : "SSR";
  const pool = ITEM_DEFS.filter((d) => d.rarity === rarity);
  if (pool.length === 0) return null;
  return pool[Math.floor(rand() * pool.length)].id;
}

export const SLOT_LABEL: Record<ItemSlot, string> = {
  weapon: "Vũ Khí",
  armor: "Giáp",
  accessory: "Trang Sức",
};
