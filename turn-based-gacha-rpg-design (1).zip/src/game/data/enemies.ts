// ============================================================================
// Quái vật + 10 ải chiến đấu (3 vùng)
// ============================================================================
import type { EnemyDef, StageDef } from "../types";
import { ENEMY_ART, ENEMY_BODY_ART } from "../art";

export const ENEMIES: EnemyDef[] = [
  { id: "slime",    name: "Slime Xanh",      role: "bruiser", statProfile: "tank",     mult: 0.5,  element: "neutral", icon: "droplets",        skills: ["splash"] },
  { id: "wolf",     name: "Sói Rừng",        role: "bruiser", statProfile: "attacker", mult: 0.55, element: "neutral", icon: "dog",             skills: ["flurry", "slash"] },
  { id: "spider",   name: "Nhện Độc",        role: "caster",  statProfile: "attacker", mult: 0.55, element: "nature",  icon: "bug",             skills: ["poisonHit", "slash"] },
  { id: "wisp",     name: "U Linh",          role: "caster",  statProfile: "support",  mult: 0.55, element: "dark",    icon: "ghost",           skills: ["drain", "weaken"] },
  { id: "skeleton", name: "Lính Xương",      role: "bruiser", statProfile: "attacker", mult: 0.6,  element: "dark",    icon: "skull",           skills: ["heavy", "slash"] },
  { id: "cultist",  name: "Đồ Tể Tà Giáo",   role: "healer",  statProfile: "support",  mult: 0.55, element: "dark",    icon: "sparkles",        skills: ["heal", "weaken"] },
  { id: "golem",    name: "Golem Đá",        role: "guard",   statProfile: "tank",     mult: 0.7,  element: "neutral", icon: "mountain",        skills: ["taunt", "heavy"] },
  { id: "treant",   name: "Mộc Tinh Cổ Thụ", role: "guard",   statProfile: "tank",     mult: 0.75, element: "nature",  icon: "tree-pine",       skills: ["taunt", "regen", "splash"] },
  { id: "roc",      name: "Chim Lôi Điện",   role: "caster",  statProfile: "attacker", mult: 0.6,  element: "thunder", icon: "cloud-lightning", skills: ["shockHit", "storm"] },
  { id: "drake",    name: "Hỏa Long Con",    role: "caster",  statProfile: "attacker", mult: 0.65, element: "fire",    icon: "flame",           skills: ["burnHit", "meteor"] },
  { id: "frostowl", name: "Cú Băng Giá",     role: "caster",  statProfile: "attacker", mult: 0.6,  element: "ice",     icon: "bird",            skills: ["frostHit", "blizzard"] },
  { id: "priest",   name: "Tế Sương Hắc Ám", role: "healer",  statProfile: "support",  mult: 0.6,  element: "dark",    icon: "moon",            skills: ["healAll", "cleanseT", "drain"] },
  { id: "knight",   name: "Hiệp Sĩ Sa Ngã",  role: "guard",   statProfile: "tank",     mult: 0.72, element: "dark",    icon: "shield",          skills: ["taunt", "sunder", "heavy"] },
  { id: "banshee",  name: "Bóng Ma Khóc",    role: "caster",  statProfile: "support",  mult: 0.62, element: "ice",     icon: "ghost",           skills: ["frostHit", "weaken", "blizzard"] },
];

// boss
export const BOSSES: EnemyDef[] = [
  { id: "boss_golem",  name: "Cổ Thạch Vương",    role: "boss", statProfile: "tank",     mult: 1.05, element: "neutral", icon: "mountain", skills: ["taunt", "heavy", "splash", "bulwark"] },
  { id: "boss_treant", name: "Thực Thự Cổ Thụ",   role: "boss", statProfile: "tank",     mult: 1.0,  element: "nature",  icon: "tree-pine", skills: ["plague", "taunt", "regen", "splash"] },
  { id: "boss_king",   name: "Ma Vương Thất Lạc", role: "boss", statProfile: "attacker", mult: 1.15, element: "dark",    icon: "crown",    skills: ["meteor", "blizzard", "drain", "warcry", "weaken"] },
];

// Gán art placeholder (nếu có) — quái chưa có ảnh sẽ fallback icon khi render.
for (const e of [...ENEMIES, ...BOSSES]) {
  e.art = ENEMY_ART[e.id];
  e.bodyArt = ENEMY_BODY_ART[e.id];
}

export const ENEMY_MAP = new Map([...ENEMIES, ...BOSSES].map((e) => [e.id, e]));

export const STAGES: StageDef[] = [
  {
    id: "s1", idx: 0, name: "Biên Rừng", zone: "Rừng U Lục", recLevel: 1, skillLv: 1,
    waves: [[{ enemy: "slime", level: 1 }, { enemy: "slime", level: 1 }]],
    gold: 90, exp: 55, gemsFirst: 120, dropRolls: 1, rarityW: [82, 16, 2],
  },
  {
    id: "s2", idx: 1, name: "Đường Mòn Sói", zone: "Rừng U Lục", recLevel: 2, skillLv: 1,
    waves: [
      [{ enemy: "slime", level: 2 }, { enemy: "wolf", level: 2 }],
      [{ enemy: "wolf", level: 2 }, { enemy: "wolf", level: 2 }],
    ],
    gold: 120, exp: 75, gemsFirst: 140, dropRolls: 1, rarityW: [80, 18, 2],
  },
  {
    id: "s3", idx: 2, name: "Tổ Nhện Độc", zone: "Rừng U Lục", recLevel: 4, skillLv: 2,
    waves: [
      [{ enemy: "spider", level: 3 }, { enemy: "slime", level: 3 }, { enemy: "spider", level: 3 }],
      [{ enemy: "boss_treant", level: 5 }],
    ],
    gold: 160, exp: 100, gemsFirst: 170, dropRolls: 2, rarityW: [76, 21, 3],
  },
  {
    id: "s4", idx: 3, name: "Hang Đá Vực", zone: "Vực Đá Gió", recLevel: 6, skillLv: 2,
    waves: [
      [{ enemy: "wolf", level: 5 }, { enemy: "wisp", level: 5 }, { enemy: "wisp", level: 5 }],
      [{ enemy: "golem", level: 6 }, { enemy: "wolf", level: 5 }],
    ],
    gold: 210, exp: 135, gemsFirst: 200, dropRolls: 2, rarityW: [72, 25, 3],
  },
  {
    id: "s5", idx: 4, name: "Tổ Chim Sấm", zone: "Vực Đá Gió", recLevel: 8, skillLv: 3,
    waves: [
      [{ enemy: "roc", level: 7 }, { enemy: "spider", level: 7 }, { enemy: "spider", level: 7 }],
      [{ enemy: "roc", level: 8 }, { enemy: "roc", level: 8 }, { enemy: "golem", level: 8 }],
    ],
    gold: 280, exp: 180, gemsFirst: 240, dropRolls: 2, rarityW: [68, 28, 4],
  },
  {
    id: "s6", idx: 5, name: "Đền Thờ Đổ Nát", zone: "Vực Đá Gió", recLevel: 10, skillLv: 3,
    waves: [
      [{ enemy: "cultist", level: 9 }, { enemy: "skeleton", level: 9 }, { enemy: "skeleton", level: 9 }],
      [{ enemy: "boss_golem", level: 11 }, { enemy: "wisp", level: 9 }],
    ],
    gold: 360, exp: 240, gemsFirst: 300, dropRolls: 3, rarityW: [62, 32, 6],
  },
  {
    id: "s7", idx: 6, name: "Cánh Đồng Sương", zone: "Thánh Địa Sa Ngã", recLevel: 13, skillLv: 3,
    waves: [
      [{ enemy: "frostowl", level: 12 }, { enemy: "frostowl", level: 12 }, { enemy: "wisp", level: 12 }],
      [{ enemy: "knight", level: 13 }, { enemy: "frostowl", level: 13 }, { enemy: "cultist", level: 13 }],
    ],
    gold: 460, exp: 320, gemsFirst: 360, dropRolls: 3, rarityW: [56, 36, 8],
  },
  {
    id: "s8", idx: 7, name: "Hành Lang Lửa Đỏ", zone: "Thánh Địa Sa Ngã", recLevel: 16, skillLv: 4,
    waves: [
      [{ enemy: "priest", level: 15 }, { enemy: "skeleton", level: 15 }, { enemy: "skeleton", level: 15 }],
      [{ enemy: "drake", level: 16 }, { enemy: "drake", level: 16 }, { enemy: "wisp", level: 16 }],
    ],
    gold: 590, exp: 420, gemsFirst: 430, dropRolls: 3, rarityW: [48, 42, 10],
  },
  {
    id: "s9", idx: 8, name: "Đại Sảnh Sa Ngã", zone: "Thánh Địa Sa Ngã", recLevel: 20, skillLv: 4,
    waves: [
      [{ enemy: "knight", level: 19 }, { enemy: "priest", level: 19 }, { enemy: "roc", level: 19 }],
      [{ enemy: "knight", level: 20 }, { enemy: "drake", level: 20 }, { enemy: "frostowl", level: 20 }, { enemy: "priest", level: 20 }],
    ],
    gold: 760, exp: 560, gemsFirst: 520, dropRolls: 4, rarityW: [40, 45, 15],
  },
  {
    id: "s10", idx: 9, name: "Ngai Ma Vương", zone: "Thánh Địa Sa Ngã", recLevel: 25, skillLv: 5,
    waves: [
      [{ enemy: "knight", level: 24 }, { enemy: "banshee", level: 24 }, { enemy: "priest", level: 24 }],
      [{ enemy: "boss_king", level: 27 }, { enemy: "banshee", level: 25 }, { enemy: "knight", level: 25 }],
    ],
    gold: 1000, exp: 750, gemsFirst: 800, dropRolls: 5, rarityW: [30, 50, 20],
  },
];

export const STAGE_MAP = new Map(STAGES.map((s) => [s.id, s]));
