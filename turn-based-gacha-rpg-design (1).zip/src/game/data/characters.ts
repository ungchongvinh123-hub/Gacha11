// ============================================================================
// 30 nhân vật — 3 class × (4 R, 4 SR, 2 SSR)
// ============================================================================
import type { BaseStats, CharDef, ClassId, Element, Growth, Rarity } from "../types";
import { buildKit, hashStr, mulberry32 } from "./skills";
import { CHAR_ART, CHAR_BODY_ART } from "../art";

export const CLASS_BASE: Record<ClassId, BaseStats> = {
  tank:     { hp: 330, atk: 22, def: 30, dice: 2, crit: 0.05, critDmg: 1.5, effectRes: 0.10, aggro: 5 },
  attacker: { hp: 205, atk: 39, def: 15, dice: 2, crit: 0.15, critDmg: 1.6, effectRes: 0.05, aggro: 2 },
  support:  { hp: 225, atk: 25, def: 17, dice: 3, crit: 0.05, critDmg: 1.5, effectRes: 0.15, aggro: 1.6 },
};

export const CLASS_GROWTH: Record<ClassId, Growth> = {
  tank:     { hp: 36, atk: 2.1, def: 3.4, dice: 0 },
  attacker: { hp: 21, atk: 4.2, def: 1.4, dice: 0 },
  support:  { hp: 23, atk: 2.5, def: 1.7, dice: 0 },
};

const RARITY_MULT: Record<Rarity, number> = { R: 1, SR: 1.14, SSR: 1.3 };

type Row = [id: string, name: string, title: string, cls: ClassId, rar: Rarity, elem: Element, icon: string];

const ROWS: Row[] = [
  // ------------------------------ ĐỠ ĐÒN -----------------------------------
  ["brom",     "Brom",     "Khiên Đồng",          "tank", "R",   "neutral", "mountain"],
  ["kaya",     "Kaya",     "Tảng Băng Trầm Lặng", "tank", "R",   "ice",     "shield-half"],
  ["odo",      "Odo",      "Rễ Cây Bất Diệt",     "tank", "R",   "nature",  "tree-pine"],
  ["grull",    "Grull",    "Chảo Lửa Thạch",      "tank", "R",   "fire",    "flame"],
  ["raksa",    "Raksa",    "Tháp Canh Sấm",       "tank", "SR",  "thunder", "cloud-lightning"],
  ["serah",    "Serah",    "Kỵ Sĩ Thánh Quang",   "tank", "SR",  "holy",    "sun"],
  ["vega",     "Vega",     "Tuần Dạ Hành Giả",    "tank", "SR",  "dark",    "moon"],
  ["dainn",    "Dainn",    "Búa Tạ Đại Ngàn",     "tank", "SR",  "neutral", "hammer"],
  ["aurelion", "Aurelion", "Long Tường Hoàng Kim","tank", "SSR", "holy",    "crown"],
  ["noxia",    "Noxia",    "Vực Thẳm Bất Tử",     "tank", "SSR", "dark",    "skull"],

  // ------------------------------ TẤN CÔNG ----------------------------------
  ["kael",     "Kael",     "Lưỡi Kiếm Lang Bạt",  "attacker", "R",   "neutral", "sword"],
  ["lira",     "Lira",     "Tia Nắng Cung Thủ",   "attacker", "R",   "holy",    "target"],
  ["piko",     "Piko",     "Song Đao Cuồng Phong","attacker", "R",   "neutral", "wind"],
  ["zeri",     "Zeri",     "Móng Vuốt Độc",       "attacker", "R",   "nature",  "bug"],
  ["ember",    "Ember",    "Hỏa Miêu Cuồng Nộ",   "attacker", "SR",  "fire",    "flame"],
  ["frost",    "Frost",    "Hàn Đao Vô Tình",     "attacker", "SR",  "ice",     "snowflake"],
  ["volka",    "Volka",    "Lôi Ảnh Tốc Hành",    "attacker", "SR",  "thunder", "zap"],
  ["shiro",    "Shiro",    "Dạ Hành Kiếm",        "attacker", "SR",  "dark",    "moon-star"],
  ["ignis",    "Ignis",    "Long Diễm Phán Quyết","attacker", "SSR", "fire",    "sun"],
  ["selene",   "Selene",   "Nguyệt Quang Sát",    "attacker", "SSR", "dark",    "moon"],

  // ------------------------------ HỖ TRỢ ------------------------------------
  ["mio",      "Mio",      "Tiếng Chuông Chữa Lành","support", "R",   "holy",    "heart"],
  ["toto",     "Toto",     "Nấm Lùng Dược Sĩ",    "support", "R",   "nature",  "mushroom"],
  ["rin",      "Rin",      "Vu Nữ Cơn Mưa",       "support", "R",   "ice",     "droplets"],
  ["pika",     "Pika",     "Tinh Linh Ánh Sáng",  "support", "R",   "holy",    "sparkles"],
  ["bibi",     "Bibi",     "Mèo Phù Thủy",        "support", "SR",  "dark",    "cat"],
  ["ola",      "Ola",      "Mục Sư Đại Dương",    "support", "SR",  "ice",     "anchor"],
  ["hana",     "Hana",     "Hoa Hồng Gai",        "support", "SR",  "nature",  "flower"],
  ["kira",     "Kira",     "Thiên Sứ Chiến Trường","support", "SR",  "holy",    "cross"],
  ["yume",     "Yume",     "Mộng Huyễn Khúc",     "support", "SSR", "dark",    "music"],
  ["sol",      "Sol",      "Thái Dương Thần Quan","support", "SSR", "holy",    "sunrise"],
];

function buildDef(row: Row): CharDef {
  const [id, name, title, classId, rarity, element, icon] = row;
  const rand = mulberry32(hashStr("stat:" + id));
  const jit = () => 0.94 + rand() * 0.12;
  const m = RARITY_MULT[rarity];
  const cb = CLASS_BASE[classId];
  const cg = CLASS_GROWTH[classId];
  const base: BaseStats = {
    hp: Math.round(cb.hp * m * jit()),
    atk: Math.round(cb.atk * m * jit()),
    def: Math.round(cb.def * m * jit()),
    dice: cb.dice + (rarity === "SSR" ? 1 : 0),
    crit: cb.crit,
    critDmg: cb.critDmg,
    effectRes: cb.effectRes + (rarity === "SSR" ? 0.05 : rarity === "SR" ? 0.02 : 0),
    aggro: cb.aggro,
  };
  const growth: Growth = {
    hp: Math.round(cg.hp * m),
    atk: Math.round(cg.atk * m * 10) / 10,
    def: Math.round(cg.def * m * 10) / 10,
    dice: 0,
  };
  const proto = { id, classId, element, rarity };
  return {
    id,
    name,
    title,
    classId,
    rarity,
    element,
    icon,
    art: CHAR_ART[id],
    bodyArt: CHAR_BODY_ART[id],
    base,
    growth,
    skills: buildKit(proto),
  };
}

export const CHARACTERS: CharDef[] = ROWS.map(buildDef);
export const CHAR_MAP = new Map(CHARACTERS.map((c) => [c.id, c]));

export function charDef(id: string): CharDef {
  const c = CHAR_MAP.get(id);
  if (!c) throw new Error("unknown char " + id);
  return c;
}

export function gachaPoolByRarity(): Record<Rarity, CharDef[]> {
  return {
    R: CHARACTERS.filter((c) => c.rarity === "R"),
    SR: CHARACTERS.filter((c) => c.rarity === "SR"),
    SSR: CHARACTERS.filter((c) => c.rarity === "SSR"),
  };
}

// starter pack cho ngưỡi chơi mới
export const STARTER_IDS = ["brom", "kael", "mio"];
