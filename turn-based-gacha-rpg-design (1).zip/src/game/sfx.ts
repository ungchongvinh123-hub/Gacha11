// WebAudio mini-synth — không cần file nhạc ngoài
let ctx: AudioContext | null = null;
let enabled = true;

export function setSfxEnabled(v: boolean) {
  enabled = v;
}

function ac(): AudioContext | null {
  if (!enabled || typeof window === "undefined") return null;
  try {
    if (!ctx) ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    if (ctx.state === "suspended") void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

function tone(freq: number, dur: number, type: OscillatorType, vol: number, slideTo?: number, delay = 0) {
  const c = ac();
  if (!c) return;
  const o = c.createOscillator();
  const g = c.createGain();
  const t0 = c.currentTime + delay;
  o.type = type;
  o.frequency.setValueAtTime(freq, t0);
  if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
  g.gain.setValueAtTime(0, t0);
  g.gain.linearRampToValueAtTime(vol, t0 + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g).connect(c.destination);
  o.start(t0);
  o.stop(t0 + dur + 0.02);
}

export type SfxName =
  | "click" | "hit" | "crit" | "heal" | "buff" | "burn" | "freeze" | "shock" | "poison"
  | "gacha" | "rare" | "ssr" | "victory" | "defeat" | "levelup" | "equip" | "coin";

export function sfx(name: SfxName) {
  if (!enabled) return;
  switch (name) {
    case "click": tone(660, 0.06, "triangle", 0.12); break;
    case "hit": tone(180, 0.12, "square", 0.18, 90); break;
    case "crit": tone(320, 0.16, "sawtooth", 0.22, 90); tone(90, 0.14, "square", 0.2, 60); break;
    case "heal": tone(520, 0.14, "sine", 0.14, 780); tone(660, 0.18, "sine", 0.1, 990, 0.08); break;
    case "buff": tone(440, 0.1, "triangle", 0.12, 660); tone(550, 0.12, "triangle", 0.1, 880, 0.07); break;
    case "burn": tone(140, 0.2, "sawtooth", 0.1, 70); break;
    case "freeze": tone(880, 0.18, "sine", 0.1, 440); break;
    case "shock": tone(1200, 0.08, "square", 0.1, 300); tone(900, 0.08, "square", 0.08, 200, 0.06); break;
    case "poison": tone(240, 0.18, "triangle", 0.1, 120); break;
    case "gacha": tone(392, 0.1, "triangle", 0.14, 523); tone(523, 0.12, "triangle", 0.14, 784, 0.09); break;
    case "rare": tone(523, 0.1, "triangle", 0.14, 659); tone(659, 0.12, "triangle", 0.14, 988, 0.09); tone(988, 0.2, "sine", 0.1, 1318, 0.18); break;
    case "ssr":
      [523, 659, 784, 1046, 1318].forEach((f, i) => tone(f, 0.22, "triangle", 0.14, f * 1.01, i * 0.09));
      break;
    case "victory": [392, 523, 659, 784].forEach((f, i) => tone(f, 0.25, "triangle", 0.16, undefined, i * 0.12)); break;
    case "defeat": [440, 349, 262, 196].forEach((f, i) => tone(f, 0.3, "sine", 0.14, undefined, i * 0.16)); break;
    case "levelup": [523, 784, 1046].forEach((f, i) => tone(f, 0.16, "triangle", 0.13, undefined, i * 0.08)); break;
    case "equip": tone(500, 0.08, "square", 0.1, 800); break;
    case "coin": tone(990, 0.07, "square", 0.09, 1320); break;
  }
}
