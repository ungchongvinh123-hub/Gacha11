"use client";

import { create } from "zustand";
import type { CharacterInstance, GameState, ItemInstance, PlayerState } from "./types";

export type View = "home" | "summon" | "roster" | "team" | "stages" | "inventory" | "battle" | "shop";

export interface Toast {
  id: number;
  msg: string;
  kind: "info" | "error" | "success";
}

interface Store {
  loaded: boolean;
  player: PlayerState | null;
  characters: CharacterInstance[];
  items: ItemInstance[];
  view: View;
  battleStageId: string | null;
  toasts: Toast[];
  fetchState: () => Promise<void>;
  mutate: <T = unknown>(type: string, payload?: Record<string, unknown>) => Promise<T>;
  setView: (v: View) => void;
  startBattle: (stageId: string) => void;
  toast: (msg: string, kind?: Toast["kind"]) => void;
}

let toastId = 0;

export const useGame = create<Store>((set, get) => ({
  loaded: false,
  player: null,
  characters: [],
  items: [],
  view: "home",
  battleStageId: null,
  toasts: [],

  async fetchState() {
    const res = await fetch("/api/state", { cache: "no-store" });
    if (!res.ok) throw new Error("Không tải được dữ liệu");
    const data = (await res.json()) as GameState;
    set({ player: data.player, characters: data.characters, items: data.items, loaded: true });
  },

  async mutate<T>(type: string, payload: Record<string, unknown> = {}): Promise<T> {
    const res = await fetch("/api/mutate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type, ...payload }),
    });
    const data = await res.json();
    if (!res.ok) {
      get().toast(data.error ?? "Có lỗi xảy ra", "error");
      throw new Error(data.error ?? "error");
    }
    await get().fetchState();
    return data as T;
  },

  setView(v) {
    set({ view: v });
  },
  startBattle(stageId) {
    set({ battleStageId: stageId, view: "battle" });
  },
  toast(msg, kind = "info") {
    const id = ++toastId;
    set((s) => ({ toasts: [...s.toasts, { id, msg, kind }] }));
    setTimeout(() => {
      set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) }));
    }, 3200);
  },
}));
