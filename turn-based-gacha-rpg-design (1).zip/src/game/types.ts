// ============================================================================
// TRIỆU HỒI KỶ NGUYÊN — shared game types (client + server safe)
// ============================================================================

export type ClassId = "tank" | "attacker" | "support";
export type Rarity = "R" | "SR" | "SSR";
export type Element =
  | "fire"
  | "ice"
  | "nature"
  | "thunder"
  | "holy"
  | "dark"
  | "neutral";

export type EffectType =
  | "burn" // lửa — DoT mạnh theo lượt
  | "poison" // độc — DoT nhẹ + giảm công/thủ
  | "freeze" // đóng băng — khoá lượt
  | "shock" // tê liệt — khoá skill, chỉ đánh thường
  | "regen" // hồi máu theo lượt
  | "atkUp"
  | "defUp"
  | "atkDown"
  | "defDown"
  | "shield" // khiên hấp thụ
  | "taunt" // khiêu khích
  | "manaRegenUp" // tăng hồi mana
  | "maxManaUp"; // tăng mana tối đa

export const DEBUFF_TYPES: EffectType[] = [
  "burn",
  "poison",
  "freeze",
  "shock",
  "atkDown",
  "defDown",
];

export interface StatusEffect {
  type: EffectType;
  turns: number; // số lượt (phase của phe mình) còn lại
  power: number; // DoT/regen/shield: giá trị phẳng đã tính sẵn; buff: phần trăm (0.3 = 30%)
  sourceUid?: string;
}

export type SkillTarget = "enemy" | "enemies" | "ally" | "allies" | "self" | "deadAlly";
export type SkillType = "damage" | "heal" | "buff" | "debuff" | "special";

/**
 * Loại cử chỉ QTE — khớp ý nghĩa từng skill (skill ko đánh dấu = không có QTE).
 * - tap:     bấm liên tục, tối đa 10 lần.
 * - connect: nối 3 điểm ngẫu nhiên trên màn.
 * - charge:  vòng tròn tụ lực, bấm đúng lúc khớp vòng đích.
 */
export type QteKind = "tap" | "connect" | "charge";

export interface SkillEffectDef {
  type: EffectType;
  chance: number[]; // 5 mức
  turns: number[];
  power: number[]; // DoT/buff theo hệ số (x Tấn công hoặc %), tuỳ loại
}

export interface SkillDef {
  id: string; // `${charId}:${key}`
  key: string;
  name: string;
  type: SkillType;
  target: SkillTarget;
  icon: string;
  element: Element;
  tier: 0 | 1 | 2;
  /** Chi phí XÚC XẮC theo 5 cấp (giảm khi lên cấp skill) — mỗi lượt roll ra bao
   *  nhiêu điểm thì dùng được skill có cost ≤ điểm đó. Đánh thường = 0. */
  cost: number[];
  /** Chỉ MỘT SỐ skill có QTE; loại QTE khớp bản chất skill (đánh dấu ở template).
   *  undefined = skill này dùng thẳng, không QTE. */
  qte?: QteKind;
  power: number[]; // hệ số chính (x Tấn công) hoặc % tuỳ special
  hits?: number;
  splashPower?: number; // hệ số lan sang mục tiêu kề
  pierce?: number; // bỏ qua % phòng thủ
  effects?: SkillEffectDef[];
  special?:
    | "taunt"
    | "cleanse"
    | "revive"
    | "manaGift"
    | "manaSpring"
    | "lifesteal"
    | "execute"
    | "shield"
    | "regen";
}

export interface BaseStats {
  hp: number;
  atk: number;
  def: number;
  /** Số viên xúc xắc 6 mặt tung mỗi lượt hành động (tổng điểm = năng lượng dùng skill) */
  dice: number;
  crit: number; // 0.05 = 5%
  critDmg: number; // 1.5 = 150%
  effectRes: number; // 0.1 = kháng 10% hiệu ứng
  aggro: number; // trọng số bị nhắm (tank cao)
}

export interface Growth {
  hp: number;
  atk: number;
  def: number;
  dice: number;
}

/**
 * Các trạng thái hoạt hình của model 2D (nhân vật lẫn quái) trong chiến đấu.
 * Mỗi state = 1 danh sách frame ảnh (xem src/game/art.ts → CHAR_ANIM).
 */
export type UnitPose = "idle" | "attack" | "cast" | "hit" | "die";

export interface CharDef {
  id: string;
  name: string;
  title: string;
  classId: ClassId;
  rarity: Rarity;
  element: Element;
  icon: string; // icon lucide dự phòng khi chưa có art
  /** Ảnh chân dung vuông (dùng roster, gacha, đội hình) — art 2D thật sau này. */
  art?: string;
  /**
   * Ảnh TOÀN THÂN (full-body) dùng trong chiến đấu. Chưa có → fallback về `art`.
   * Model 2D toàn thân thường là 1 file .png nền trong suốt, kích thước ví dụ 512x768.
   * Có `bodyArt` rồi thì mới tính tới animation frame (xem ART_PIPELINE.md).
   */
  bodyArt?: string;
  base: BaseStats;
  growth: Growth;
  skills: SkillDef[]; // DEFAULT_KIT_SIZE kỹ năng (20)
}

// ------------------------------- Items ------------------------------------

export type ItemSlot = "weapon" | "armor" | "accessory";

export interface StatBonus {
  hp?: number;
  hpPct?: number;
  atk?: number;
  atkPct?: number;
  def?: number;
  defPct?: number;
  /** +số viên xúc xắc khi hành động (hệ xúc xắc mới) */
  dice?: number;
  crit?: number;
  critDmg?: number;
  effectRes?: number;
}

export interface ItemPassive {
  type: "healOnKill" | "executeThreshold" | "elementOnSkill" | "extraDie";
  value: number;
  desc: string;
}

export interface ItemDef {
  id: string;
  name: string;
  slot: ItemSlot;
  cls: ClassId | null; // null = dùng chung
  rarity: Rarity;
  stats: StatBonus;
  icon: string;
  /**
   * Danh sách Nội tại (passive) — 1 trang bị có thể mang NHIỀU công dụng.
   * Mở rộng tương lai: chỉ cần thêm phần tử vào mảng + thêm case trong
   * BattleEngine.resolveItemPassives (engine/battle.ts) mà không đụng UI.
   */
  passives?: ItemPassive[];
}

// -------------------------- Persistent state -------------------------------

export interface CharacterInstance {
  id: number;
  defId: string;
  level: number;
  exp: number;
  spentPoints: number;
  skillLevels: Record<string, number>;
  loadout: string[]; // tối đa 3 skill id mang vào trận
}

export interface ItemInstance {
  id: number;
  defId: string;
  equippedBy: number | null;
  level: number; // cấp cường hóa: 0, 1, 2...
}

export interface PlayerState {
  id: number;
  name: string;
  gold: number;
  gems: number;
  team: number[];
  cleared: string[];
}

export interface GameState {
  player: PlayerState;
  characters: CharacterInstance[];
  items: ItemInstance[];
}

// ------------------------------ Enemies ------------------------------------

export type EnemyRole = "bruiser" | "guard" | "caster" | "healer" | "boss";

export interface EnemyDef {
  id: string;
  name: string;
  role: EnemyRole;
  statProfile: ClassId; // dùng hệ số theo class
  mult: number; // nhân chỉ số tổng
  element: Element;
  icon: string; // icon lucide dự phòng
  art?: string; // ảnh đại diện vuông
  bodyArt?: string; // ảnh toàn thân dùng trong chiến đấu (fallback về art)
  skills: string[]; // template keys
}

export interface WaveSpawn {
  enemy: string;
  level: number;
}

export interface StageDef {
  id: string;
  idx: number;
  name: string;
  zone: string;
  recLevel: number;
  skillLv: number; // level skill của quái
  waves: WaveSpawn[][];
  gold: number;
  exp: number;
  gemsFirst: number;
  dropRolls: number;
  rarityW: [number, number, number]; // trọng số R/SR/SSR khi rơi đồ
}

// ------------------------------ Constants ----------------------------------

export const MAX_LEVEL = 50;
export const GACHA_COST = 160;
export const GACHA_RATES = { SSR: 0.03, SR: 0.17, R: 0.8 } as const;

/**
 * ==== KNOBS MỞ RỘNG ====
 * Muốn đổi luật chơi về sau, chỉ cần sửa 1 dòng tại đây, toàn bộ engine + UI
 * tự động tuân theo (không phải lần mò tìm chỗ hardcode):
 */
export const MAX_LOADOUT = 6; // số skill mang vào trận (đánh thường miễn phí + 6 skill)
export const MAX_SKILL_LEVEL = 5; // số cấp tối đa cho 1 kỹ năng
export const DEFAULT_KIT_SIZE = 20; // số skill trong skill tree mỗi tướng (bộ sinh đã tham số hóa)

export function expForLevel(level: number): number {
  return 40 + level * level * 12 + level * 14;
}

// ------------------------------ Vietnamese ---------------------------------

export const CLASS_LABEL: Record<ClassId, string> = {
  tank: "Đỡ Đòn",
  attacker: "Tấn Công",
  support: "Hỗ Trợ",
};

export const ELEMENT_LABEL: Record<Element, string> = {
  fire: "Lửa",
  ice: "Băng",
  nature: "Tự Nhiên",
  thunder: "Sấm Sét",
  holy: "Thánh",
  dark: "Hắc Ám",
  neutral: "Vô Thuộc Tính",
};

export const EFFECT_LABEL: Record<EffectType, string> = {
  burn: "Thiêu Đốt",
  poison: "Trúng Độc",
  freeze: "Đóng Băng",
  shock: "Tê Liệt",
  regen: "Hồi Phục",
  atkUp: "Tăng Công",
  defUp: "Tăng Thủ",
  atkDown: "Giảm Công",
  defDown: "Giảm Thủ",
  shield: "Khiên Chắn",
  taunt: "Khiêu Khích",
  manaRegenUp: "Hồi Mana+",
  maxManaUp: "Mana Tối Đa+",
};

export const ELEMENT_COLORS: Record<Element, [string, string]> = {
  fire: ["#7c2d12", "#f97316"],
  ice: ["#0c4a6e", "#38bdf8"],
  nature: ["#14532d", "#4ade80"],
  thunder: ["#713f12", "#facc15"],
  holy: ["#78350f", "#fcd34d"],
  dark: ["#3b0764", "#a78bfa"],
  neutral: ["#1f2937", "#9ca3af"],
};

export const RARITY_COLORS: Record<Rarity, string> = {
  R: "#38bdf8",
  SR: "#c084fc",
  SSR: "#fbbf24",
};
