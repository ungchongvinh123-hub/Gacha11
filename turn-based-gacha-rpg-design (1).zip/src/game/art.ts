import type { UnitPose } from "./types";

// ============================================================================
// ART PIPELINE — nơi duy nhất khai báo ảnh cho nhân vật & quái vật
// ============================================================================
// MỤC TIÊU SAU NÀY: "model nhân vật 2D toàn thân" (full-body sprite)
// với animation: idle (đứng), attack/cast (tung skill), hit (trúng đòn),
// trúng hiệu ứng (burn/freeze/shock/poison overlay), die (chết)…
//
// CÁCH LÀM (2 trường phái, xem ART_PIPELINE.md ở gốc project để biết chi tiết):
//   A) FRAME-BASED: 1 chuỗi ảnh đứng yên mỗi trạng thái (như JRPG cổ điển):
//        /public/units/characters/{id}/idle_0.png, attack_0.png, cast_0.png, hit_0.png, die_0.png
//   B) SKELETAL 2D (Spine/DragonBones/Live2D): 1 file rig + texture, xương quay/gập
//      cho phép 1 bộ art sinh ra vô số animation — chuẩn của gacha anime hiện đại.
//
// CODE ĐÃ SẴN SÀNG:
//   - BattleEngine trả event stream: {t:'action'} / {t:'dmg'} / {t:'dot'} / {t:'effect'} / died
//   - Component UnitFigure (src/components/UnitFigure.tsx) nhận `pose` + hiệu ứng
//     để bật animation tương ứng — xem battle screen.
//   - Muốn xài skeleton: đặt file rig rồi thay component render bằng player lib,
//     KHÔNG đụng engine chiến đấu (vì engine thuần logic, tách khỏi hiển thị).
// ============================================================================

/** Chân dung vuông (roster, gacha, đội hình). */
export const CHAR_ART: Record<string, string> = {
  brom: "/sprites/characters/brom.png",
  kael: "/sprites/characters/kael.png",
  mio: "/sprites/characters/mio.png",
  ember: "/sprites/characters/ember.png",
  frost: "/sprites/characters/frost.png",
  sol: "/sprites/characters/sol.png",
};

/** Ảnh toàn thân cho chiến đấu — ĐANG dùng tạm chân dung; khi có art thật:
 *  đổi thành "/units/characters/{id}/body.png" (nền trong suốt, ~512x768).
 */
export const CHAR_BODY_ART: Record<string, string> = {
  brom: "/sprites/characters/brom.png",
  kael: "/sprites/characters/kael.png",
  mio: "/sprites/characters/mio.png",
  ember: "/sprites/characters/ember.png",
  frost: "/sprites/characters/frost.png",
  sol: "/sprites/characters/sol.png",
};

export const ENEMY_ART: Record<string, string> = {
  boss_treant: "/sprites/enemies/boss_treant.png",
};

export const ENEMY_BODY_ART: Record<string, string> = {
  boss_treant: "/sprites/enemies/boss_treant.png",
};

// ============================================================================
// ANIMATION FRAME — "bỏ ảnh state vào là chạy"
// Khi có art 2D thật, chỉ cần khai báo danh sách frame theo state tại đây.
// Nếu KHÔNG khai báo → UnitFigure tự fallback: ảnh toàn thân tĩnh + CSS motion.
// ============================================================================
export const CHAR_ANIM: Record<string, Partial<Record<UnitPose, string[]>>> = {
  // Ví dụ cú pháp khi art sẵn sàng (file nền trong suốt):
  // ember: {
  //   idle:   ["/units/characters/ember/idle_0.png", "/units/characters/ember/idle_1.png", "/units/characters/ember/idle_2.png"],
  //   attack: ["/units/characters/ember/attack_0.png", "/units/characters/ember/attack_1.png", "/units/characters/ember/attack_2.png"],
  //   cast:   ["/units/characters/ember/cast_0.png", "/units/characters/ember/cast_1.png"],
  //   hit:    ["/units/characters/ember/hit_0.png"],
  //   die:    ["/units/characters/ember/die_0.png", "/units/characters/ember/die_1.png"],
  // },
};

export const ENEMY_ANIM: Record<string, Partial<Record<UnitPose, string[]>>> = {};

/** Lấy chân dung vuông (undefined = chưa có → dùng icon lucide). */
export function charArt(id: string): string | undefined {
  return CHAR_ART[id];
}

/** Lấy ảnh toàn thân (undefined → fallback chân dung → icon). */
export function charBodyArt(id: string): string | undefined {
  return CHAR_BODY_ART[id] ?? CHAR_ART[id];
}

export function enemyArt(id: string): string | undefined {
  return ENEMY_ART[id];
}

export function enemyBodyArt(id: string): string | undefined {
  return ENEMY_BODY_ART[id] ?? ENEMY_ART[id];
}

/** Lấy frame animation của tướng (undefined = chưa có → dùng ảnh tĩnh). */
export function charAnimFrames(id: string): Partial<Record<UnitPose, string[]>> | undefined {
  return CHAR_ANIM[id];
}

/** Lấy frame animation của quái (undefined = chưa có → dùng ảnh tĩnh). */
export function enemyAnimFrames(id: string): Partial<Record<UnitPose, string[]>> | undefined {
  return ENEMY_ANIM[id];
}
