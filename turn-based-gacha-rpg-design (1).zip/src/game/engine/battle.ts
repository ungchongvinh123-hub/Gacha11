// ============================================================================
// Battle engine — phe A hành động hết rồi tới phe B, chọn tự do đơn vị/skill/mục tiêu
// Pure TS, mọi thay đổi trả về event để UI animate.
// ============================================================================
import type {
  BaseStats,
  CharacterInstance,
  CharDef,
  ClassId,
  EffectType,
  Element,
  EnemyRole,
  ItemInstance,
  Rarity,
  SkillDef,
  StageDef,
  StatusEffect,
  UnitPose,
  WaveSpawn,
} from "../types";
import { DEBUFF_TYPES, MAX_LOADOUT, MAX_SKILL_LEVEL } from "../types";
import { ENEMY_MAP } from "../data/enemies";
import { skillFromKey } from "../data/skills";
import { ITEM_MAP } from "../data/items";
import { CHAR_ANIM, ENEMY_ANIM } from "../art";
import { CLASS_BASE, CLASS_GROWTH } from "../data/characters";
import { computeStats } from "./stats";

// ---------------------------------------------------------------- types ----
export interface UnitSkill {
  def: SkillDef;
  lv: number; // 1..5
}

export interface BattleUnit {
  uid: string;
  side: "player" | "enemy";
  slot: number;
  name: string;
  icon: string;
  element: Element;
  classId: ClassId;
  rarity?: Rarity;
  level: number;
  stats: BaseStats;
  hp: number;
  /** Điểm xúc xắc lượt hiện tại (chỉ phe người chơi — roll khi bắt đầu hành động) */
  energy?: number;
  effects: StatusEffect[];
  alive: boolean;
  acted: boolean;
  skills: UnitSkill[];
  aiRole?: EnemyRole;
  charInstanceId?: number;
  equippedItemIds?: string[]; // Danh sách id trang bị để lấy passive trong trận
  lastSkillKey?: string; // skill quái dùng ở lượt trước (chống spam)
  art?: string; // Chân dung (fallback khi chưa có bodyArt)
  bodyArt?: string; // Ảnh toàn thân render trong chiến đấu
  animFrames?: Partial<Record<UnitPose, string[]>>; // Frame animation theo state
}

export type Action =
  | { kind: "attack"; targetUid: string }
  | { kind: "skill"; skillIdx: number; targetUid?: string };

/**
 * Ngữ cảnh QTE của 1 hành động:
 * - qteMult: hệ số sát thương khi phe người chơi tung skill (QTE tốt = 1.3, trật = 0.6)
 * - defendMult: hệ số chặn đòn khi quái tấn công (chặn chuẩn = 0.3, trật = 1.0 = ăn đủ)
 */
export interface BattleCtx {
  qteMult?: number;
  defendMult?: number;
}

/** Xác định 1 hành động có gây sát thương lên phe đối diện không (dùng cho QTE chặn). */
export function actionOffensive(u: BattleUnit, action: Action): boolean {
  if (action.kind === "attack") return true;
  const sk = u.skills[action.skillIdx];
  if (!sk) return false;
  const d = sk.def;
  return (d.type === "damage" || d.type === "debuff") && (d.target === "enemy" || d.target === "enemies");
}

export type BattleEvent =
  | { t: "phase"; side: "player" | "enemy"; round: number }
  | { t: "dot"; uid: string; amount: number; kind: "burn" | "poison"; died: boolean }
  | { t: "regenTick"; uid: string; amount: number }
  | { t: "roll"; uid: string; faces: number[]; total: number }
  | { t: "skipFrozen"; uid: string }
  | { t: "action"; uid: string; kind: "attack" | "skill"; name: string; icon: string }
  | { t: "dmg"; uid: string; amount: number; crit: boolean; absorbed: number; died: boolean; splash: boolean; elementRelation?: "strong" | "weak" | "none" }
  | { t: "block"; uid: string } // chặn đòn THÀNH CÔNG: không nhận sát thương
  | { t: "heal"; uid: string; amount: number }
  | { t: "effect"; uid: string; etype: EffectType; applied: boolean }
  | { t: "cleanse"; uid: string; count: number }
  | { t: "revive"; uid: string; amount: number }
  | { t: "noMana"; uid: string }
  | { t: "waveStart"; wave: number; total: number }
  | { t: "end"; victory: boolean };

export interface BattleStateSnapshot {
  units: BattleUnit[];
  phase: "player" | "enemy";
  round: number;
  waveIdx: number;
  totalWaves: number;
  status: "running" | "victory" | "defeat";
}

// ------------------------------------------------------------ factories ----
export function makePlayerUnit(
  inst: CharacterInstance,
  def: CharDef,
  allItems: ItemInstance[],
  slot: number,
): BattleUnit {
  const stats = computeStats(def, inst.level, allItems.filter((i) => i.equippedBy === inst.id));
  const loadout = inst.loadout.slice(0, MAX_LOADOUT);
  const skills: UnitSkill[] = loadout
    .map((sid) => {
      const sd = def.skills.find((s) => s.id === sid);
      if (!sd) return null;
      const lv = inst.skillLevels[sid] ?? 0;
      return lv > 0 ? { def: sd, lv: Math.min(MAX_SKILL_LEVEL, lv) } : null;
    })
    .filter((s): s is UnitSkill => !!s);
  const equippedGear = allItems.filter((i) => i.equippedBy === inst.id);
  return {
    uid: `p${inst.id}`,
    side: "player",
    slot,
    name: def.name,
    icon: def.icon,
    element: def.element,
    classId: def.classId,
    rarity: def.rarity,
    level: inst.level,
    stats: { hp: stats.hp, atk: stats.atk, def: stats.def, dice: stats.dice, crit: stats.crit, critDmg: stats.critDmg, effectRes: stats.effectRes, aggro: stats.aggro },
    hp: stats.hp,
    effects: [],
    alive: true,
    acted: false,
    skills,
    charInstanceId: inst.id,
    equippedItemIds: equippedGear.map((i) => i.defId),
    art: def.art,
    bodyArt: def.bodyArt ?? def.art,
    animFrames: CHAR_ANIM[def.id],
  };
}

export function makeEnemyUnit(spawn: WaveSpawn, slot: number, skillLv: number, wave: number): BattleUnit {
  const ed = ENEMY_MAP.get(spawn.enemy);
  if (!ed) throw new Error("unknown enemy " + spawn.enemy);
  const cb = CLASS_BASE[ed.statProfile];
  const cg = CLASS_GROWTH[ed.statProfile];
  const lv = spawn.level;
  const m = ed.mult;
  const stats: BaseStats = {
    hp: Math.round((cb.hp + cg.hp * (lv - 1)) * m * 0.6),
    atk: Math.round((cb.atk + cg.atk * (lv - 1)) * m * 0.9),
    def: Math.round((cb.def + cg.def * (lv - 1)) * m * 0.9),
    dice: 0,
    crit: cb.crit,
    critDmg: cb.critDmg,
    effectRes: ed.role === "boss" ? 0.35 : cb.effectRes * 0.5,
    aggro: ed.statProfile === "tank" ? 3 : 1.5,
  };
  const proto = { id: `${ed.id}${wave}${slot}`, classId: ed.statProfile, element: ed.element };
  const skills: UnitSkill[] = ed.skills.map((k) => ({ def: skillFromKey(k, proto), lv: Math.max(1, Math.min(5, skillLv)) }));
  return {
    uid: `e${wave}_${slot}`,
    side: "enemy",
    slot,
    name: ed.name,
    icon: ed.icon,
    element: ed.element,
    classId: ed.statProfile,
    level: lv,
    stats,
    hp: stats.hp,
    effects: [],
    alive: true,
    acted: false,
    skills,
    aiRole: ed.role,
    art: ed.art,
    bodyArt: ed.bodyArt ?? ed.art,
    animFrames: ENEMY_ANIM[ed.id],
  };
}

// ------------------------------------------------------------- helpers -----
const clamp = (n: number, a: number, b: number) => Math.max(a, Math.min(b, n));

export function effectsOf(u: BattleUnit, type: EffectType): StatusEffect[] {
  return u.effects.filter((e) => e.type === type);
}
export function hasEffect(u: BattleUnit, type: EffectType): boolean {
  return u.effects.some((e) => e.type === type && e.turns > 0);
}
function sumEffect(u: BattleUnit, type: EffectType): number {
  return u.effects.filter((e) => e.type === type && e.turns > 0).reduce((a, e) => a + e.power, 0);
}

export function maxHp(u: BattleUnit): number {
  return u.stats.hp;
}
/** Tổng "cơ hội xúc xắc": chỉ số dice + nội tại extraDie + hiệu ứng maxManaUp.
 *  Mỗi cơ hội = 1 lần roll lại (giữ kết quả cao hơn) — mana luôn nằm trong 1..6. */
export function diceCount(u: BattleUnit): number {
  let extra = 0;
  for (const e of u.effects) if (e.type === "maxManaUp" && e.turns > 0) extra += e.power;
  for (const id of u.equippedItemIds ?? []) {
    const item = ITEM_MAP.get(id);
    for (const p of item?.passives ?? []) if (p.type === "extraDie") extra += p.value;
  }
  return Math.max(1, u.stats.dice + Math.round(extra));
}
export function effAtk(u: BattleUnit): number {
  const poison = hasEffect(u, "poison") ? 0.12 : 0;
  const mult = 1 + sumEffect(u, "atkUp") - sumEffect(u, "atkDown") - poison;
  return Math.max(1, u.stats.atk * mult);
}
export function effDef(u: BattleUnit): number {
  const poison = hasEffect(u, "poison") ? 0.12 : 0;
  const mult = 1 + sumEffect(u, "defUp") - sumEffect(u, "defDown") - poison;
  return u.stats.def * Math.max(0.15, mult);
}
export function isShocked(u: BattleUnit): boolean {
  return hasEffect(u, "shock");
}

// ============================================================ ENGINE ========
export class BattleEngine {
  units: BattleUnit[] = [];
  phase: "player" | "enemy" = "player";
  round = 0;
  waveIdx = 0;
  status: "running" | "victory" | "defeat" = "running";
  private stage: StageDef;

  constructor(playerUnits: BattleUnit[], stage: StageDef) {
    this.stage = stage;
    this.units = [...playerUnits, ...this.spawnWave(0)];
    for (const u of playerUnits) u.acted = false;
  }

  snapshot(): BattleStateSnapshot {
    return {
      units: this.units,
      phase: this.phase,
      round: this.round,
      waveIdx: this.waveIdx,
      totalWaves: this.stage.waves.length,
      status: this.status,
    };
  }

  /**
   * Đổ xúc xắc cho 1 đơn vị phe người chơi khi bắt đầu hành động.
   * Số viên = dice (class) + trang bị extraDie + hiệu ứng tăng xúc xắc.
   * Tổng điểm = năng lượng dùng skill trong lượt này.
   */
  roll(uid: string): { faces: number[]; total: number } | null {
    const u = this.unit(uid);
    if (!u || !u.alive || u.side !== "player") return null;
    // 1 viên xúc xắc 6 mặt DUY NHẤT: mana = mặt xúc xắc (1..6), không bao giờ > 6.
    let v = 1 + Math.floor(Math.random() * 6);
    // Số "xúc xắc" cao (class hỗ trợ/SSR/trang bị) = cơ hội roll lại lấy kết quả cao hơn
    const chances = Math.max(0, diceCount(u) - 1);
    for (let i = 0; i < chances; i++) {
      if (v >= 6) break;
      const r = 1 + Math.floor(Math.random() * 6);
      if (r > v) v = r;
    }
    u.energy = v;
    return { faces: [v], total: v };
  }

  private spawnWave(idx: number): BattleUnit[] {
    const skillLv = this.stage.skillLv;
    return this.stage.waves[idx].map((sp, slot) => makeEnemyUnit(sp, slot, skillLv, idx));
  }

  side(side: "player" | "enemy"): BattleUnit[] {
    return this.units.filter((u) => u.side === side);
  }
  aliveOf(side: "player" | "enemy"): BattleUnit[] {
    return this.units.filter((u) => u.side === side && u.alive);
  }
  unit(uid: string): BattleUnit | undefined {
    return this.units.find((u) => u.uid === uid);
  }
  readyUnits(side: "player" | "enemy"): BattleUnit[] {
    return this.aliveOf(side).filter((u) => !u.acted && !hasEffect(u, "freeze"));
  }

  // ----------------------------------------------------- phase handling ----
  startSidePhase(side: "player" | "enemy"): BattleEvent[] {
    this.phase = side;
    if (side === "player") this.round++;
    // đầu hiệp phe mình: chưa ai roll xúc xắc
    for (const u of this.side("player")) if (u.alive) u.energy = undefined;
    const evs: BattleEvent[] = [{ t: "phase", side, round: this.round }];
    for (const u of this.side(side)) {
      if (!u.alive) continue;
      // tick hiệu ứng theo lượt
      for (const e of u.effects) {
        if (e.turns <= 0) continue;
        if (e.type === "burn" || e.type === "poison") {
          const dmg = Math.max(1, Math.round(e.power));
          u.hp = Math.max(0, u.hp - dmg);
          const died = u.hp <= 0;
          if (died) u.alive = false;
          evs.push({ t: "dot", uid: u.uid, amount: dmg, kind: e.type, died });
        } else if (e.type === "regen") {
          const heal = Math.min(Math.round(e.power), maxHp(u) - u.hp);
          u.hp += heal;
          if (heal > 0) evs.push({ t: "regenTick", uid: u.uid, amount: heal });
        }
      }
      if (!u.alive) continue;

      // đóng băng: khóa toàn bộ lượt
      if (hasEffect(u, "freeze")) {
        u.acted = true;
        evs.push({ t: "skipFrozen", uid: u.uid });
      } else {
        u.acted = false;
      }

      // giảm duration
      for (const e of u.effects) e.turns -= 1;
      u.effects = u.effects.filter((e) => e.turns > 0 || e.type === "shield" && e.power > 0);
      u.effects = u.effects.filter((e) => (e.type === "shield" ? e.power > 0 : e.turns > 0));
    }
    return evs;
  }

  allActed(side: "player" | "enemy"): boolean {
    return this.readyUnits(side).length === 0;
  }

  // ----------------------------------------------------------- targeting ---
  private foesOf(u: BattleUnit): BattleUnit[] {
    return this.aliveOf(u.side === "player" ? "enemy" : "player");
  }
  private alliesOf(u: BattleUnit): BattleUnit[] {
    return this.aliveOf(u.side);
  }

  validTargets(u: BattleUnit, action: Action): BattleUnit[] {
    if (action.kind === "attack") return this.foesOf(u);
    const sk = u.skills[action.skillIdx];
    if (!sk) return [];
    const t = sk.def.target;
    if (t === "enemy") return this.foesOf(u);
    if (t === "ally") return this.alliesOf(u);
    if (t === "self") return [u];
    if (t === "deadAlly") return this.side(u.side).filter((x) => !x.alive);
    return [];
  }

  needsTarget(u: BattleUnit, action: Action): boolean {
    if (action.kind === "attack") return true;
    const sk = u.skills[action.skillIdx];
    if (!sk) return false;
    return ["enemy", "ally", "deadAlly"].includes(sk.def.target);
  }

  canUseSkill(u: BattleUnit, idx: number): { ok: boolean; reason?: string } {
    const sk = u.skills[idx];
    if (!sk) return { ok: false, reason: "none" };
    if (isShocked(u)) return { ok: false, reason: "shock" };
    // Quái KHÔNG có xúc xắc — dùng skill định sẵn tự do (chỉ bị khóa bởi shock/mục tiêu)
    if (u.side === "player") {
      const cost = sk.def.cost[sk.lv - 1];
      if ((u.energy ?? 0) < cost) return { ok: false, reason: "cost" };
    }
    if (sk.def.target === "deadAlly" && this.validTargets(u, { kind: "skill", skillIdx: idx }).length === 0)
      return { ok: false, reason: "noTarget" };
    return { ok: true };
  }

  // ------------------------------------------------------------- damage ----
  private getElementMultiplier(skillElem: Element, targetElem: Element): { mult: number; relation: "strong" | "weak" | "none" } {
    // Lửa (fire) vs Băng (ice) khắc chế qua lại lẫn nhau
    if (skillElem === "fire" && targetElem === "ice") return { mult: 1.5, relation: "strong" };
    if (skillElem === "ice" && targetElem === "fire") return { mult: 1.5, relation: "strong" };

    // Sét (thunder) vs Độc (nature/Tự nhiên) khắc chế qua lại lẫn nhau
    if (skillElem === "thunder" && targetElem === "nature") return { mult: 1.5, relation: "strong" };
    if (skillElem === "nature" && targetElem === "thunder") return { mult: 1.5, relation: "strong" };

    // Khắc chế phụ: Thánh (holy) vs Hắc Ám (dark)
    if (skillElem === "holy" && targetElem === "dark") return { mult: 1.35, relation: "strong" };
    if (skillElem === "dark" && targetElem === "holy") return { mult: 1.35, relation: "strong" };

    return { mult: 1.0, relation: "none" };
  }

  private hit(
    attacker: BattleUnit,
    target: BattleUnit,
    power: number,
    pierce = 0,
    skillElement?: Element,
    qteMult = 1
  ): { amount: number; crit: boolean; relation: "strong" | "weak" | "none" } {
    if (qteMult <= 0) return { amount: 0, crit: false, relation: "none" };
    const elem = skillElement ?? attacker.element;
    const { mult, relation } = this.getElementMultiplier(elem, target.element);

    let dmg = effAtk(attacker) * power * mult * qteMult * (100 / (100 + effDef(target) * (1 - pierce)));
    const crit = Math.random() < attacker.stats.crit;
    if (crit) dmg *= attacker.stats.critDmg;
    dmg *= 0.9 + Math.random() * 0.2;
    return { amount: Math.max(1, Math.round(dmg)), crit, relation };
  }

  private dealDamage(attacker: BattleUnit, target: BattleUnit, amount: number, evs: BattleEvent[]): { dealt: number; absorbed: number; died: boolean } {
    let remaining = amount;
    let absorbed = 0;
    const shield = target.effects.find((e) => e.type === "shield" && e.power > 0);
    if (shield) {
      absorbed = Math.min(shield.power, remaining);
      shield.power -= absorbed;
      remaining -= absorbed;
      if (shield.power <= 0) target.effects = target.effects.filter((e) => e !== shield);
    }
    target.hp = Math.max(0, target.hp - remaining);
    
    // --- PASSIVE: executeThreshold (Kết liễu khi máu mục tiêu thấp dưới ngưỡng %) ---
    // NOTE: passives là mảng — 1 trang bị có thể mang nhiều nội tại, engine duyệt tất cả.
    if (target.hp > 0 && attacker.side === "player" && attacker.equippedItemIds) {
      for (const itemId of attacker.equippedItemIds) {
        const item = ITEM_MAP.get(itemId);
        for (const p of item?.passives ?? []) {
          if (p.type !== "executeThreshold") continue;
          const threshold = p.value; // Ví dụ: 0.04 (4%) hoặc 0.08 (8% máu)
          const limitHp = maxHp(target) * threshold;
          if (target.hp <= limitHp) {
            evs.push({ t: "effect", uid: target.uid, etype: "taunt", applied: true });
            remaining += target.hp; // Cộng dồn lượng sát thương kết liễu
            target.hp = 0;
            break;
          }
        }
      }
    }


    const died = target.hp <= 0;
    if (died) {
      target.alive = false;
      target.effects = [];
      
      // --- PASSIVE: healOnKill (Hồi máu khi hạ gục mục tiêu) — cộng dồn nhiều nội tại ---
      if (attacker.side === "player" && attacker.equippedItemIds && attacker.alive) {
        let totalHeal = 0;
        for (const itemId of attacker.equippedItemIds) {
          const item = ITEM_MAP.get(itemId);
          for (const p of item?.passives ?? []) {
            if (p.type !== "healOnKill") continue;
            totalHeal += Math.round(maxHp(attacker) * p.value);
          }
        }
        if (totalHeal > 0) {
          const healed = this.heal(attacker, totalHeal);
          if (healed > 0) evs.push({ t: "heal", uid: attacker.uid, amount: healed });
        }
      }
    }
    return { dealt: remaining, absorbed, died };
  }

  private heal(target: BattleUnit, amount: number): number {
    const real = Math.min(Math.round(amount), maxHp(target) - target.hp);
    target.hp += real;
    return real;
  }

  private tryEffect(
    evs: BattleEvent[],
    caster: BattleUnit,
    target: BattleUnit,
    type: EffectType,
    chance: number,
    turns: number,
    power: number,
  ) {
    const isDebuff = DEBUFF_TYPES.includes(type);
    let finalChance = chance;
    if (isDebuff) finalChance = chance * (1 - target.stats.effectRes);
    const applied = Math.random() < finalChance;
    evs.push({ t: "effect", uid: target.uid, etype: type, applied });
    if (!applied) return;
    let value = power;
    if (type === "burn" || type === "poison" || type === "regen" || type === "shield") {
      value = power * effAtk(caster); // lưu giá trị phẳng theo công của ngưởi thi triển
    }
    const existing = target.effects.find((e) => e.type === type);
    if (existing) {
      existing.turns = Math.max(existing.turns, turns);
      existing.power = Math.max(existing.power, value);
    } else {
      target.effects.push({ type, turns, power: value, sourceUid: caster.uid });
    }
  }

  // -------------------------------------------------------------- action ---
  perform(actorUid: string, action: Action, ctx?: BattleCtx): BattleEvent[] {
    if (this.status !== "running") throw new Error("trận đấu đã kết thúc");
    const actor = this.unit(actorUid);
    if (!actor || !actor.alive) throw new Error("đơn vị không hợp lệ");
    if (actor.side !== this.phase) throw new Error("chưa tới lượt");
    if (actor.acted) throw new Error("đơn vị đã hành động");
    if (hasEffect(actor, "freeze")) throw new Error("đang bị đóng băng");

    const evs: BattleEvent[] = [];

    if (action.kind === "attack") {
      const target = this.unit(action.targetUid);
      if (!target || !target.alive || target.side === actor.side) throw new Error("mục tiêu không hợp lệ");
      evs.push({ t: "action", uid: actor.uid, kind: "attack", name: "Đánh Thường", icon: "sword" });
      // Chặn THÀNH CÔNG (defendMult===0) → KHÔNG nhận sát thương, không hiệu ứng
      if (target.side === "player" && (ctx?.defendMult ?? 1) === 0) {
        evs.push({ t: "block", uid: target.uid });
      } else {
        const atkMult = target.side === "player" ? (ctx?.defendMult ?? 1) : 1;
        const { amount, crit, relation } = this.hit(actor, target, 1.0, 0, actor.element, atkMult);
        const r = this.dealDamage(actor, target, amount, evs);
        evs.push({ t: "dmg", uid: target.uid, amount: r.dealt, crit, absorbed: r.absorbed, died: r.died, splash: false, elementRelation: relation });
      }
    } else {
      const sk = actor.skills[action.skillIdx];
      if (!sk) throw new Error("skill không hợp lệ");
      const chk = this.canUseSkill(actor, action.skillIdx);
      if (!chk.ok) throw new Error("không thể dùng skill: " + chk.reason);
      const s = sk.def;
      const lv = sk.lv - 1;
      evs.push({ t: "action", uid: actor.uid, kind: "skill", name: s.name, icon: s.icon });
      // phe người chơi tiêu điểm xúc xắc đã roll; quái KHÔNG có xúc xắc (dùng tự do)
      if (actor.side === "player") {
        const cost = s.cost[lv];
        if ((actor.energy ?? 0) < cost) throw new Error("không đủ điểm xúc xắc");
        actor.energy = (actor.energy ?? 0) - cost;
      }
      actor.lastSkillKey = s.key;

      // resolve targets
      let primaries: BattleUnit[] = [];
      if (s.target === "enemies") primaries = this.foesOf(actor);
      else if (s.target === "allies") primaries = this.alliesOf(actor);
      else if (s.target === "self") primaries = [actor];
      else {
        const t = action.targetUid ? this.unit(action.targetUid) : undefined;
        if (!t) throw new Error("thiếu mục tiêu");
        if (s.target === "deadAlly") {
          if (t.alive || t.side !== actor.side) throw new Error("mục tiêu không hợp lệ");
        } else if (!t.alive) throw new Error("mục tiêu không hợp lệ");
        primaries = [t];
      }

      const power = s.power[lv] ?? 0;
      let lifestealTotal = 0;

      for (const target of primaries) {
        // Chặn THÀNH CÔNG: đòn bị đỡ hết — không dmg, không hiệu ứng, không splash
        if (target.side === "player" && (ctx?.defendMult ?? 1) === 0) {
          evs.push({ t: "block", uid: target.uid });
          continue;
        }
        // revive
        if (s.special === "revive") {
          target.alive = true;
          target.effects = [];
          target.hp = Math.round(maxHp(target) * power);
          target.energy = 0;
          target.acted = true;
          evs.push({ t: "revive", uid: target.uid, amount: target.hp });
          continue;
        }
        // sát thương chính
        if (power > 0 && (s.type === "damage" || s.type === "debuff")) {
          let pw = power;
          if (s.special === "execute" && target.hp / maxHp(target) < 0.4) pw *= 1.8;
          const hitsN = s.hits ?? 1;
          const skillMult =
            (actor.side === "player" ? ctx?.qteMult ?? 1 : 1) *
            (target.side === "player" ? ctx?.defendMult ?? 1 : 1);
          for (let h = 0; h < hitsN; h++) {
            const { amount, crit, relation } = this.hit(actor, target, pw, s.pierce ?? 0, s.element, skillMult);
            const r = this.dealDamage(actor, target, amount, evs);
            lifestealTotal += r.dealt;
            evs.push({ t: "dmg", uid: target.uid, amount: r.dealt, crit, absorbed: r.absorbed, died: r.died, splash: false, elementRelation: relation });
            if (r.died) break;
          }
          // lan sang mục tiêu kề (cả phe quái cũng như vậy)
          if (s.splashPower && target.alive !== undefined) {
            const neighbors = this.side(target.side).filter(
              (x) => x.alive && x.uid !== target.uid && Math.abs(x.slot - target.slot) === 1,
            );
            for (const nb of neighbors) {
              const nbMult =
                (actor.side === "player" ? ctx?.qteMult ?? 1 : 1) *
                (nb.side === "player" ? ctx?.defendMult ?? 1 : 1);
              const { amount, relation } = this.hit(actor, nb, pw * s.splashPower, 0, s.element, nbMult);
              const r = this.dealDamage(actor, nb, amount, evs);
              evs.push({ t: "dmg", uid: nb.uid, amount: r.dealt, crit: false, absorbed: r.absorbed, died: r.died, splash: true, elementRelation: relation });
            }
          }
        }
        // hồi máu
        if (power > 0 && (s.type === "heal" || s.special === "cleanse")) {
          const healed = this.heal(target, effAtk(actor) * power);
          evs.push({ t: "heal", uid: target.uid, amount: healed });
        }
        // giải hiệu ứng
        if (s.special === "cleanse") {
          const before = target.effects.length;
          target.effects = target.effects.filter((e) => !DEBUFF_TYPES.includes(e.type));
          evs.push({ t: "cleanse", uid: target.uid, count: before - target.effects.length });
        }
        if (!target.alive) continue;
        
        // --- PASSIVE: elementOnSkill (Gây hiệu ứng ngẫu nhiên/hệ khi dùng kỹ năng) ---
        // Mỗi nội tại elementOnSkill được roll độc lập — nhiều nội tại = nhiều lần roll.
        if (actor.side === "player" && actor.equippedItemIds) {
          for (const itemId of actor.equippedItemIds) {
            const item = ITEM_MAP.get(itemId);
            for (const p of item?.passives ?? []) {
              if (p.type !== "elementOnSkill") continue;
              const chance = p.value;
              if (Math.random() < chance) {
                let etype: EffectType = "shock";
                let powerFactor = 0.15;
                if (actor.element === "fire") { etype = "burn"; powerFactor = 0.28; }
                else if (actor.element === "ice") { etype = "freeze"; }
                else if (actor.element === "nature") { etype = "poison"; powerFactor = 0.18; }
                else if (actor.element === "thunder") { etype = "shock"; }

                this.tryEffect(evs, actor, target, etype, 1.0, 2, powerFactor);
              }
            }
          }
        }

        // hiệu ứng đi kèm
        for (const e of s.effects ?? []) {
          this.tryEffect(evs, actor, target, e.type, e.chance[lv], e.turns[lv], e.power[lv]);
        }
      }

      if (s.special === "lifesteal" && lifestealTotal > 0) {
        const healed = this.heal(actor, lifestealTotal * 0.6);
        if (healed > 0) evs.push({ t: "heal", uid: actor.uid, amount: healed });
      }
    }

    actor.acted = true;
    evs.push(...this.checkBattleEnd());
    return evs;
  }

  private checkBattleEnd(): BattleEvent[] {
    const evs: BattleEvent[] = [];
    const enemiesAlive = this.aliveOf("enemy").length;
    const playersAlive = this.aliveOf("player").length;
    if (playersAlive === 0) {
      this.status = "defeat";
      evs.push({ t: "end", victory: false });
      return evs;
    }
    if (enemiesAlive === 0) {
      if (this.waveIdx + 1 < this.stage.waves.length) {
        this.waveIdx++;
        this.units = [...this.side("player"), ...this.spawnWave(this.waveIdx)];
        evs.push({ t: "waveStart", wave: this.waveIdx + 1, total: this.stage.waves.length });
      } else {
        this.status = "victory";
        evs.push({ t: "end", victory: true });
      }
    }
    return evs;
  }

  // ------------------------------------------------------------------ AI ---
  chooseAIAction(u: BattleUnit): Action {
    const allies = this.side(u.side);
    const foes = this.foesOf(u);
    if (foes.length === 0) return { kind: "attack", targetUid: allies[0]?.uid ?? u.uid };

    let usable = u.skills
      .map((sk, idx) => ({ sk, idx, chk: this.canUseSkill(u, idx) }))
      .filter((x) => x.chk.ok);

    const pick = <T,>(arr: T[]): T | undefined => (arr.length ? arr[Math.floor(Math.random() * arr.length)] : undefined);

    // Không dùng trùng 1 skill 2 lượt liên tiếp (nếu còn lựa chọn khác)
    if (u.lastSkillKey && usable.length > 1) {
      const others = usable.filter((x) => x.sk.def.key !== u.lastSkillKey);
      if (others.length > 0) usable = others;
    }
    // hồi sinh
    const revive = usable.find((x) => x.sk.def.special === "revive");
    const deadAlly = allies.filter((a) => !a.alive);
    if (revive && deadAlly.length > 0 && Math.random() < 0.9) {
      return { kind: "skill", skillIdx: revive.idx, targetUid: deadAlly[deadAlly.length - 1].uid };
    }
    // healer: cứu đồng đội
    const heals = usable.filter((x) => x.sk.def.type === "heal" && x.sk.def.special !== "cleanse");
    const wounded = allies.filter((a) => a.alive && a.hp / maxHp(a) < 0.6).sort((a, b) => a.hp / maxHp(a) - b.hp / maxHp(b));
    if (u.aiRole === "healer" && heals.length > 0 && wounded.length > 0 && Math.random() < 0.85) {
      const h = pick(heals)!;
      if (h.sk.def.target === "allies") return { kind: "skill", skillIdx: h.idx };
      return { kind: "skill", skillIdx: h.idx, targetUid: wounded[0].uid };
    }
    if (heals.length > 0 && wounded.length > 0 && Math.random() < 0.3) {
      const h = pick(heals)!;
      if (h.sk.def.target === "allies") return { kind: "skill", skillIdx: h.idx };
      return { kind: "skill", skillIdx: h.idx, targetUid: wounded[0].uid };
    }
    // cleanse
    const cleanse = usable.find((x) => x.sk.def.special === "cleanse");
    const dirty = allies.filter((a) => a.alive && a.effects.filter((e) => DEBUFF_TYPES.includes(e.type)).length >= 2);
    if (cleanse && dirty.length > 0 && Math.random() < 0.7) {
      if (cleanse.sk.def.target === "allies") return { kind: "skill", skillIdx: cleanse.idx };
      return { kind: "skill", skillIdx: cleanse.idx, targetUid: dirty[0].uid };
    }
    // taunt
    const taunt = usable.find((x) => x.sk.def.special === "taunt");
    if (taunt && !hasEffect(u, "taunt") && Math.random() < 0.6) {
      return { kind: "skill", skillIdx: taunt.idx };
    }
    // buff
    const buffs = usable.filter((x) => x.sk.def.type === "buff" || x.sk.def.special === "shield");
    if (buffs.length > 0 && Math.random() < 0.35) {
      const b = pick(buffs)!;
      if (["allies", "self"].includes(b.sk.def.target)) return { kind: "skill", skillIdx: b.idx };
      const tgt = pick(allies.filter((a) => a.alive))!;
      return { kind: "skill", skillIdx: b.idx, targetUid: tgt.uid };
    }
    // damage / control
    const dmgs = usable.filter((x) => x.sk.def.type === "damage" || x.sk.def.type === "debuff");
    if (dmgs.length > 0 && Math.random() < 0.75) {
      const d = pick(dmgs)!;
      if (d.sk.def.target === "enemies") return { kind: "skill", skillIdx: d.idx };
      const tgt = this.weightedTarget(u, foePreferWounded(d.sk.def) ? [...foes].sort((a, b) => a.hp - b.hp).slice(0, 2) : foes);
      return { kind: "skill", skillIdx: d.idx, targetUid: tgt.uid };
    }
    // đánh thường
    const tgt = this.weightedTarget(u, foes);
    return { kind: "attack", targetUid: tgt.uid };
  }

  private weightedTarget(u: BattleUnit, candidates: BattleUnit[]): BattleUnit {
    if (candidates.length === 1) return candidates[0];
    // Khiêu khích: bắt buộc nhắm vào kẻ đang taunt
    const taunters = candidates.filter((c) => hasEffect(c, "taunt"));
    const pool = taunters.length > 0 ? taunters : candidates;
    // class đỡ đòn có trọng số bị nhắm cao hơn (aggro)
    const weights = pool.map((c) => c.stats.aggro * (0.7 + Math.random() * 0.6));
    let sum = weights.reduce((a, b) => a + b, 0);
    let roll = Math.random() * sum;
    for (let i = 0; i < pool.length; i++) {
      roll -= weights[i];
      if (roll <= 0) return pool[i];
    }
    return pool[pool.length - 1];
  }
}

function foePreferWounded(s: SkillDef): boolean {
  return s.special === "execute";
}
