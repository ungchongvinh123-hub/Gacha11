// ============================================================================
// Tính chỉ số: cơ bản theo class/level + cộng thêm từ trang bị
// ============================================================================
import type { BaseStats, CharDef, CharacterInstance, ItemInstance, StatBonus } from "../types";
import { ITEM_MAP } from "../data/items";

export interface ComputedStats extends BaseStats {
  // chỉ số cơ bản (chưa đồ) để hiển thị breakdown
  raw: BaseStats;
  bonus: Required<StatBonus>;
}

export function rawStats(def: CharDef, level: number): BaseStats {
  const lv = Math.max(1, level);
  return {
    hp: def.base.hp + def.growth.hp * (lv - 1),
    atk: def.base.atk + def.growth.atk * (lv - 1),
    def: def.base.def + def.growth.def * (lv - 1),
    dice: def.base.dice + def.growth.dice * (lv - 1),
    crit: def.base.crit,
    critDmg: def.base.critDmg,
    effectRes: def.base.effectRes,
    aggro: def.base.aggro,
  };
}

const EMPTY_BONUS: Required<StatBonus> = {
  hp: 0, hpPct: 0, atk: 0, atkPct: 0, def: 0, defPct: 0,
  dice: 0, crit: 0, critDmg: 0, effectRes: 0,
};

export function equipmentOf(charId: number, allItems: ItemInstance[]): ItemInstance[] {
  return allItems.filter((i) => i.equippedBy === charId);
}

export function sumItemBonus(equipped: ItemInstance[]): Required<StatBonus> {
  const b = { ...EMPTY_BONUS };
  for (const it of equipped) {
    const d = ITEM_MAP.get(it.defId);
    if (!d) continue;
    // Mỗi cấp cường hóa tăng thêm 15% chỉ số gốc của trang bị
    const scale = 1 + (it.level ?? 0) * 0.15;
    for (const k of Object.keys(d.stats) as (keyof StatBonus)[]) {
      const val = d.stats[k] ?? 0;
      b[k] += val * scale;
    }
  }
  return b;
}

export function computeStats(def: CharDef, level: number, equipped: ItemInstance[]): ComputedStats {
  const raw = rawStats(def, level);
  const bonus = sumItemBonus(equipped);
  const total: BaseStats = {
    hp: Math.round((raw.hp + bonus.hp) * (1 + bonus.hpPct)),
    atk: Math.round((raw.atk + bonus.atk) * (1 + bonus.atkPct)),
    def: Math.round((raw.def + bonus.def) * (1 + bonus.defPct)),
    dice: raw.dice + bonus.dice,
    crit: Math.min(0.85, raw.crit + bonus.crit),
    critDmg: raw.critDmg + bonus.critDmg,
    effectRes: Math.min(0.75, raw.effectRes + bonus.effectRes),
    aggro: raw.aggro,
  };
  return { ...total, raw, bonus };
}

// tiện ích cho UI -------------------------------------------------------------
export function pointsAvailable(c: CharacterInstance): number {
  return Math.max(0, c.level - c.spentPoints);
}

export function skillLearnCost(newLevel: number, tier: number): { points: number; gold: number } {
  return { points: newLevel, gold: Math.round(200 * newLevel * (1 + tier * 0.75)) };
}

export function powerScore(stats: BaseStats, skillLevels: Record<string, number>): number {
  const learned = Object.values(skillLevels).reduce((a, b) => a + b, 0);
  return Math.round(stats.hp / 8 + stats.atk * 3.5 + stats.def * 3.5 + stats.dice * 25 + learned * 6);
}
