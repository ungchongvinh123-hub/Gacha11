"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Icn } from "./ui";

/**
 * Nhắc xoay ngang trên điện thoại (mục tiêu: app Android màn hình ngang).
 * Chỉ hiện khi: màn hình nhỏ + dạng cảm ứng + đang ở chiều DỌC.
 * Trong webview APK (đã khóa landscape) overlay này không bao giờ hiện.
 */
export default function RotatePrompt() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const check = () => {
      const touch = window.matchMedia("(pointer: coarse)").matches;
      const small = window.innerWidth < 900;
      const portrait = window.innerHeight > window.innerWidth;
      setShow(touch && small && portrait);
    };
    check();
    window.addEventListener("resize", check);
    window.addEventListener("orientationchange", check);
    return () => {
      window.removeEventListener("resize", check);
      window.removeEventListener("orientationchange", check);
    };
  }, []);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[80] bg-[#0b0e1a]/95 backdrop-blur flex flex-col items-center justify-center gap-4 px-8 text-center"
        >
          <motion.div
            animate={{ rotate: [0, 90, 90, 0] }}
            transition={{ repeat: Infinity, duration: 2.6, times: [0, 0.35, 0.7, 1] }}
          >
            <Icn name="smartphone" className="w-16 h-16 text-indigo-300" />
          </motion.div>
          <div className="text-lg font-black tracking-wide text-slate-100">Xoay ngang điện thoại</div>
          <div className="text-sm text-slate-400 leading-relaxed">Game được thiết kế cho màn hình ngang (landscape)</div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
