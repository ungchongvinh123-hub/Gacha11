"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import clsx from "clsx";
import type { EffectType, Element, Rarity, UnitPose } from "@/game/types";
import { ELEMENT_COLORS, RARITY_COLORS } from "@/game/types";
import { ElementDot, Icn } from "./ui";

const POSE_DURATION: Record<Exclude<UnitPose, "idle">, number> = {
  attack: 500, // đủ thời gian chạy hết frame vung đòn
  cast: 550,
  hit: 420,
  die: 800,
};
const FRAME_MS = 170; // tốc độ lật frame

/**
 * UnitFigure — "model" 2D của đơn vị trong chiến đấu.
 *
 * ===== STATE MACHINE =====
 *  pose: idle → attack/cast (khi hành động) → hit (khi trúng đòn) → die (khi chết)
 *  - BattleScreen chỉ việc tăng hitCount / lungeCount / đổi dead — component
 *    tự suy pose và quay về idle. Engine chiến đấu không bị đụng tới.
 *
 * ===== FRAME-BASED ANIMATION =====
 *  Nếu `animFrames` có danh sách ảnh cho pose hiện tại → chạy đúng chuỗi frame
 *  (idle/attack lặp, hit/die chạy 1 lần). Khai báo frame ở src/game/art.ts.
 *
 * ===== FALLBACK =====
 *  Chưa có frame → dùng `artPath` (ảnh toàn thân/chân dung tĩnh) + CSS motion
 *  proxy (nhún, lao tới, rung, flash, overlay hiệu ứng) — không vỡ gì cả.
 */
export default function UnitFigure(props: {
  icon: string;
  element: Element;
  rarity?: Rarity;
  side: "player" | "enemy";
  dead?: boolean;
  artPath?: string;
  animFrames?: Partial<Record<UnitPose, string[]>>;
  hitCount?: number;
  lungeCount?: number;
  frozen?: boolean;
  shocked?: boolean;
  taunting?: boolean;
  statuses?: EffectType[];
  flip?: boolean; // lật ngang ảnh (quái bên phải quay mặt về phe ta)
  className?: string;
}) {
  const { icon, element, rarity, side, dead, artPath, animFrames, hitCount = 0, lungeCount = 0, frozen, shocked, taunting, statuses = [], flip, className } = props;
  const [c1, c2] = ELEMENT_COLORS[element];

  // --- pose machine ---
  const [pose, setPose] = useState<UnitPose>("idle");
  const [frameIdx, setFrameIdx] = useState(0);
  const prevHit = useRef(0);
  const prevLunge = useRef(0);
  const prevDead = useRef(!!dead);
  const timers = useRef<number[]>([]);

  const clearTimers = () => {
    timers.current.forEach((t) => window.clearTimeout(t));
    timers.current = [];
  };

  useEffect(() => () => clearTimers(), []);

  // dead: giữ pose die (revive sẽ về idle)
  useEffect(() => {
    if (dead && !prevDead.current) {
      clearTimers();
      setPose("die");
      setFrameIdx(0);
    }
    if (!dead && prevDead.current) setPose("idle");
    prevDead.current = !!dead;
  }, [dead]);

  // trúng đòn → hit một lần rồi về idle
  useEffect(() => {
    if (hitCount > prevHit.current) {
      clearTimers();
      setPose("hit");
      setFrameIdx(0);
      const t = window.setTimeout(() => {
        if (!props.dead) setPose("idle");
      }, POSE_DURATION.hit);
      timers.current.push(t);
      prevHit.current = hitCount;
    }
  }, [hitCount, props.dead]);

  // hành động (đánh/skill) → attack/cast một lần rồi về idle
  useEffect(() => {
    if (lungeCount > prevLunge.current) {
      clearTimers();
      const p: UnitPose = "attack";
      setPose(p);
      setFrameIdx(0);
      const t = window.setTimeout(() => {
        if (!props.dead) setPose("idle");
      }, POSE_DURATION.attack);
      timers.current.push(t);
      prevLunge.current = lungeCount;
    }
  }, [lungeCount, props.dead]);

  // --- chọn frame cho pose hiện tại ---
  const frames = animFrames?.[pose];
  const frameList = frames && frames.length > 0 ? frames : null;
  const isLoop = pose === "idle" || pose === "attack" || pose === "cast";
  const currentImg = frameList
    ? frameList[Math.min(frameIdx, frameList.length - 1)]
    : artPath;

  useEffect(() => {
    if (!frameList || frameList.length <= 1) return;
    const iv = window.setInterval(() => {
      setFrameIdx((i) =>
        isLoop ? (i + 1) % frameList.length : Math.min(i + 1, frameList.length - 1),
      );
    }, FRAME_MS);
    return () => window.clearInterval(iv);
  }, [pose, frameList?.length, isLoop]); // eslint-disable-line react-hooks/exhaustive-deps

  // nhảy frame khi pose đổi (tránh hiện frame cũ)
  useEffect(() => {
    if (frameList && frameList.length > 0) setFrameIdx(0);
  }, [pose]); // eslint-disable-line react-hooks/exhaustive-deps

  const lungeX = side === "player" ? 18 : -18;
  const burning = statuses.includes("burn");
  const poisoned = statuses.includes("poison");
  const playingFrames = !!frameList;

  return (
    <div className={clsx("relative flex flex-col items-center justify-end w-full select-none", className)}>
      <div className="absolute bottom-0.5 left-1/2 -translate-x-1/2 w-8 md:w-10 h-1.5 rounded-full bg-black/45 blur-[2px] pointer-events-none" />

      <motion.div
        key={`hit-${hitCount}`}
        animate={hitCount > 0 && !playingFrames ? { x: [0, -6, 7, -4, 3, 0] } : {}}
        transition={{ duration: 0.32 }}
        className="relative h-14 w-14 md:h-[76px] md:w-[76px]"
      >
        {/* flash trắng khi trúng đòn (luôn bật — kể cả có frame) */}
        {hitCount > 0 && (
          <motion.div
            initial={{ opacity: 0.55 }}
            animate={{ opacity: 0 }}
            transition={{ duration: 0.22 }}
            className="absolute inset-0 rounded-lg bg-white z-20 pointer-events-none"
          />
        )}

        <div
          className="absolute inset-0 rounded-xl overflow-hidden flex items-end justify-center"
          style={{
            background: artPath ? "transparent" : `linear-gradient(150deg, ${c1}55, #0b0e1a 75%)`,
            border: `2px solid ${rarity ? RARITY_COLORS[rarity] : c2}66`,
            boxShadow: `inset 0 0 16px ${c2}22`,
          }}
        >
          <motion.div
            animate={!dead && !playingFrames ? { y: [0, -3, 0] } : dead ? { opacity: 0 } : {}}
            transition={
              dead
                ? { duration: 0.6 }
                : { repeat: Infinity, duration: 2.4, ease: "easeInOut" }
            }
            className={clsx("h-full w-full flex items-end justify-center", dead && "grayscale")}
          >
            {/* lunge khi hành động — chỉ dùng CSS nếu KHÔNG có frame */}
            <motion.div
              key={`l-${lungeCount}`}
              animate={lungeCount > 0 && !playingFrames ? { x: [0, lungeX, 0], scale: [1, 1.08, 1] } : {}}
              transition={{ duration: 0.3 }}
              className="h-full w-full flex items-end justify-center"
            >
              {/* idle bob nhẹ khi đang chạy frame idle */}
              <motion.div
                animate={playingFrames && pose === "idle" ? { y: [0, -2, 0] } : {}}
                transition={{ repeat: Infinity, duration: 2.2, ease: "easeInOut" }}
                className={clsx("h-full w-full flex items-end justify-center", dead && "grayscale")}
              >
                <div
                  style={{ transform: flip ? "scaleX(-1)" : undefined }}
                  className="h-full w-full flex items-end justify-center"
                >
                  {currentImg ? (
                    <img
                      key={`${pose}-${frameIdx}`}
                      src={currentImg}
                      alt=""
                      draggable={false}
                      className="max-h-full max-w-full object-contain drop-shadow-[0_6px_5px_rgba(0,0,0,0.6)]"
                      style={{
                        filter: dead ? "grayscale(1) brightness(0.6)" : undefined,
                        transform: pose === "hit" ? "translateX(3px)" : undefined,
                      }}
                    />
                  ) : (
                    <Icn
                      name={icon}
                      className="mb-1"
                      style={{ width: 34, height: 34, color: c2, filter: `drop-shadow(0 0 8px ${c2})` }}
                    />
                  )}
                </div>
              </motion.div>
            </motion.div>
          </motion.div>
        </div>

        {/* overlay hiệu ứng đang chịu */}
        {frozen && !dead && (
          <div className="absolute inset-0 rounded-xl z-10 pointer-events-none bg-gradient-to-b from-cyan-300/40 to-cyan-200/10 border border-cyan-200/70 flex items-center justify-center">
            <Icn name="snowflake" className="w-6 h-6 text-cyan-100 drop-shadow-[0_0_6px_#7dd3fc]" />
          </div>
        )}
        {burning && !dead && (
          <div className="absolute inset-x-0 bottom-0 h-1/3 rounded-b-xl z-10 pointer-events-none bg-gradient-to-t from-orange-500/50 to-transparent" />
        )}
        {poisoned && !dead && (
          <div className="absolute inset-0 rounded-xl z-10 pointer-events-none border border-green-400/50 bg-green-500/15" />
        )}
        {shocked && !dead && (
          <div className="absolute inset-0 rounded-xl z-10 pointer-events-none border border-yellow-300/60 bg-yellow-400/10 flex items-start justify-end pr-0.5">
            <Icn name="zap" className="w-4 h-4 text-yellow-300 mt-0.5" />
          </div>
        )}
        {taunting && !dead && (
          <span className="absolute -top-1.5 -right-1.5 z-20 w-4 h-4 rounded-full bg-rose-500 flex items-center justify-center">
            <Icn name="flag" className="w-2.5 h-2.5 text-white" />
          </span>
        )}
      </motion.div>

      {!artPath && !frameList && (
        <span className="absolute bottom-0.5 right-0.5 z-10">
          <ElementDot element={element} size={7} />
        </span>
      )}
    </div>
  );
}
