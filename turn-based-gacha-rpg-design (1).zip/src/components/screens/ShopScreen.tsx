"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import clsx from "clsx";
import { useGame } from "@/game/store";
import { ITEM_DEFS } from "@/game/data/items";
import { formatBonus } from "./RosterScreen";
import { SLOT_LABEL } from "@/game/data/items";
import { CLASS_LABEL, RARITY_COLORS } from "@/game/types";
import { Btn, Chip, Icn } from "../ui";
import { sfx } from "@/game/sfx";

interface ShopItem {
  id: string;
  price: number;
  type: "item" | "gems";
  gemsGain?: number;
  name?: string;
  icon?: string;
}

const SHOP_ITEMS: ShopItem[] = [
  // --- VŨ KHÍ SSR (Thượng Cổ Thần Binh) ---
  { id: "w_atk_ssr1", price: 18000, type: "item" }, // Long Nha Kiếm SSR (Attacker)
  { id: "w_tnk_ssr1", price: 20000, type: "item" }, // Thần Thuẫn Aegis SSR (Tank)
  { id: "w_sup_ssr1", price: 18000, type: "item" }, // Thái Dương Trượng SSR (Support)

  // --- TRANG SỨC SSR (Cổ Vật Chí Bảo) ---
  { id: "j_ssr2", price: 15000, type: "item" },     // Nhẫn Chí Mạng SSR
  { id: "j_ssr3", price: 16000, type: "item" },     // Thánh Bùa Hộ Mệnh SSR

  // --- THÁNH Y SSR ---
  { id: "a_atk_ssr", price: 14000, type: "item" },  // Thần Tốc Chiến Y SSR
  { id: "a_tnk_ssr", price: 15000, type: "item" },  // Thiên Thạch Giáp SSR
  { id: "a_sup_ssr", price: 14000, type: "item" },  // Thánh Quang Miện Bào SSR

  // --- ĐỒ SR (Giải pháp giá rẻ hơn) ---
  { id: "w_atk_sr2", price: 6500, type: "item" },   // Đại Cung Phong Sát SR
  { id: "w_tnk_sr2", price: 7000, type: "item" },   // Bích Chướng SR
  { id: "w_sup_sr1", price: 6500, type: "item" },   // Nguyệt Trượng SR

  // --- QUY ĐỔI MA THẠCH (Dành cho nông dân cày cuốc) ---
  { id: "g1", price: 4000, type: "gems", gemsGain: 320, name: "Túi Ngọc Gacha Nhỏ", icon: "gem" }, // Đủ 2 lần quay
  { id: "g2", price: 11000, type: "gems", gemsGain: 1000, name: "Rương Ngọc Gacha Lớn", icon: "gem" }, // Gần đủ x10 quay
  { id: "g3", price: 25000, type: "gems", gemsGain: 2500, name: "Thần Sa Bảo Hạp", icon: "crown" }, // Đủ hơn 15 lần quay
];

export default function ShopScreen() {
  const { player, mutate, toast } = useGame();
  const [busy, setBusy] = useState(false);

  const gold = player?.gold ?? 0;

  async function buy(item: ShopItem) {
    if (busy) return;
    if (gold < item.price) {
      toast("Không đủ vàng! Hãy cày thêm bằng cách đánh ải quái", "error");
      return;
    }
    setBusy(true);
    try {
      if (item.type === "item") {
        await mutate("buyItem", { itemId: item.id, price: item.price });
        sfx("coin");
        toast(`Mua thành công trang bị! Hãy kiểm tra trong hòm đồ`, "success");
      } else {
        await mutate("buyGems", { price: item.price, gemsGain: item.gemsGain });
        sfx("ssr");
        toast(`Đã đổi thành công +${item.gemsGain} Ngọc quý!`, "success");
      }
    } catch {
      // handled
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto pb-12">
      <div className="flex items-center justify-between mb-2">
        <div>
          <h2 className="text-xl font-black tracking-wide">CỬA HÀNG THẦN BÍ</h2>
          <p className="text-xs text-slate-500 mt-0.5">Tiêu thụ vàng kiếm được từ ải quái để mua Trang bị SSR cực phẩm hoặc đổi Ngọc triệu hồi.</p>
        </div>
        <div className="flex items-center gap-1.5 rounded-full bg-amber-400/10 border border-amber-400/20 px-3 py-1 text-sm font-semibold">
          <Icn name="coins" className="w-4 h-4 text-amber-300" />
          <span className="text-amber-200 tabular-nums">{gold.toLocaleString()}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 mt-4">
        {SHOP_ITEMS.map((item) => {
          if (item.type === "item") {
            const d = ITEM_DEFS.find((x) => x.id === item.id);
            if (!d) return null;
            const canAfford = gold >= item.price;
            return (
              <motion.div
                key={item.id}
                whileHover={{ y: -2 }}
                className={clsx(
                  "rounded-2xl border p-4 flex flex-col justify-between transition-all bg-white/[0.02]",
                  d.rarity === "SSR" ? "border-amber-400/20" : "border-white/8",
                )}
              >
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <span
                      className="w-11 h-11 rounded-xl flex items-center justify-center border shrink-0"
                      style={{ background: `${RARITY_COLORS[d.rarity]}12`, borderColor: `${RARITY_COLORS[d.rarity]}44` }}
                    >
                      <Icn name={d.icon} className="w-5 h-5" style={{ color: RARITY_COLORS[d.rarity] }} />
                    </span>
                    <div className="min-w-0">
                      <div className="font-bold text-sm truncate" style={{ color: RARITY_COLORS[d.rarity] }}>
                        {d.name}
                      </div>
                      <div className="flex gap-1.5 mt-0.5">
                        <span className="text-[9px] font-bold text-slate-400">{SLOT_LABEL[d.slot]}</span>
                        <span className="text-[9px] font-bold" style={{ color: RARITY_COLORS[d.rarity] }}>{d.rarity}</span>
                        {d.cls && <span className="text-[9px] font-bold text-indigo-400">{CLASS_LABEL[d.cls]}</span>}
                      </div>
                    </div>
                  </div>
                  <div className="rounded-lg bg-emerald-500/5 p-2 text-[11px] text-emerald-300 leading-tight mb-2">
                    {formatBonus(d.stats)}
                  </div>
                  {d.passives && d.passives.length > 0 && (
                    <div className="rounded-lg bg-fuchsia-500/5 border border-fuchsia-500/10 p-2 mb-4 space-y-0.5">
                      {d.passives.map((p, idx) => (
                        <div key={idx} className="text-[10px] text-fuchsia-300 leading-tight flex items-start gap-1">
                          <span>⚡</span>
                          <span><b>Nội tại:</b> {p.desc}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between gap-2 border-t border-white/5 pt-3 mt-1">
                  <span className="text-xs font-black text-amber-300 flex items-center gap-1">
                    <Icn name="coins" className="w-3.5 h-3.5" />
                    {item.price.toLocaleString()}
                  </span>
                  <Btn
                    variant={canAfford ? "gold" : "ghost"}
                    disabled={busy || !canAfford}
                    onClick={() => buy(item)}
                    className="!px-3 !py-1.5 !text-[11px]"
                  >
                    MUA
                  </Btn>
                </div>
              </motion.div>
            );
          } else {
            // Quy đổi ngọc
            const canAfford = gold >= item.price;
            return (
              <motion.div
                key={item.id}
                whileHover={{ y: -2 }}
                className="rounded-2xl border border-indigo-400/15 bg-gradient-to-br from-indigo-950/20 to-transparent p-4 flex flex-col justify-between transition-all"
              >
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <span className="w-11 h-11 rounded-xl flex items-center justify-center border border-indigo-400/40 bg-indigo-500/15 text-indigo-300 shrink-0">
                      <Icn name={item.icon ?? "gem"} className="w-5 h-5 text-indigo-300" />
                    </span>
                    <div>
                      <div className="font-bold text-sm text-slate-200">{item.name}</div>
                      <span className="text-[9px] font-bold text-cyan-300">ĐỔI NGỌC GACHA</span>
                    </div>
                  </div>
                  <div className="rounded-lg bg-cyan-500/5 p-2 text-[11px] text-cyan-300 leading-tight mb-4 flex items-center gap-1.5">
                    <Icn name="gem" className="w-3.5 h-3.5 text-cyan-300" /> Nhận ngay +{item.gemsGain} Ngọc quý
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 border-t border-white/5 pt-3 mt-1">
                  <span className="text-xs font-black text-amber-300 flex items-center gap-1">
                    <Icn name="coins" className="w-3.5 h-3.5" />
                    {item.price.toLocaleString()}
                  </span>
                  <Btn
                    variant={canAfford ? "primary" : "ghost"}
                    disabled={busy || !canAfford}
                    onClick={() => buy(item)}
                    className="!px-3 !py-1.5 !text-[11px]"
                  >
                    QUY ĐỔI
                  </Btn>
                </div>
              </motion.div>
            );
          }
        })}
      </div>
    </div>
  );
}
