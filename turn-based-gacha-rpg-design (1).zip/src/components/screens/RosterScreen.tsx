"use client";

import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import clsx from "clsx";
import { useGame } from "@/game/store";
import { CHAR_MAP } from "@/game/data/characters";
import { ITEM_MAP, SLOT_LABEL } from "@/game/data/items";
import { computeStats, pointsAvailable, powerScore, skillLearnCost } from "@/game/engine/stats";
import { describeSkill } from "@/game/data/skills";
import type { CharacterInstance, ClassId, ItemInstance, ItemSlot, Rarity } from "@/game/types";
import { CLASS_LABEL, ELEMENT_LABEL, expForLevel, MAX_LEVEL, MAX_LOADOUT, MAX_SKILL_LEVEL, RARITY_COLORS } from "@/game/types";
import { Bar, Btn, Chip, CLASS_META, ElementDot, EXP_COLOR, Icn, Modal, Portrait, Stars } from "../ui";
import { sfx } from "@/game/sfx";

const RARITY_ORDER: Record<Rarity, number> = { SSR: 0, SR: 1, R: 2 };

export default function RosterScreen() {
  const { characters, player } = useGame();
  const [filter, setFilter] = useState<ClassId | "all">("all");
  const [selId, setSelId] = useState<number | null>(null);

  const list = useMemo(() => {
    return characters
      .map((c) => ({ c, def: CHAR_MAP.get(c.defId)! }))
      .filter((x) => x.def && (filter === "all" || x.def.classId === filter))
      .sort((a, b) => RARITY_ORDER[a.def.rarity] - RARITY_ORDER[b.def.rarity] || b.c.level - a.c.level || a.def.name.localeCompare(b.def.name));
  }, [characters, filter]);

  const sel = selId != null ? characters.find((c) => c.id === selId) : null;

  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <h2 className="text-xl font-black tracking-wide">TÚI TƯỚNG <span className="text-slate-400 text-sm font-semibold">({characters.length})</span></h2>
        <div className="flex gap-1.5">
          {(["all", "tank", "attacker", "support"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={clsx(
                "px-3 py-1.5 rounded-full text-xs font-bold transition-all border",
                filter === f
                  ? "bg-indigo-500/25 text-indigo-200 border-indigo-400/40"
                  : "bg-white/[0.04] text-slate-400 border-white/8 hover:text-slate-200",
              )}
            >
              {f === "all" ? "Tất cả" : CLASS_LABEL[f]}
            </button>
          ))}
        </div>
      </div>

      {list.length === 0 && (
        <div className="text-center text-slate-500 py-16 text-sm">Chưa có tướng nào — hãy qua Cổng Triệu Hồi!</div>
      )}

      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-7 gap-2">
        {list.map(({ c, def }, i) => {
          const inTeam = player?.team.includes(c.id);
          return (
            <motion.button
              key={c.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: Math.min(i * 0.02, 0.4) }}
              onClick={() => {
                sfx("click");
                setSelId(c.id);
              }}
              className={clsx(
                "relative rounded-xl border p-2 flex flex-col items-center gap-1.5 transition-all hover:scale-[1.03] active:scale-95 bg-white/[0.03]",
                inTeam ? "border-amber-400/50" : "border-white/8 hover:border-white/20",
              )}
              style={{ boxShadow: def.rarity === "SSR" ? `0 0 12px ${RARITY_COLORS.SSR}22` : undefined }}
            >
              <Portrait icon={def.icon} element={def.element} rarity={def.rarity} size={52} artPath={def.art} />
              <div className="text-[11px] font-bold leading-tight text-center truncate w-full">{def.name}</div>
              <div className="flex items-center gap-1">
                <Stars rarity={def.rarity} />
                <span className="text-[9px] text-slate-400 font-semibold">Lv.{c.level}</span>
              </div>
              {inTeam && (
                <span className="absolute -top-1.5 -right-1.5 bg-amber-400 text-amber-950 text-[8px] font-black px-1.5 py-0.5 rounded-full shadow">
                  ĐỘI
                </span>
              )}
            </motion.button>
          );
        })}
      </div>

      <AnimatePresence>{sel && <CharDetail charId={sel.id} onClose={() => setSelId(null)} />}</AnimatePresence>
    </div>
  );
}

// ============================ DETAIL MODAL ==================================
function CharDetail({ charId, onClose }: { charId: number; onClose: () => void }) {
  const { characters, items, player, mutate, toast } = useGame();
  const [tab, setTab] = useState<"info" | "skills" | "gear">("skills");
  const [expandSkill, setExpandSkill] = useState<string | null>(null);
  const [pickSlot, setPickSlot] = useState<ItemSlot | null>(null);

  const c = characters.find((x) => x.id === charId);
  if (!c) return null;
  const def = CHAR_MAP.get(c.defId)!;
  const equip = items.filter((i) => i.equippedBy === c.id);
  const stats = computeStats(def, c.level, equip);
  const avail = pointsAvailable(c);
  const inLoadout = (sid: string) => c.loadout.includes(sid);

  async function learn(skillId: string, tier: number) {
    const cur = c!.skillLevels[skillId] ?? 0;
    sfx(cur === 0 ? "levelup" : "equip");
    await mutate("learnSkill", { charId, skillId }).catch(() => {});
  }

  async function toggleLoadout(skillId: string) {
    const cur = c!.skillLevels[skillId] ?? 0;
    if (cur === 0) {
      toast("Phải học kỹ năng trước đã", "error");
      return;
    }
    let next: string[];
    if (c!.loadout.includes(skillId)) next = c!.loadout.filter((s) => s !== skillId);
    else if (c!.loadout.length >= MAX_LOADOUT) {
      toast(`Chỉ mang tối đa ${MAX_LOADOUT} kỹ năng vào trận`, "error");
      return;
    } else next = [...c!.loadout, skillId];
    sfx("click");
    await mutate("setLoadout", { charId, loadout: next }).catch(() => {});
  }

  return (
    <Modal onClose={onClose} wide>
      <div className="flex flex-col max-h-[92vh]">
        {/* header */}
        <div className="flex items-center gap-3 p-4 pb-3 border-b border-white/8 bg-white/[0.02]">
          <Portrait icon={def.icon} element={def.element} rarity={def.rarity} size={64} artPath={def.art} />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-black text-lg leading-none">{def.name}</h3>
              <Chip color={CLASS_META[def.classId].color}>{CLASS_META[def.classId].label}</Chip>
              <Chip color={RARITY_COLORS[def.rarity]}>{def.rarity}</Chip>
              <Chip color="#94a3b8">
                <ElementDot element={def.element} size={6} /> {ELEMENT_LABEL[def.element]}
              </Chip>
            </div>
            <div className="text-xs text-slate-400 mt-1">{def.title} · #{c.id}</div>
            <div className="mt-2 flex items-center gap-2">
              <span className="text-[10px] font-bold text-amber-300">Lv.{c.level}{c.level >= MAX_LEVEL ? " MAX" : ""}</span>
              {c.level < MAX_LEVEL && (
                <>
                  <Bar value={c.exp} max={expForLevel(c.level)} color={EXP_COLOR} height={5} className="flex-1 max-w-44" />
                  <span className="text-[9px] text-slate-500 tabular-nums">{c.exp}/{expForLevel(c.level)}</span>
                </>
              )}
            </div>
          </div>
          <div className="text-right shrink-0">
            <div className="text-[10px] uppercase tracking-wider text-slate-500">Lực chiến</div>
            <div className="text-2xl font-black text-amber-300 tabular-nums">{powerScore(stats, c.skillLevels).toLocaleString()}</div>
          </div>
        </div>

        {/* tabs */}
        <div className="flex gap-1 px-4 pt-3">
          {(
            [
              ["info", "Chỉ Số", "info"],
              ["skills", `Kỹ Năng (${Object.keys(c.skillLevels).length}/${def.skills.length})`, "sparkles"],
              ["gear", "Trang Bị", "shield"],
            ] as const
          ).map(([k, label, icon]) => (
            <button
              key={k}
              onClick={() => setTab(k)}
              className={clsx(
                "flex items-center gap-1.5 px-3 py-2 rounded-t-xl text-xs font-bold border-b-2 transition-all",
                tab === k ? "bg-white/[0.05] text-indigo-300 border-indigo-400" : "text-slate-500 border-transparent hover:text-slate-300",
              )}
            >
              <Icn name={icon} className="w-3.5 h-3.5" /> {label}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-4 pt-3">
          {/* ------------------------------ INFO TAB ------------------------------ */}
          {tab === "info" && (
            <div className="grid sm:grid-cols-2 gap-2">
              {(
                [
                  ["Máu (HP)", stats.raw.hp, stats.bonus.hp, stats.bonus.hpPct * stats.raw.hp, stats.hp, "#4ade80"],
                  ["Tấn Công", stats.raw.atk, stats.bonus.atk, stats.bonus.atkPct * stats.raw.atk, stats.atk, "#f87171"],
                  ["Phòng Thủ", stats.raw.def, stats.bonus.def, stats.bonus.defPct * stats.raw.def, stats.def, "#60a5fa"],
                  ["Xúc Xắc (cơ hội)", stats.raw.dice, stats.bonus.dice, 0, stats.dice, "#38bdf8"],
                ] as const
              ).map(([label, raw, flat, pctB, total, color]) => {
                const bonus = Math.round((flat as number) + (pctB as number));
                return (
                  <div key={label} className="rounded-xl border border-white/8 bg-white/[0.03] p-3 flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-400">{label}</span>
                    <div className="text-right">
                      <div className="font-black tabular-nums" style={{ color }}>{total}</div>
                      {bonus > 0 && <div className="text-[9px] text-emerald-400 tabular-nums">{(raw as number).toFixed(0)} +{bonus}</div>}
                    </div>
                  </div>
                );
              })}
              {(
                [
                  ["Chí Mạng", `${Math.round(stats.crit * 100)}%`],
                  ["ST Chí Mạng", `${Math.round(stats.critDmg * 100)}%`],
                  ["Kháng Hiệu Ứng", `${Math.round(stats.effectRes * 100)}%`],
                  ["Bị nhắm (aggro)", `x${stats.aggro}`],
                  ["Điểm kỹ năng còn", `${avail}`],
                ] as const
              ).map(([label, val]) => (
                <div key={label} className="rounded-xl border border-white/8 bg-white/[0.03] p-3 flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-400">{label}</span>
                  <span className="font-black tabular-nums text-slate-200">{val}</span>
                </div>
              ))}
              <div className="sm:col-span-2 rounded-xl border border-indigo-400/20 bg-indigo-500/[0.07] p-3 text-xs text-slate-300/85 leading-relaxed">
                Chỉ số cơ bản theo class <b>{CLASS_LABEL[def.classId]}</b>. Mỗi lượt hành động <b>đổ 1 viên xúc xắc 6 mặt</b>:
                mặt ra bao nhiêu thì nhận bấy nhiêu mana (1-6, không bao giờ quá 6) để dùng skill.
                Class hỗ trợ/SSR có chỉ số xúc xắc cao hơn = thêm cơ hội roll lại lấy kết quả tốt hơn.
                Quái vật KHÔNG có xúc xắc — dùng skill định sẵn. Đỡ đòn dễ bị quái nhắm tới hơn.
              </div>
            </div>
          )}

          {/* ----------------------------- SKILLS TAB ----------------------------- */}
          {tab === "skills" && (
            <div className="space-y-2">
              <div className="flex items-center justify-between rounded-xl border border-amber-400/25 bg-amber-400/[0.06] px-3 py-2 text-xs">
                <span className="text-amber-200 font-bold">Điểm kỹ năng: {avail}</span>
                <span className="text-slate-400">Mang theo: <b className="text-indigo-300">{c.loadout.length}/{MAX_LOADOUT}</b> kỹ năng</span>
              </div>
              {def.skills.map((s) => {
                const lv = c.skillLevels[s.id] ?? 0;
                const learned = lv > 0;
                const nextCost = lv < MAX_SKILL_LEVEL ? skillLearnCost(lv + 1, s.tier) : null;
                const carried = inLoadout(s.id);
                const canAfford = nextCost ? avail >= nextCost.points && (player?.gold ?? 0) >= nextCost.gold : false;
                const expanded = expandSkill === s.id;
                const dlv = Math.max(1, lv);
                return (
                  <div key={s.id} className={clsx("rounded-xl border transition-all", carried ? "border-indigo-400/50 bg-indigo-500/[0.08]" : "border-white/8 bg-white/[0.02]")}>
                    <div className="flex items-center gap-2.5 p-2.5">
                      <button onClick={() => setExpandSkill(expanded ? null : s.id)} className="flex items-center gap-2.5 flex-1 min-w-0 text-left">
                        <span
                          className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 border"
                          style={{
                            background: learned ? "rgba(99,102,241,0.15)" : "rgba(255,255,255,0.04)",
                            borderColor: learned ? "rgba(129,140,248,0.4)" : "rgba(255,255,255,0.08)",
                          }}
                        >
                          <Icn name={s.icon} className="w-4.5 h-4.5" style={{ color: learned ? "#a5b4fc" : "#475569" }} />
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <span className={clsx("text-[12px] font-bold truncate", learned ? "text-slate-100" : "text-slate-500")}>{s.name}</span>
                            {s.tier === 2 && <Chip color="#fbbf24" className="!text-[8px]">Bí kỹ</Chip>}
                          </div>
                          <div className="flex items-center gap-1 mt-0.5">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <span key={i} className={clsx("w-3 h-1 rounded-full", i < lv ? "bg-indigo-400" : "bg-white/10")} />
                            ))}
                            <span className="text-[9px] text-slate-500 ml-1 font-semibold">{lv}/5</span>
                            <span className="text-[9px] text-cyan-400/80 font-semibold ml-1 flex items-center gap-0.5">
                              <span className="text-[10px]">⚄</span> {s.cost[Math.max(0, dlv - 1)]}
                            </span>
                          </div>
                        </div>
                      </button>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          onClick={() => toggleLoadout(s.id)}
                          title={carried ? "Gỡ khỏi đội hình skill" : "Mang vào trận"}
                          disabled={!learned && !carried}
                          className={clsx(
                            "text-[10px] font-black px-2 py-1.5 rounded-lg border transition-all",
                            carried
                              ? "bg-indigo-500/30 border-indigo-400/60 text-indigo-200"
                              : "border-white/10 text-slate-500 hover:text-slate-300",
                            !learned && "opacity-30",
                          )}
                        >
                          {carried ? "ĐANG MANG" : "MANG"}
                        </button>
                        {nextCost ? (
                          <button
                            onClick={() => learn(s.id, s.tier)}
                            disabled={!canAfford}
                            className={clsx(
                              "text-[10px] font-black px-2.5 py-1.5 rounded-lg transition-all min-w-[74px]",
                              canAfford ? "bg-amber-400 text-amber-950 hover:brightness-110" : "bg-white/[0.05] text-slate-500",
                            )}
                            title={`${nextCost.points} điểm · ${nextCost.gold} vàng`}
                          >
                            {lv === 0 ? "HỌC" : "+1"} · {nextCost.points}đ {nextCost.gold}v
                          </button>
                        ) : (
                          <span className="text-[10px] font-black px-2 py-1.5 text-amber-400">MAX</span>
                        )}
                      </div>
                    </div>
                    {expanded && (
                      <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} className="overflow-hidden">
                        <div className="px-3 pb-3 pt-1 text-[11px] text-slate-300/85 leading-relaxed border-t border-white/5">
                          <span className="text-indigo-300 font-semibold">{lv === 0 ? "Khi học (cấp 1): " : `Cấp ${dlv}: `}</span>
                          {describeSkill(s, dlv)}
                        </div>
                      </motion.div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* ------------------------------ GEAR TAB ------------------------------ */}
          {tab === "gear" && (
            <div className="space-y-3">
              {(["weapon", "armor", "accessory"] as ItemSlot[]).map((slot) => {
                const eq = equip.find((i) => ITEM_MAP.get(i.defId)?.slot === slot);
                const eqDef = eq ? ITEM_MAP.get(eq.defId) : null;
                return (
                  <div key={slot} className="rounded-xl border border-white/8 bg-white/[0.03] p-3 flex items-center gap-3">
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center border shrink-0"
                      style={{
                        background: eqDef ? `${RARITY_COLORS[eqDef.rarity]}18` : "rgba(255,255,255,0.04)",
                        borderColor: eqDef ? `${RARITY_COLORS[eqDef.rarity]}55` : "rgba(255,255,255,0.08)",
                        borderStyle: eqDef ? "solid" : "dashed",
                      }}
                    >
                      <Icn name={eqDef?.icon ?? "plus"} className="w-5 h-5" style={{ color: eqDef ? RARITY_COLORS[eqDef.rarity] : "#475569" }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-[9px] uppercase tracking-widest text-slate-500 font-bold">{SLOT_LABEL[slot]}</div>
                      {eqDef ? (
                        <>
                          <div className="text-sm font-bold" style={{ color: RARITY_COLORS[eqDef.rarity] }}>
                            {eqDef.name} {eq && eq.level > 0 ? <span className="text-emerald-300">+{eq.level}</span> : ""}
                          </div>
                          <div className="text-[10px] text-emerald-300/90">
                            {formatBonus(
                              Object.fromEntries(
                                Object.entries(eqDef.stats).map(([k, v]) => [
                                  k,
                                  (v as number) * (1 + (eq ? eq.level : 0) * 0.15),
                                ])
                              )
                            )}
                          </div>
                        </>
                      ) : (
                        <div className="text-xs text-slate-500 italic">Slot trống — có thể lắp trang bị</div>
                      )}
                    </div>
                    <div className="flex gap-1.5 shrink-0">
                      {eq && (
                        <Btn variant="ghost" className="!px-2.5 !py-1.5 !text-[11px]" onClick={() => mutate("unequip", { itemId: eq.id }).then(() => sfx("equip")).catch(() => {})}>
                          Tháo
                        </Btn>
                      )}
                      <Btn variant="primary" className="!px-2.5 !py-1.5 !text-[11px]" onClick={() => setPickSlot(slot)}>
                        {eq ? "Đổi" : "Lắp"}
                      </Btn>
                    </div>
                  </div>
                );
              })}
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Mỗi class dùng loại vũ khí riêng: khiên cho Đỡ Đòn, trượng cho Hỗ Trợ, kiếm/cung cho Tấn Công — không dùng chéo được.
                Trang sức dùng chung cho mọi class.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* item picker */}
      {pickSlot && (
        <ItemPicker
          char={c}
          slot={pickSlot}
          onClose={() => setPickSlot(null)}
        />
      )}
    </Modal>
  );
}

import type { StatBonus } from "@/game/types";

export function formatBonus(stats: StatBonus): string {
  const L: Record<string, string> = {
    hp: "HP", hpPct: "HP%", atk: "Công", atkPct: "Công%", def: "Thủ", defPct: "Thủ%",
    dice: "Xúc xắc", crit: "Chí mạng", critDmg: "STCM", effectRes: "Kháng HƯ",
  };
  return Object.entries(stats)
    .filter(([, v]) => v)
    .map(([k, v]) => {
      const isPct = k.endsWith("Pct") || k === "crit" || k === "critDmg" || k === "effectRes";
      return `+${isPct ? Math.round((v as number) * 100) + "%" : v} ${L[k] ?? k}`;
    })
    .join(" · ");
}

// ------------------------------ item picker ---------------------------------
function ItemPicker({ char, slot, onClose }: { char: CharacterInstance; slot: ItemSlot; onClose: () => void }) {
  const { items, mutate } = useGame();
  const def = CHAR_MAP.get(char.defId)!;

  const candidates: { item: ItemInstance; d: NonNullable<ReturnType<typeof ITEM_MAP.get>>; usable: boolean }[] =
    items
      .map((item) => ({ item, d: ITEM_MAP.get(item.defId)!, usable: true }))
      .filter((x) => x.d && x.d.slot === slot)
      .map((x) => ({ ...x, usable: !x.d.cls || x.d.cls === def.classId }))
      .filter((x) => x.item.equippedBy === null || x.item.equippedBy === char.id)
      .sort((a, b) => (a.usable === b.usable ? 0 : a.usable ? -1 : 1));

  return (
    <div className="absolute inset-0 z-20 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div className="w-full max-w-md max-h-[70vh] overflow-y-auto rounded-2xl border border-white/10 bg-[#141830] p-4" onClick={(e) => e.stopPropagation()}>
        <h4 className="font-bold text-sm mb-3 flex items-center gap-2">
          Chọn {SLOT_LABEL[slot]} cho <span className="text-indigo-300">{def.name}</span>
        </h4>
        {candidates.length === 0 && <div className="text-slate-500 text-sm py-8 text-center">Kho đồ trống — đánh ải để nhặt trang bị!</div>}
        <div className="space-y-1.5">
          {candidates.map(({ item, d, usable }) => (
            <button
              key={item.id}
              disabled={!usable}
              onClick={async () => {
                await mutate("equip", { itemId: item.id, charId: char.id }).then(() => sfx("equip")).catch(() => {});
                onClose();
              }}
              className={clsx(
                "w-full flex items-center gap-3 rounded-xl border p-2.5 text-left transition-all",
                usable ? "border-white/10 bg-white/[0.03] hover:bg-white/[0.07] active:scale-[0.98]" : "border-white/5 opacity-40",
                item.equippedBy === char.id && "border-indigo-400/50 bg-indigo-500/10",
              )}
            >
              <span
                className="w-9 h-9 rounded-lg flex items-center justify-center border shrink-0"
                style={{ background: `${RARITY_COLORS[d.rarity]}15`, borderColor: `${RARITY_COLORS[d.rarity]}44` }}
              >
                <Icn name={d.icon} className="w-4 h-4" style={{ color: RARITY_COLORS[d.rarity] }} />
              </span>
              <div className="flex-1 min-w-0">
                <div className="text-xs font-bold" style={{ color: usable ? RARITY_COLORS[d.rarity] : "#64748b" }}>
                  {d.name} {item.equippedBy === char.id && <span className="text-indigo-300 text-[9px]">(đang mặc)</span>}
                </div>
                <div className="text-[10px] text-slate-400 truncate">{formatBonus(d.stats)}</div>
              </div>
              {!usable && <span className="text-[9px] font-bold text-rose-400 shrink-0">SAI CLASS</span>}
              {d.rarity !== "R" && <Chip color={RARITY_COLORS[d.rarity]}>{d.rarity}</Chip>}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
