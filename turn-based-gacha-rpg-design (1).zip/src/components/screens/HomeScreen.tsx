"use client";

import { motion } from "framer-motion";
import { useGame, type View } from "@/game/store";
import { Btn, Icn } from "../ui";
import { STAGES } from "@/game/data/enemies";
import { sfx } from "@/game/sfx";

export default function HomeScreen() {
  const { player, characters, items, setView } = useGame();

  const go = (v: View) => {
    sfx("click");
    setView(v);
  };

  const cards: { view: View; icon: string; title: string; desc: string; grad: string }[] = [
    { view: "summon", icon: "dices", title: "Triệu Hồi", desc: "Quay nhân vật mới — SSR 3%", grad: "from-fuchsia-500/25 to-indigo-900/30" },
    { view: "team", icon: "swords", title: "Đội Hình", desc: "Sắp xếp 5 chiến binh", grad: "from-rose-500/25 to-red-900/30" },
    { view: "stages", icon: "play", title: "Chiến Đấu", desc: "Chinh phạt 10 ải quái", grad: "from-emerald-500/25 to-teal-900/30" },
    { view: "roster", icon: "users", title: "Tướng", desc: "Skill tree, trang bị", grad: "from-sky-500/25 to-blue-900/30" },
  ];

  return (
    <div className="relative min-h-full">
      {/* hero */}
      <div className="relative h-52 md:h-64 overflow-hidden">
        <img src="/images/home-hero.jpg" alt="" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0b0e1a] via-transparent to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0b0e1a]/70 via-transparent to-transparent" />
        <div className="absolute bottom-4 left-4 md:left-6">
          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-2xl md:text-4xl font-black tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-100 to-indigo-200 drop-shadow"
          >
            TRIỆU HỒI KỶ NGUYÊN
          </motion.h1>
          <p className="text-slate-300/90 text-xs md:text-sm mt-1 max-w-md">
            Gacha turn-based RPG — xây đội 5 ngưởi, khai phá skill tree, chinh phục Ma Vương.
          </p>
        </div>
        <div className="absolute bottom-4 right-4 hidden md:block">
          <Btn variant="gold" onClick={() => go("stages")}>
            <Icn name="play" className="w-4 h-4" /> VÀO TRẬN
          </Btn>
        </div>
      </div>

      <div className="px-4 md:px-6 py-4 space-y-5 max-w-5xl mx-auto">
        {/* stats */}
        <div className="grid grid-cols-3 gap-2 md:gap-3">
          {[
            { icon: "users", label: "Tướng sở hữu", value: characters.length, color: "#93c5fd" },
            { icon: "award", label: "Ải đã vượt", value: `${player?.cleared.length ?? 0}/${STAGES.length}`, color: "#4ade80" },
            { icon: "backpack", label: "Trang bị", value: items.length, color: "#fbbf24" },
          ].map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
              className="rounded-2xl border border-white/8 bg-white/[0.04] p-3 md:p-4 flex items-center gap-3"
            >
              <span
                className="w-9 h-9 md:w-11 md:h-11 rounded-xl flex items-center justify-center shrink-0"
                style={{ background: `${s.color}1c`, color: s.color }}
              >
                <Icn name={s.icon} className="w-5 h-5" />
              </span>
              <div className="min-w-0">
                <div className="text-lg md:text-2xl font-black tabular-nums leading-none">{s.value}</div>
                <div className="text-[10px] md:text-xs text-slate-400 mt-1 truncate">{s.label}</div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* nav cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-3">
          {cards.map((c, i) => (
            <motion.button
              key={c.view}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + i * 0.05 }}
              onClick={() => go(c.view)}
              className={`group relative overflow-hidden rounded-2xl border border-white/8 bg-gradient-to-br ${c.grad} p-4 md:p-5 text-left transition-transform hover:scale-[1.02] active:scale-95`}
            >
              <Icn name={c.icon} className="w-7 h-7 md:w-8 md:h-8 text-white/90 mb-3 transition-transform group-hover:scale-110" />
              <div className="font-bold text-sm md:text-base">{c.title}</div>
              <div className="text-[10px] md:text-xs text-slate-300/70 mt-0.5">{c.desc}</div>
              <Icn
                name="chevron-right"
                className="absolute right-3 bottom-3 w-4 h-4 text-white/30 transition-transform group-hover:translate-x-1"
              />
            </motion.button>
          ))}
        </div>

        {/* guide */}
        <div className="rounded-2xl border border-indigo-400/15 bg-indigo-500/[0.06] p-4 md:p-5">
          <h3 className="font-bold text-indigo-200 mb-2 text-sm flex items-center gap-2">
            <Icn name="info" className="w-4 h-4" /> Hướng dẫn nhanh
          </h3>
          <ul className="text-xs md:text-sm text-slate-300/80 space-y-1.5 leading-relaxed">
            <li>• <b>Triệu Hồi</b> bằng ngọc để nhận tướng mới. Tướng trùng vẫn giữ lại như bản sao riêng.</li>
            <li>• Mỗi tướng có <b>20 kỹ năng</b> trong skill tree — lên cấp nhận điểm kỹ năng để học & nâng tối đa 5 cấp.</li>
            <li>• Chọn <b>3 kỹ năng mang vào trận</b> (kèm đòn đánh thường) trong mục Tướng → Kỹ năng → Mang theo.</li>
            <li>• Trang bị rơi từ ải quái: khiên chỉ cho <b>Đỡ Đòn</b>, trượng chỉ cho <b>Hỗ Trợ</b>... giữ cân bằng game.</li>
            <li>• Hiệu ứng: <b>Thiêu đốt</b> đốt máu theo lượt, <b>Đóng băng</b> khóa lượt, <b>Độc</b> giảm công/thủ, <b>Tê liệt</b> khóa kỹ năng.</li>
            <li>• <b>Khắc Chế Hệ (X1.5 sát thương)</b>: <b>Lửa</b> ⇄ <b>Băng</b> (khắc qua lại), <b>Sét</b> ⇄ <b>Độc</b> (khắc qua lại), <b>Thánh</b> ⇄ <b>Hắc Ám</b> (khắc qua lại). Hãy chọn skill hệ khắc chế để hạ gục quái dễ dàng!</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
