"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import clsx from "clsx";
import { useGame } from "@/game/store";
import { CHAR_MAP } from "@/game/data/characters";
import { computeStats, powerScore } from "@/game/engine/stats";
import { Btn, Chip, CLASS_META, Icn, Portrait, Stars } from "../ui";
import { CLASS_LABEL } from "@/game/types";
import { sfx } from "@/game/sfx";

export default function TeamScreen() {
  const { player, characters, items, mutate, setView } = useGame();
  const [picking, setPicking] = useState<number | null>(null); // slot index đang chọn

  const team = player?.team ?? [];
  const teamChars = team.map((id) => characters.find((c) => c.id === id)).filter(Boolean);

  const totalPower = teamChars.reduce((sum, c) => {
    const def = CHAR_MAP.get(c!.defId);
    if (!def) return sum;
    const stats = computeStats(def, c!.level, items.filter((i) => i.equippedBy === c!.id));
    return sum + powerScore(stats, c!.skillLevels);
  }, 0);

  const classCount = { tank: 0, attacker: 0, support: 0 };
  for (const c of teamChars) {
    const def = CHAR_MAP.get(c!.defId);
    if (def) classCount[def.classId]++;
  }

  async function removeAt(slot: number) {
    const next = team.filter((_, i) => i !== slot);
    await mutate("setTeam", { ids: next }).catch(() => {});
  }

  async function assignTo(slot: number, charId: number) {
    let next = [...team];
    next = next.filter((id) => id !== charId); // chống trùng
    if (slot >= next.length) next.push(charId);
    else next[slot] = charId;
    sfx("equip");
    await mutate("setTeam", { ids: next.slice(0, 5) }).catch(() => {});
    setPicking(null);
  }

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-1 flex-wrap gap-2">
        <h2 className="text-xl font-black tracking-wide">ĐỘI HÌNH <span className="text-slate-400 text-sm font-semibold">(tối đa 5)</span></h2>
        <div className="flex items-center gap-2">
          <Chip color="#fbbf24">Lực chiến {totalPower.toLocaleString()}</Chip>
          <Btn variant="gold" onClick={() => { sfx("click"); setView("stages"); }} disabled={team.length === 0}>
            <Icn name="play" className="w-4 h-4" /> Chiến
          </Btn>
        </div>
      </div>
      <p className="text-xs text-slate-500 mb-4">
        {(["tank", "attacker", "support"] as const).map((k) => (
          <span key={k} className="mr-3 inline-flex items-center gap-1">
            <Icn name={CLASS_META[k].icon} className="w-3.5 h-3.5" style={{ color: CLASS_META[k].color }} />
            {CLASS_META[k].label}: <b>{classCount[k]}</b>
          </span>
        ))}
        <span className="text-slate-600">— gợi ý: ít nhất 1 đỡ đòn + 1 hỗ trợ.</span>
      </p>

      {/* slots */}
      <div className="grid grid-cols-5 gap-2 md:gap-3 mb-6">
        {Array.from({ length: 5 }).map((_, slot) => {
          const c = team[slot] != null ? characters.find((x) => x.id === team[slot]) : null;
          const def = c ? CHAR_MAP.get(c.defId) : null;
          return (
            <motion.div
              key={slot}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: slot * 0.05 }}
              className={clsx(
                "relative rounded-2xl border aspect-[3/4] flex flex-col items-center justify-center gap-1.5 p-2 transition-all",
                c ? "border-white/15 bg-white/[0.04]" : "border-dashed border-white/15 bg-white/[0.015]",
                picking === slot && "ring-2 ring-indigo-400",
              )}
            >
              {c && def ? (
                <>
                  <Portrait icon={def.icon} element={def.element} rarity={def.rarity} size={54} artPath={def.art} />
                  <div className="text-[11px] font-bold truncate w-full text-center">{def.name}</div>
                  <Stars rarity={def.rarity} />
                  <span className="text-[9px] text-slate-400">Lv.{c.level}</span>
                  <Chip color={CLASS_META[def.classId].color} className="!text-[8px] !px-1.5">{CLASS_LABEL[def.classId]}</Chip>
                  <div className="absolute top-1 left-1 right-1 flex justify-between">
                    <button
                      onClick={() => setPicking(picking === slot ? null : slot)}
                      className="w-6 h-6 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center"
                      title="Đổi tướng"
                    >
                      <Icn name="rotate-ccw" className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => removeAt(slot)}
                      className="w-6 h-6 rounded-lg bg-rose-500/20 hover:bg-rose-500/40 text-rose-300 flex items-center justify-center"
                      title="Rút khỏi đội"
                    >
                      <Icn name="x" className="w-3 h-3" />
                    </button>
                  </div>
                </>
              ) : (
                <button onClick={() => setPicking(picking === slot ? null : slot)} className="flex flex-col items-center gap-2 text-slate-500 hover:text-indigo-300 transition-colors">
                  <span className="w-10 h-10 rounded-xl bg-white/[0.05] flex items-center justify-center">
                    <Icn name="plus" className="w-5 h-5" />
                  </span>
                  <span className="text-[10px] font-bold uppercase tracking-wider">Slot {slot + 1}</span>
                </button>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* picker */}
      {picking !== null && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <h3 className="text-xs font-bold uppercase tracking-[0.2em] text-slate-400 mb-2">Chọn tướng vào slot {picking + 1}</h3>
          <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-8 gap-2 max-h-[45vh] overflow-y-auto pr-1">
            {characters.map((c) => {
              const def = CHAR_MAP.get(c.defId)!;
              const already = team.includes(c.id);
              return (
                <button
                  key={c.id}
                  onClick={() => assignTo(picking, c.id)}
                  className={clsx(
                    "relative rounded-xl border p-2 flex flex-col items-center gap-1 transition-all hover:scale-[1.04] active:scale-95 bg-white/[0.03]",
                    already ? "border-amber-400/40 opacity-60" : "border-white/10 hover:border-indigo-400/50",
                  )}
                >
                  <Portrait icon={def.icon} element={def.element} rarity={def.rarity} size={42} artPath={def.art} />
                  <span className="text-[10px] font-bold text-center leading-tight truncate w-full">{def.name}</span>
                  <span className="text-[8px] text-slate-400">Lv.{c.level}</span>
                  {already && <span className="absolute top-1 right-1 text-[8px] font-black text-amber-300">TRONG ĐỘI</span>}
                </button>
              );
            })}
          </div>
        </motion.div>
      )}
    </div>
  );
}
