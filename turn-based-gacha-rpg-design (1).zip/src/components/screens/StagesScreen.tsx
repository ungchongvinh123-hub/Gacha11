"use client";

import { motion } from "framer-motion";
import clsx from "clsx";
import { useGame } from "@/game/store";
import { STAGES } from "@/game/data/enemies";
import { Btn, Chip, Icn } from "../ui";
import { sfx } from "@/game/sfx";

export default function StagesScreen() {
  const { player, startBattle, toast } = useGame();
  const cleared = player?.cleared ?? [];
  const zones = [...new Set(STAGES.map((s) => s.zone))];

  function enter(stageId: string, locked: boolean) {
    if (locked) return;
    if ((player?.team.length ?? 0) === 0) {
      toast("Đội hình trống — hãy thêm tướng vào đội trước!", "error");
      return;
    }
    sfx("click");
    startBattle(stageId);
  }

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto">
      <h2 className="text-xl font-black tracking-wide mb-1">ẢI CHIẾN ĐẤU</h2>
      <p className="text-xs text-slate-500 mb-5">Vượt ải để mở khóa ải tiếp theo. Thưởng lần đầu: ngọc quý. Vật phẩm rơi theo tỉ lệ của từng ải.</p>

      {zones.map((zone) => (
        <div key={zone} className="mb-6">
          <h3 className="text-xs font-black uppercase tracking-[0.3em] text-indigo-300/80 mb-2">{zone}</h3>
          <div className="space-y-2">
            {STAGES.filter((s) => s.zone === zone).map((s) => {
              const done = cleared.includes(s.id);
              const locked = s.idx > 0 && !cleared.includes(STAGES[s.idx - 1].id);
              return (
                <motion.div
                  key={s.id}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: s.idx * 0.04 }}
                  className={clsx(
                    "rounded-2xl border p-3 md:p-4 flex items-center gap-3 transition-all",
                    locked
                      ? "border-white/5 bg-white/[0.015] opacity-50"
                      : done
                        ? "border-emerald-500/25 bg-emerald-500/[0.05]"
                        : "border-white/10 bg-white/[0.04] hover:border-indigo-400/40",
                  )}
                >
                  <div
                    className={clsx(
                      "w-11 h-11 rounded-xl flex items-center justify-center font-black text-lg shrink-0 border",
                      done
                        ? "bg-emerald-500/15 border-emerald-400/40 text-emerald-300"
                        : locked
                          ? "bg-white/[0.04] border-white/10 text-slate-600"
                          : "bg-indigo-500/15 border-indigo-400/40 text-indigo-300",
                    )}
                  >
                    {locked ? <Icn name="lock" className="w-5 h-5" /> : done ? <Icn name="check" className="w-5 h-5" /> : s.idx + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-sm">{s.name}</span>
                      <Chip color="#94a3b8">Lv.{s.recLevel}+</Chip>
                      <Chip color="#f472b6">{s.waves.length} đợt</Chip>
                    </div>
                    <div className="flex items-center gap-3 mt-1 text-[10px] text-slate-400">
                      <span className="flex items-center gap-1"><Icn name="coins" className="w-3 h-3 text-amber-300" /> {s.gold}</span>
                      <span className="flex items-center gap-1"><Icn name="star" className="w-3 h-3 text-emerald-300" /> {s.exp} exp</span>
                      <span className="flex items-center gap-1"><Icn name="gem" className="w-3 h-3 text-cyan-300" /> {s.gemsFirst} (đầu tiên)</span>
                      <span className="flex items-center gap-1"><Icn name="backpack" className="w-3 h-3 text-fuchsia-300" /> rơi {s.dropRolls}x</span>
                    </div>
                  </div>
                  <Btn
                    variant={done ? "ghost" : "primary"}
                    disabled={locked}
                    onClick={() => enter(s.id, locked)}
                    className="shrink-0"
                  >
                    {done ? "Đánh lại" : "Vào ải"}
                  </Btn>
                </motion.div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}
