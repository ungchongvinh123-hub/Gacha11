"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import clsx from "clsx";
import { useGame } from "@/game/store";
import { ITEM_MAP, SLOT_LABEL } from "@/game/data/items";
import { CHAR_MAP } from "@/game/data/characters";
import type { ItemInstance, ItemSlot } from "@/game/types";
import { CLASS_LABEL, RARITY_COLORS } from "@/game/types";
import { Btn, Chip, Icn, Modal } from "../ui";
import { formatBonus } from "./RosterScreen";
import { sfx } from "@/game/sfx";

export default function InventoryScreen() {
  const { items, characters, mutate } = useGame();
  const [filter, setFilter] = useState<ItemSlot | "all">("all");
  const [sel, setSel] = useState<ItemInstance | null>(null);

  const list = useMemo(
    () =>
      items
        .filter((i) => filter === "all" || ITEM_MAP.get(i.defId)?.slot === filter)
        .sort((a, b) => {
          const order = { SSR: 0, SR: 1, R: 2 };
          const da = ITEM_MAP.get(a.defId)!;
          const db = ITEM_MAP.get(b.defId)!;
          return order[da.rarity] - order[db.rarity] || a.defId.localeCompare(b.defId);
        }),
    [items, filter],
  );

  const selDef = sel ? ITEM_MAP.get(sel.defId) : null;
  const wearer = sel?.equippedBy ? characters.find((c) => c.id === sel.equippedBy) : null;
  const compatible = selDef
    ? characters.filter((c) => !selDef.cls || CHAR_MAP.get(c.defId)?.classId === selDef.cls)
    : [];

  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <h2 className="text-xl font-black tracking-wide">KHO ĐỒ <span className="text-slate-400 text-sm font-semibold">({items.length})</span></h2>
        <div className="flex gap-1.5">
          {(["all", "weapon", "armor", "accessory"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={clsx(
                "px-3 py-1.5 rounded-full text-xs font-bold border transition-all",
                filter === f ? "bg-indigo-500/25 text-indigo-200 border-indigo-400/40" : "bg-white/[0.04] text-slate-400 border-white/8",
              )}
            >
              {f === "all" ? "Tất cả" : SLOT_LABEL[f]}
            </button>
          ))}
        </div>
      </div>

      {list.length === 0 && (
        <div className="text-center py-16 text-slate-500 text-sm">
          Kho đồ trống. Trang bị rơi từ ải chiến đấu — ải càng khó tỉ lệ đồ hiếm càng cao!
        </div>
      )}

      <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-2">
        {list.map((item, i) => {
          const d = ITEM_MAP.get(item.defId)!;
          const equipped = item.equippedBy !== null;
          return (
            <motion.button
              key={item.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: Math.min(i * 0.015, 0.3) }}
              onClick={() => {
                sfx("click");
                setSel(item);
              }}
              className={clsx(
                "relative rounded-xl border p-2 aspect-square flex flex-col items-center justify-center gap-1 transition-all hover:scale-105 active:scale-95",
                equipped ? "border-indigo-400/40" : "border-white/8 hover:border-white/20",
              )}
              style={{ background: `${RARITY_COLORS[d.rarity]}0d`, boxShadow: d.rarity === "SSR" ? `0 0 10px ${RARITY_COLORS.SSR}22` : undefined }}
            >
              <Icn name={d.icon} className="w-6 h-6" style={{ color: RARITY_COLORS[d.rarity] }} />
              <span className="text-[8px] font-bold uppercase tracking-wider animate-pulse" style={{ color: RARITY_COLORS[d.rarity] }}>
                {d.rarity} {item.level > 0 ? `+${item.level}` : ""}
              </span>
              {item.level > 0 && (
                <span className="absolute top-1 left-1.5 text-[9px] font-black text-emerald-300 drop-shadow">
                  +{item.level}
                </span>
              )}
              {equipped && (
                <span className="absolute top-0.5 right-0.5 w-3.5 h-3.5 rounded-full bg-indigo-500 flex items-center justify-center">
                  <Icn name="check" className="w-2 h-2 text-white" />
                </span>
              )}
            </motion.button>
          );
        })}
      </div>

      {sel && selDef && (
        <Modal onClose={() => { setSel(null); }}>
          <div className="p-5 max-h-[88vh] overflow-y-auto">
            <div className="flex items-center gap-3 mb-4">
              <span
                className="w-14 h-14 rounded-2xl flex items-center justify-center border"
                style={{ background: `${RARITY_COLORS[selDef.rarity]}15`, borderColor: `${RARITY_COLORS[selDef.rarity]}55` }}
              >
                <Icn name={selDef.icon} className="w-7 h-7" style={{ color: RARITY_COLORS[selDef.rarity] }} />
              </span>
              <div>
                <div className="font-black text-lg flex items-center gap-1.5" style={{ color: RARITY_COLORS[selDef.rarity] }}>
                  {selDef.name} {sel.level > 0 && <span className="text-emerald-300">+{sel.level}</span>}
                </div>
                <div className="flex gap-1.5 mt-1">
                  <Chip color="#94a3b8">{SLOT_LABEL[selDef.slot]}</Chip>
                  <Chip color={RARITY_COLORS[selDef.rarity]}>{selDef.rarity}</Chip>
                  <Chip color="#a5b4fc">{selDef.cls ? `Chỉ ${CLASS_LABEL[selDef.cls]}` : "Mọi class"}</Chip>
                </div>
              </div>
            </div>
            
            {/* Hiển thị chi tiết chỉ số sau cường hóa */}
            <div className="rounded-xl border border-emerald-400/20 bg-emerald-400/[0.06] p-3 text-sm text-emerald-200 mb-2">
              <div className="font-bold text-xs text-slate-400 mb-1">Chỉ số hiện tại:</div>
              {formatBonus(
                Object.fromEntries(
                  Object.entries(selDef.stats).map(([k, v]) => [
                    k,
                    (v as number) * (1 + sel.level * 0.15),
                  ])
                )
              )}
              {sel.level > 0 && (
                <div className="text-[10px] text-emerald-400 mt-1">
                  (Đã cộng thêm +{(sel.level * 15)}% chỉ số gốc từ cấp cường hóa +{sel.level})
                </div>
              )}
            </div>

            {/* Hiển thị Nội tại đặc biệt (Passives) nếu có — hỗ trợ nhiều nội tại/trang bị */}
            {selDef.passives && selDef.passives.length > 0 && (
              <div className="rounded-xl border border-fuchsia-400/20 bg-fuchsia-500/[0.06] p-3 mb-3">
                <div className="font-black text-[10px] text-fuchsia-400 uppercase tracking-widest mb-1.5 flex items-center gap-1">
                  <Icn name="sparkles" className="w-3.5 h-3.5 text-fuchsia-400" /> HIỆU ỨNG ĐẶC BIỆT ({selDef.passives.length})
                </div>
                <div className="space-y-1">
                  {selDef.passives.map((p, idx) => (
                    <div key={idx} className="flex items-start gap-1.5 text-xs text-fuchsia-200 leading-snug">
                      <Icn name="check" className="w-3 h-3 text-fuchsia-400 mt-0.5 shrink-0" />
                      <span>{p.desc}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Khối Cường Hóa bằng Gold */}
            <div className="rounded-xl border border-indigo-400/15 bg-indigo-500/[0.03] p-3 mb-4">
              <div className="flex items-center justify-between text-xs font-bold text-indigo-300 mb-2">
                <span>BỆ CƯỜNG HÓA</span>
                <span>Tối đa +15</span>
              </div>
              {sel.level >= 15 ? (
                <div className="text-center text-xs font-bold text-amber-400 py-1">
                  ★ TRANG BỊ ĐÃ ĐẠT CẤP CỰC ĐẠI (+15) ★
                </div>
              ) : (
                (() => {
                  const baseCost = selDef.rarity === "SSR" ? 2200 : selDef.rarity === "SR" ? 1100 : 500;
                  const goldCost = Math.round(baseCost * (1 + sel.level * 0.45));
                  const canUpgradeUnequipped = sel.level < 3;
                  const canUpgradeEquipped = wearer ? sel.level + 1 <= wearer.level : false;
                  
                  let blockReason = "";
                  if (!sel.equippedBy && !canUpgradeUnequipped) {
                    blockReason = "Trang bị tự do tối đa +3. Hãy lắp vào tướng tương ứng để vượt giới hạn!";
                  } else if (sel.equippedBy && !canUpgradeEquipped) {
                    blockReason = `Cấp cường hóa (+${sel.level + 1}) không được vượt quá cấp độ tướng đang mặc (Lv.${wearer?.level})!`;
                  }

                  return (
                    <div className="space-y-2">
                      <div className="text-[11px] text-slate-300">
                        Nâng cấp tiếp theo: <b className="text-emerald-300">+{sel.level + 1}</b> (Tăng <b className="text-emerald-300">+15%</b> chỉ số gốc)
                      </div>
                      {blockReason ? (
                        <div className="text-[10px] text-rose-300 bg-rose-500/10 border border-rose-500/20 rounded p-1.5 leading-normal">
                          ⚠️ {blockReason}
                        </div>
                      ) : (
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-[11px] text-slate-400 flex items-center gap-1">
                            Chi phí: <Icn name="coins" className="w-3 h-3 text-amber-300" /> {goldCost.toLocaleString()} vàng
                          </span>
                          <button
                            onClick={async () => {
                              try {
                                const data = await mutate<{ newLevel: number }>("upgradeItem", { itemId: sel.id });
                                sfx("levelup");
                                setSel({ ...sel, level: data.newLevel });
                              } catch {}
                            }}
                            className="bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-black text-xs px-3 py-1.5 rounded-lg active:scale-95"
                          >
                            CƯỜNG HÓA
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })()
              )}
            </div>
            {wearer && (
              <div className="text-xs text-slate-400 mb-3">
                Đang mặc trên <b className="text-indigo-300">{CHAR_MAP.get(wearer.defId)?.name}</b>
              </div>
            )}
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Trang bị cho</div>
            <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1 mb-4">
              {compatible.length === 0 && <div className="text-slate-500 text-xs py-4 text-center">Không có tướng nào dùng được món này.</div>}
              {compatible.map((c) => {
                const d = CHAR_MAP.get(c.defId)!;
                return (
                  <button
                    key={c.id}
                    onClick={async () => {
                      await mutate("equip", { itemId: sel.id, charId: c.id }).then(() => sfx("equip")).catch(() => {});
                      setSel(null);
                    }}
                    className="w-full flex items-center gap-2.5 rounded-xl border border-white/8 bg-white/[0.03] hover:bg-white/[0.07] p-2 text-left transition-all active:scale-[0.98]"
                  >
                    <span className="text-xs font-bold flex-1">{d.name}</span>
                    <span className="text-[10px] text-slate-400">Lv.{c.level} · {CLASS_LABEL[d.classId]}</span>
                    <Icn name="chevron-right" className="w-3.5 h-3.5 text-slate-500" />
                  </button>
                );
              })}
            </div>
            {sel.equippedBy !== null && (
              <Btn
                variant="ghost"
                className="w-full"
                onClick={async () => {
                  await mutate("unequip", { itemId: sel.id }).then(() => sfx("equip")).catch(() => {});
                  setSel(null);
                }}
              >
                Tháo ra khỏi tướng
              </Btn>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
}
