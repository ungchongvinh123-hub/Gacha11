"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import clsx from "clsx";
import { useGame } from "@/game/store";
import { CHAR_MAP } from "@/game/data/characters";
import { STAGE_MAP } from "@/game/data/enemies";
import {
  BattleEngine,
  makePlayerUnit,
  maxHp,
  diceCount,
  isShocked,
  type Action,
  type BattleEvent,
  type BattleUnit,
} from "@/game/engine/battle";
import { describeSkill } from "@/game/data/skills";
import { EFFECT_LABEL, RARITY_COLORS } from "@/game/types";
import type { ItemDef } from "@/game/types";
import { ITEM_MAP } from "@/game/data/items";
import { Bar, Btn, EFFECT_META, HP_COLOR, HP_LOW, Icn } from "../ui";
import UnitFigure from "../UnitFigure";
import QteOverlay, { makeQteSpec, type QteSpec } from "../QteOverlay";
import { actionOffensive, type BattleCtx } from "@/game/engine/battle";
import type { QteKind } from "@/game/types";
import { sfx, setSfxEnabled } from "@/game/sfx";

// ---------------------------------------------------------------- types ----
interface Float {
  id: number;
  uid: string;
  text: string;
  color: string;
  icon?: string;
  big?: boolean;
}
interface DispUnit {
  hp: number;
  alive: boolean;
}
interface Banner {
  main: string;
  sub?: string;
  icon?: string;
  color?: string;
}
interface Reward {
  victory: boolean;
  exp: number;
  goldGain: number;
  gemsGain: number;
  dropped: string[];
  levelups: { id: number; from: number; to: number }[];
}

let floatId = 0;

export default function BattleScreen() {
  const { battleStageId, player, characters, items, setView, mutate, fetchState } = useGame();
  const stage = battleStageId ? STAGE_MAP.get(battleStageId) : null;

  const engineRef = useRef<BattleEngine | null>(null);
  const busyRef = useRef(false);
  const [snapVersion, setSnapVersion] = useState(0);
  const [disp, setDisp] = useState<Record<string, DispUnit>>({});
  const [floats, setFloats] = useState<Float[]>([]);
  const [banner, setBanner] = useState<Banner | null>(null);
  const [hits, setHits] = useState<Record<string, number>>({});
  const [lunges, setLunges] = useState<Record<string, number>>({});
  const [busy, setBusy] = useState(false);
  const [selectedUid, setSelectedUid] = useState<string | null>(null);
  const [pending, setPending] = useState<Action | null>(null);
  const [result, setResult] = useState<Reward | null>(null);
  const [auto, setAuto] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [sound, setSound] = useState(true);
  const [skillInfo, setSkillInfo] = useState<string | null>(null);
  const [zoom, setZoom] = useState(false); // phóng to đều CẢ 2 bên khi có đòn đánh
  const zoomTimer = useRef<number | null>(null);
  const [diceUi, setDiceUi] = useState<{ faces: number[]; total: number } | null>(null);
  const [qteSpec, setQteSpec] = useState<QteSpec | null>(null);
  const [clash, setClash] = useState(false); // đối đầu: phóng to 2 bên khi có QTE
  const qteSettleRef = useRef<((mult: number) => void) | null>(null);
  const autoRef = useRef(false);
  autoRef.current = auto;
  const submittedRef = useRef(false);

  function pulseZoom() {
    setZoom(true);
    if (zoomTimer.current) window.clearTimeout(zoomTimer.current);
    zoomTimer.current = window.setTimeout(() => setZoom(false), 320);
  }

  /** Chọn đơn vị + đổ xúc xắc trước khi hành động (mỗi lượt 1 lần/nhân vật). */
  async function selectAndRoll(uid: string) {
    const eng = engineRef.current;
    if (!eng || busyRef.current) return;
    const u = eng.unit(uid);
    if (!u || !u.alive || u.acted) return;
    setPending(null);
    setSelectedUid(uid);
    if (u.energy !== undefined) return; // đã roll ở lượt hiện tại
    busyRef.current = true;
    setBusy(true);
    const r = eng.roll(uid);
    if (r) {
      setDiceUi(r);
      sfx("gacha");
      // Thời gian THẬT cố định (không bị tốc độ x2 nuốt) để đủ đọc điểm
      await realDelay(1800);
      setDiceUi(null);
      setSnapVersion((v) => v + 1);
    }
    busyRef.current = false;
    setBusy(false);
  }

  /** Chạy QTE: hiện overlay và chờ người chơi hoàn thành cử chỉ → trả hệ số.
   *  mode 'skill': dễ → thưởng sát thương; mode 'block': khó, nhịp đổi → chặn đòn. */
  const runQte = (mode: "skill" | "block", kind?: QteKind) =>
    new Promise<number>((resolve) => {
      if (autoRef.current) {
        resolve(mode === "skill" ? 1 : 0.9); // tự động: không show QTE, mức trung bình
        return;
      }
      pulseZoom(); // trận phóng to nhẹ đúng lúc QTE xuất hiện ở giữa 2 bên
      const spec = makeQteSpec(mode, kind);
      qteSettleRef.current = (mult) => resolve(mult);
      setQteSpec(spec);
    });

  function skillDefFor(action: Action, uid?: string): { qte?: string } | null {
    const eng = engineRef.current;
    if (!eng) return null;
    const u = uid ? eng.unit(uid) : eng.unit(selectedUid ?? "");
    if (!u || action.kind !== "skill") return null;
    const sk = u.skills[action.skillIdx];
    return sk ? { qte: sk.def.qte } : null;
  }

  function settleQte(mult: number) {
    const fn = qteSettleRef.current;
    qteSettleRef.current = null;
    setQteSpec(null);
    fn?.(mult);
  }

  const engine = () => engineRef.current!;
  const snapUnits = engineRef.current?.snapshot().units ?? [];
  void snapVersion; // re-render marker

  const delay = useCallback(
    (ms: number) => new Promise((r) => setTimeout(r, ms / speed)),
    [speed],
  );

  // Độ trễ thời gian THẬT — dùng cho thứ cần đọc kỹ (đổ xúc xắc), không bị x2 đẩy nhanh
  const realDelay = useCallback((ms: number) => new Promise((r) => setTimeout(r, ms)), []);

  // ---------------------------------------------------------- init battle --
  useEffect(() => {
    if (!stage || !player) return;
    const teamChars = player.team
      .map((id) => characters.find((c) => c.id === id))
      .filter((c): c is NonNullable<typeof c> => !!c)
      .slice(0, 5);
    if (teamChars.length === 0) return;
    const units = teamChars.map((c, i) => makePlayerUnit(c, CHAR_MAP.get(c.defId)!, items, i));
    const eng = new BattleEngine(units, stage);
    engineRef.current = eng;
    const d: Record<string, DispUnit> = {};
    for (const u of eng.units) d[u.uid] = { hp: u.hp, alive: u.alive };
    setDisp(d);
    const evs = eng.startSidePhase("player");
    setSnapVersion((v) => v + 1);
    void playEvents(evs, true);
    // (Watchdog sẽ tự đổ xúc xắc cho nhân vật đầu tiên)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stage?.id]);

  // ------------------------------------------------------------- visuals ---
  const pushFloat = useCallback((f: Omit<Float, "id">) => {
    const id = ++floatId;
    setFloats((arr) => [...arr, { ...f, id }].slice(-24));
    setTimeout(() => setFloats((arr) => arr.filter((x) => x.id !== id)), 1100);
  }, []);

  const showBanner = useCallback(
    async (b: Banner, ms = 900) => {
      setBanner(b);
      await delay(ms);
      setBanner((cur) => (cur?.main === b.main ? null : cur));
    },
    [delay],
  );

  function patchDisp(uid: string, patch: Partial<DispUnit>) {
    setDisp((d) => ({ ...d, [uid]: { ...d[uid], ...patch } }));
  }



  async function playEvents(evs: BattleEvent[], instantPhaseBanner = false) {
    const eng = engine();
    for (const ev of evs) {
      switch (ev.t) {
        case "phase": {
          setSnapVersion((v) => v + 1);
          if (!instantPhaseBanner) {
            if (ev.side === "player") sfx("buff");
            void showBanner(
              ev.side === "player"
                ? { main: `HIỆP ${ev.round} — LƯỢT CỦA BẠN`, icon: "shield", color: "#818cf8" }
                : { main: `HIỆP ${ev.round} — LƯỢT ĐỊCH`, icon: "skull", color: "#f87171" },
              800,
            );
            await delay(550);
          }
          break;
        }
        case "dot": {
          sfx(ev.kind === "burn" ? "burn" : "poison");
          pushFloat({
            uid: ev.uid,
            text: `-${ev.amount}`,
            color: ev.kind === "burn" ? "#fb923c" : "#4ade80",
            icon: EFFECT_META[ev.kind].icon,
          });
          setHits((h) => ({ ...h, [ev.uid]: (h[ev.uid] ?? 0) + 1 }));
          const u = eng.unit(ev.uid);
          if (u) patchDisp(ev.uid, { hp: u.hp, alive: u.alive });
          await delay(380);
          break;
        }
        case "regenTick":
          pushFloat({ uid: ev.uid, text: `+${ev.amount}`, color: "#86efac", icon: "sprout" });
          {
            const u = eng.unit(ev.uid);
            if (u) patchDisp(ev.uid, { hp: u.hp });
          }
          await delay(240);
          break;
        case "skipFrozen":
          pushFloat({ uid: ev.uid, text: "ĐÓNG BĂNG", color: "#7dd3fc", icon: "snowflake" });
          sfx("freeze");
          await delay(260);
          break;
        case "action": {
          // Không hiện chữ/tên skill — chỉ lao tới (bên tung đòn) + phóng đều cả 2 bên
          setLunges((l) => ({ ...l, [ev.uid]: (l[ev.uid] ?? 0) + 1 }));
          pulseZoom();
          if (ev.kind === "skill") sfx("buff");
          else sfx("hit");
          await delay(360);
          break;
        }
        case "dmg": {
          sfx(ev.crit ? "crit" : "hit");
          if (!ev.splash) {
            pushFloat({
              uid: ev.uid,
              text: `-${ev.amount}`,
              color: ev.elementRelation === "strong" ? "#fbbf24" : ev.crit ? "#fca5a5" : "#f8fafc",
              icon: ev.crit ? "zap" : undefined,
              big: ev.crit || ev.elementRelation === "strong",
            });
          } else {
            pushFloat({ uid: ev.uid, text: `-${ev.amount}`, color: "#cbd5e1" });
          }
          
          if (ev.elementRelation === "strong" && !ev.splash) {
            pushFloat({
              uid: ev.uid,
              text: "⚡ KHẮC CHẾ (+50%)",
              color: "#fbbf24",
              big: true,
            });
          }

          if (ev.absorbed > 0) pushFloat({ uid: ev.uid, text: `Chắn ${ev.absorbed}`, color: "#7dd3fc", icon: "shield-half" });
          setHits((h) => ({ ...h, [ev.uid]: (h[ev.uid] ?? 0) + 1 }));
          const u = eng.unit(ev.uid);
          if (u) patchDisp(ev.uid, { hp: u.hp, alive: u.alive });
          if (ev.died) {
            pushFloat({ uid: ev.uid, text: "HẠ GỤC", color: "#f87171", icon: "skull" });
            sfx("poison");
          }
          // Bên trúng đòn rung + flash (bên UnitFigure), cả 2 bên phóng đều 1 nhịp
          if (!ev.splash) pulseZoom();
          await delay(ev.crit ? 400 : 280);
          break;
        }
        case "block": {
          // Chặn đòn THÀNH CÔNG: không nhận sát thương — hoạt ảnh phòng thủ khớp kết quả
          sfx("equip");
          pushFloat({ uid: ev.uid, text: "CHẶN!", color: "#4ade80", icon: "shield", big: true });
          const bu = eng.unit(ev.uid);
          if (bu) patchDisp(ev.uid, { hp: bu.hp, alive: bu.alive });
          pulseZoom();
          await delay(420);
          break;
        }
        case "heal":
          sfx("heal");
          pushFloat({ uid: ev.uid, text: `+${ev.amount}`, color: "#4ade80", icon: "heart" });
          {
            const u = eng.unit(ev.uid);
            if (u) patchDisp(ev.uid, { hp: u.hp });
          }
          await delay(300);
          break;
        case "effect": {
          const meta = EFFECT_META[ev.etype];
          if (ev.applied) {
            pushFloat({ uid: ev.uid, text: EFFECT_LABEL[ev.etype], color: meta.color, icon: meta.icon });
            if (ev.etype === "freeze") sfx("freeze");
            else if (ev.etype === "shock") sfx("shock");
            else if (ev.etype === "burn") sfx("burn");
            else if (ev.etype === "poison") sfx("poison");
            else sfx("buff");
          } else {
            pushFloat({ uid: ev.uid, text: "KHÁNG!", color: "#94a3b8", icon: "shield" });
          }
          setSnapVersion((v) => v + 1);
          await delay(240);
          break;
        }
        case "cleanse":
          if (ev.count > 0) {
            pushFloat({ uid: ev.uid, text: `Thanh tẩy x${ev.count}`, color: "#7dd3fc", icon: "sparkles" });
            sfx("heal");
          }
          break;
        case "revive":
          pushFloat({ uid: ev.uid, text: `HỒI SINH +${ev.amount}`, color: "#fcd34d", icon: "cross", big: true });
          sfx("levelup");
          patchDisp(ev.uid, { alive: true, hp: ev.amount });
          await delay(420);
          break;
        case "waveStart":
          setSnapVersion((v) => v + 1);
          {
            const d: Record<string, DispUnit> = {};
            for (const u of eng.units) d[u.uid] = { hp: u.hp, alive: u.alive };
            setDisp(d);
          }
          sfx("rare");
          await showBanner({ main: `ĐỢT ${ev.wave}/${ev.total}`, sub: "Địch mới xuất hiện!", icon: "swords", color: "#f472b6" }, 1000);
          break;
        case "end":
          break;
      }
    }
    setSnapVersion((v) => v + 1);
  }

  // --------------------------------------------------------------- flow ----
  const finishBattle = useCallback(
    async (victory: boolean) => {
      if (submittedRef.current || !stage) return;
      submittedRef.current = true;
      sfx(victory ? "victory" : "defeat");
      await showBanner(
        victory
          ? { main: "CHIẾN THẮNG!", icon: "crown", color: "#fbbf24" }
          : { main: "THẤT BẠI...", icon: "skull", color: "#f87171" },
        1400,
      );
      try {
        const res = await mutate<Reward>("battleResult", {
          stageId: stage.id,
          victory,
          participants: player?.team ?? [],
        });
        setResult(res);
      } catch {
        setResult({ victory, exp: 0, goldGain: 0, gemsGain: 0, dropped: [], levelups: [] });
      }
    },
    [stage, player, mutate, showBanner],
  );

  const endEnemyPhase = useCallback(async () => {
    const eng = engine();
    const evs = eng.startSidePhase("player");
    setPending(null);
    setSelectedUid(null);
    await playEvents(evs);
    if (eng.snapshot().status === "defeat") return finishBattle(false);
    // (Watchdog sẽ đổ xúc xắc cho nhân vật đầu lượt mới)
  }, [finishBattle]); // eslint-disable-line react-hooks/exhaustive-deps

  const runEnemyPhase = useCallback(async () => {
    const eng = engine();
    if (eng.snapshot().status !== "running") return;
    await playEvents(eng.startSidePhase("enemy"));
    if (eng.snapshot().status !== "running") return;
    // AI hành động lần lượt
    let guard = 0;
    while (eng.snapshot().status === "running" && guard++ < 12) {
      const actor = eng.readyUnits("enemy")[0];
      if (!actor) break;
      const action = eng.chooseAIAction(actor);
      // QTE CHẶN ĐÒN (manual): phóng to 2 bên đối đầu → tụ lực → chặn=0 / trật=100%
      let ctx: BattleCtx | undefined;
      if (actionOffensive(actor, action) && eng.aliveOf("player").length > 0 && !autoRef.current) {
        busyRef.current = true;
        setBusy(true);
        setClash(true);
        await delay(420);
        const dMult = await runQte("block"); // 0 = chặn (không nhận sát thương) | 1 = trật (ăn đủ)
        ctx = { defendMult: dMult };
        setClash(false);
        busyRef.current = false;
        setBusy(false);
        setSnapVersion((v) => v + 1);
      }
      let evs: BattleEvent[] = [];
      try {
        evs = eng.perform(actor.uid, action, ctx);
      } catch {
        break;
      }
      await playEvents(evs);
      if (eng.snapshot().status !== "running") break;
      await delay(380);
    }
    if (eng.snapshot().status === "defeat") return finishBattle(false);
    if (eng.snapshot().status === "victory") return finishBattle(true);
    await delay(300);
    await endEnemyPhase();
  }, [delay, finishBattle, endEnemyPhase]); // eslint-disable-line react-hooks/exhaustive-deps

  async function playerAct(action: Action) {
    const eng = engine();
    if (busyRef.current || eng.phase !== "player" || eng.snapshot().status !== "running") return;
    busyRef.current = true;
    setBusy(true);
    setPending(null);
    try {
      // QTE TUNG SKILL: CHỈ skill được đánh dấu qte (khớp loại cử chỉ với skill)
      const sdef = skillDefFor(action);
      let ctx: BattleCtx = {};
      if (action.kind === "skill" && sdef?.qte) {
        // Đối đầu: phóng to 2 bên trước khi QTE tụ lực
        setClash(true);
        await delay(420);
        ctx = { qteMult: await runQte("skill", sdef.qte as QteKind) };
        setClash(false);
      }
      const evs = eng.perform(selectedUid!, action, ctx);
      await playEvents(evs);
    } catch (e) {
      console.error(e);
    }
    if (eng.snapshot().status === "victory") {
      busyRef.current = false;
      setBusy(false);
      return finishBattle(true);
    }
    if (eng.snapshot().status === "defeat") {
      busyRef.current = false;
      setBusy(false);
      return finishBattle(false);
    }
    busyRef.current = false;
    setBusy(false);
    // (Watchdog sẽ tự đổ xúc xắc người kế tiếp hoặc chuyển lượt địch)
  }

  async function endTurnEarly() {
    if (busyRef.current) return;
    const eng = engine();
    busyRef.current = true;
    setBusy(true);
    setPending(null);
    setSelectedUid(null);
    for (const u of eng.aliveOf("player")) u.acted = true;
    busyRef.current = false;
    setBusy(false);
    setSnapVersion((v) => v + 1);
    // (Watchdog thấy cả đội đã hành động → tự chuyển lượt địch)
  }

  // auto-battle
  useEffect(() => {
    if (!auto || busyRef.current || result || !engineRef.current) return;
    const eng = engineRef.current;
    if (eng.phase !== "player" || eng.snapshot().status !== "running") return;
    const ready = eng.readyUnits("player")[0];
    if (!ready) return;
    if (!ready || ready.energy === undefined) return; // watchdog sẽ roll
    const t = setTimeout(() => {
      setSelectedUid(ready.uid);
      const action = eng.chooseAIAction(ready);
      void playerActWith(ready.uid, action);
    }, 300 / speed);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auto, snapVersion, result, speed, busy]);

  // ============================ WATCHDOG (bộ điều phối) ============================
  // Chống kẹt lượt: chỉ chạy khi trận rảnh (không busy). Nếu còn người chưa roll →
  // tự đổ xúc xắc; nếu cả đội đã hành động / bị đóng băng → tự chuyển lượt địch.
  const watchdogBusy = useRef(false);
  useEffect(() => {
    const eng = engineRef.current;
    if (!eng || result) return;
    const st = eng.snapshot();
    if (st.status !== "running") return;
    if (busyRef.current || watchdogBusy.current) return;
    if (st.phase !== "player") return;
    const alive = eng.aliveOf("player");
    if (alive.length === 0) return; // thua — finishBattle xử lý nơi khác
    const ready = eng.readyUnits("player");
    if (ready.length === 0) {
      // Cả đội đã hành động hoặc bị khóa → qua lượt địch
      watchdogBusy.current = true;
      busyRef.current = true;
      setBusy(true);
      void runEnemyPhase().finally(() => {
        watchdogBusy.current = false;
        busyRef.current = false;
        setBusy(false);
        setSnapVersion((v) => v + 1);
      });
      return;
    }
    const first = ready[0];
    if (first.energy === undefined) {
      void selectAndRoll(first.uid);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [snapVersion, busy, result]);

  async function playerActWith(uid: string, action: Action) {
    setSelectedUid(uid);
    const eng = engine();
    if (busyRef.current) return;
    busyRef.current = true;
    setBusy(true);
    setPending(null);
    try {
      const sdef = skillDefFor(action, uid);
      let ctx: BattleCtx = {};
      if (action.kind === "skill" && sdef?.qte) {
        setClash(true);
        await delay(420);
        ctx = { qteMult: await runQte("skill", sdef.qte as QteKind) };
        setClash(false);
      }
      const evs = eng.perform(uid, action, ctx);
      await playEvents(evs);
    } catch (e) {
      console.error(e);
    }
    if (eng.snapshot().status === "victory") {
      busyRef.current = false;
      setBusy(false);
      return finishBattle(true);
    }
    if (eng.snapshot().status === "defeat") {
      busyRef.current = false;
      setBusy(false);
      return finishBattle(false);
    }
    busyRef.current = false;
    setBusy(false);
    // (Watchdog tiếp quản)
  }

  function toggleSound() {
    setSound((s) => {
      setSfxEnabled(!s);
      return !s;
    });
  }

  if (!stage) {
    return (
      <div className="h-full flex flex-col items-center justify-center gap-3 text-slate-400">
        <Icn name="swords" className="w-10 h-10" />
        <div>Chưa chọn ải chiến đấu</div>
        <Btn onClick={() => setView("stages")}>Chọn ải</Btn>
      </div>
    );
  }

  const eng = engineRef.current;
  if (!eng) {
    return <div className="h-full flex items-center justify-center text-slate-500 text-sm">Đang dựng chiến trường...</div>;
  }

  const selUnit = selectedUid ? eng.unit(selectedUid) : null;
  const validTargets: string[] =
    selUnit && pending ? eng.validTargets(selUnit, pending).map((u) => u.uid) : [];
  const playerPhase = eng.phase === "player" && eng.snapshot().status === "running" && !busy;

  function unitClick(u: BattleUnit) {
    if (!playerPhase) return;
    if (pending && validTargets.includes(u.uid)) {
      void playerAct(pending.kind === "attack" ? { kind: "attack", targetUid: u.uid } : { kind: "skill", skillIdx: (pending as { skillIdx: number }).skillIdx, targetUid: u.uid });
      return;
    }
    if (u.side === "player" && u.alive && !u.acted) {
      sfx("click");
      void selectAndRoll(u.uid);
    }
  }

  function chooseAction(a: Action) {
    if (!selUnit) return;
    sfx("click");
    if (eng!.needsTarget(selUnit, a)) {
      setPending(a);
    } else {
      void playerAct(a);
    }
  }

  const infoSkill = selUnit && skillInfo ? selUnit.skills.find((s) => s.def.id === skillInfo)?.def : null;
  const qteFocus = !!qteSpec || clash; // phóng to 2 bên khi đối đầu/QTE

  return (
    <div className="fixed inset-0 md:absolute md:inset-0 z-10 flex flex-col bg-[#0b0e1a] select-none overflow-hidden">
      {/* background */}
      <div className="absolute inset-0">
        <img src="/images/battle-bg.jpg" alt="" className="w-full h-full object-cover opacity-40" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0b0e1a]/60 via-transparent to-[#0b0e1a]" />
      </div>

      {/* header */}
      <div className="relative z-10 flex items-center gap-2 px-3 py-2 text-xs">
        <button onClick={() => setView("stages")} className="flex items-center gap-1 rounded-lg bg-black/40 border border-white/10 px-2.5 py-1.5 font-bold hover:bg-black/60">
          <Icn name="x" className="w-3.5 h-3.5" /> Thoát
        </button>
        <div className="font-black tracking-wider text-slate-200">
          {stage.name} <span className="text-slate-500 font-semibold">· Đợt {eng.waveIdx + 1}/{stage.waves.length} · Hiệp {eng.round}</span>
        </div>
        <div className="flex-1" />
        <button
          onClick={() => setAuto((a) => !a)}
          className={clsx(
            "flex items-center gap-1 rounded-lg px-2.5 py-1.5 font-bold border",
            auto ? "bg-amber-400/20 border-amber-400/50 text-amber-300" : "bg-black/40 border-white/10 text-slate-400",
          )}
        >
          <Icn name="play" className="w-3.5 h-3.5" /> Tự động
        </button>
        <button
          onClick={() => setSpeed((s) => (s === 1 ? 2 : 1))}
          className="flex items-center gap-1 rounded-lg bg-black/40 border border-white/10 px-2.5 py-1.5 font-bold text-slate-300"
        >
          <Icn name="fast-forward" className="w-3.5 h-3.5" /> x{speed}
        </button>
        <button onClick={toggleSound} className="flex items-center gap-1 rounded-lg bg-black/40 border border-white/10 px-2.5 py-1.5 font-bold text-slate-300">
          <Icn name={sound ? "volume-2" : "volume-x"} className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* banner */}
      <AnimatePresence>
        {banner && (
          <motion.div
            key={banner.main + banner.sub}
            initial={{ opacity: 0, scale: 0.7, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 1.1 }}
            className="absolute left-1/2 top-[32%] -translate-x-1/2 z-30 pointer-events-none flex flex-col items-center"
          >
            <div
              className="flex items-center gap-2 font-black text-xl md:text-3xl tracking-widest px-6 py-2 rounded-2xl bg-black/50 backdrop-blur border"
              style={{ color: banner.color ?? "#e2e8f0", borderColor: `${banner.color ?? "#e2e8f0"}55`, textShadow: `0 0 24px ${banner.color ?? "#fff"}` }}
            >
              {banner.icon && <Icn name={banner.icon} className="w-6 h-6 md:w-8 md:h-8" />}
              {banner.main}
            </div>
            {banner.sub && <div className="text-xs md:text-sm text-slate-300 mt-1 font-semibold">{banner.sub}</div>}
          </motion.div>
        )}
      </AnimatePresence>

      {/* battlefield — bố cục DD: 2 phe đứng đối diện, tiền tuyến (slot 0) ở dưới, hậu phương xếp cao dần.
          Khi có hành động: CẢ HAI bên phóng to đều (scale nhẹ) — không bên nào chiếm diện tích hơn bên nào. */}
      <div
        className="relative z-10 flex-1 flex items-stretch justify-between md:justify-around px-1.5 md:px-10 min-h-0 overflow-hidden transition-transform duration-300 ease-out will-change-transform"
        style={{ transform: qteFocus ? "scale(1.16)" : zoom ? "scale(1.045)" : "scale(1)" }}
      >
        {/* Phe ta — cột TRÁI, hướng mặt về phía quái (bên phải) */}
        <div className="flex flex-col-reverse justify-center items-center md:items-start gap-0.5 md:gap-1">
          {snapUnits
            .filter((u) => u.side === "player")
            .sort((a, b) => a.slot - b.slot)
            .map((u) => (
              <UnitCard
                key={u.uid}
                unit={u}
                disp={disp[u.uid]}
                floats={floats.filter((f) => f.uid === u.uid)}
                hitCount={hits[u.uid] ?? 0}
                lungeCount={lunges[u.uid] ?? 0}
                targeted={validTargets.includes(u.uid)}
                selectable={
                  playerPhase &&
                  (validTargets.includes(u.uid) || (u.alive && !u.acted && !pending))
                }
                selected={selectedUid === u.uid}
                acted={u.acted}
                dimmed={!disp[u.uid]?.alive}
                flip={false}
                onClick={() => unitClick(u)}
              />
            ))}
        </div>

        {/* Quái — cột PHẢI, lật ngang để hướng mặt về phe ta */}
        <div className="flex flex-col-reverse justify-center items-center md:items-end gap-0.5 md:gap-1">
          {snapUnits
            .filter((u) => u.side === "enemy")
            .sort((a, b) => a.slot - b.slot)
            .map((u) => (
              <UnitCard
                key={u.uid}
                unit={u}
                disp={disp[u.uid]}
                floats={floats.filter((f) => f.uid === u.uid)}
                hitCount={hits[u.uid] ?? 0}
                lungeCount={lunges[u.uid] ?? 0}
                targeted={validTargets.includes(u.uid)}
                selectable={playerPhase && validTargets.includes(u.uid)}
                dimmed={!disp[u.uid]?.alive}
                flip={true}
                onClick={() => unitClick(u)}
              />
            ))}
        </div>
      </div>

      {/* Dice roll BẮT BUỘC — to giữa màn hình khi bắt đầu chọn nhân vật hành động */}
      <AnimatePresence>
        {diceUi && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-[34] bg-black/55 backdrop-blur-[2px]"
            />
            <motion.div
              key={"dice-" + diceUi.total + "-" + diceUi.faces.join("")}
              initial={{ opacity: 0, scale: 0.6 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.3 }}
              transition={{ type: "spring", stiffness: 260, damping: 18 }}
              className="absolute inset-0 z-[36] flex items-center justify-center pointer-events-none"
            >
              <div className="rounded-3xl bg-[#0d1020]/95 border-2 border-cyan-400/40 px-8 py-6 flex flex-col items-center shadow-2xl">
                <div className="text-[11px] font-black tracking-[0.35em] text-cyan-300/80 uppercase mb-3 text-center">
                  {selUnit?.name ?? ""} · Đổ xúc xắc
                </div>
                <div className="flex items-center gap-4">
                  {diceUi.faces.map((f, i) => (
                    <DiceDie key={i} value={f} rolling />
                  ))}
                  <motion.span
                    initial={{ opacity: 0, x: -6 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.55 }}
                    className="text-3xl font-black text-white/25"
                  >
                    =
                  </motion.span>
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.6, type: "spring", stiffness: 300, damping: 12 }}
                    className="text-6xl md:text-7xl font-black text-cyan-200 tabular-nums"
                    style={{ textShadow: "0 0 26px rgba(34,211,238,0.9)" }}
                  >
                    {diceUi.total}
                  </motion.span>
                </div>
                <motion.div
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 }}
                  className="mt-3 text-center"
                >
                  <div className="text-[11px] text-cyan-300 font-bold uppercase tracking-widest">
                    Mana lượt này = {diceUi.total}/6
                  </div>
                  <div className="text-[9px] text-slate-400 mt-0.5">Dùng hết lượt này · mỗi lượt đổ lại từ đầu</div>
                </motion.div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* QTE overlay */}
      <AnimatePresence>
        {qteSpec && (
          <QteOverlay
            spec={qteSpec}
            onResult={(mult) => settleQte(mult)}
          />
        )}
      </AnimatePresence>

      {/* action bar — skill chỉ là icon; NHẤN GIỮ để xem mô tả chi tiết, nhả tay là mất */}
      <div className="relative z-20 border-t border-white/10 bg-[#0d1020]/95 backdrop-blur px-3 py-1.5">
        {/* tooltip skill khi đang nhấn giữ */}
        <AnimatePresence>
          {skillInfo && infoSkill && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 6 }}
              transition={{ duration: 0.12 }}
              className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-[min(92vw,560px)] pointer-events-none"
            >
              <div className="rounded-xl border border-indigo-400/30 bg-[#151a33]/95 backdrop-blur p-3 flex items-start gap-3 shadow-2xl">
                <span className="w-9 h-9 rounded-lg bg-indigo-500/20 border border-indigo-400/40 flex items-center justify-center shrink-0">
                  <Icn name={infoSkill.icon} className="w-4.5 h-4.5 text-indigo-300" />
                </span>
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-sm text-indigo-200">{infoSkill.name}</div>
                  <div className="text-[11px] text-slate-400 leading-relaxed">{describeSkill(infoSkill, selUnit!.skills.find((s) => s.def.id === skillInfo)!.lv)}</div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {selUnit && playerPhase ? (
          <div className="flex items-center gap-1.5 md:gap-2 overflow-x-auto py-0.5">
            {/* đơn vị đang điều khiển — avatar + tên */}
            <div className="flex flex-col items-center shrink-0 mr-1 pr-1.5 border-r border-white/10">
              <span className="w-8 h-8 rounded-lg border border-indigo-400/40 bg-indigo-500/15 flex items-center justify-center">
                <Icn name={selUnit.icon} className="w-4 h-4 text-indigo-200" />
              </span>
              <span className="text-[8px] font-bold text-slate-400 max-w-[64px] truncate leading-tight mt-0.5">{selUnit.name}</span>
            </div>
            {/* mana nhận từ xúc xắc lượt này */}
            {selUnit.energy !== undefined && (
              <div className="flex flex-col items-center shrink-0 mr-1 pl-1.5 border-l border-white/10">
                <span className="w-9 h-9 rounded-lg bg-cyan-400/15 border border-cyan-400/50 flex items-center justify-center">
                  <span className="text-sm font-black text-cyan-100">{selUnit.energy}<span className="text-[9px] text-cyan-300/70">/6</span></span>
                </span>
                <span className="text-[7px] font-bold text-cyan-400/90 uppercase tracking-wide mt-0.5">mana lượt</span>
              </div>
            )}
            {/* đánh thường (miễn phí) */}
            <SkillBtn
              icon="sword"
              cost={0}
              active={pending?.kind === "attack"}
              onUse={() => chooseAction({ kind: "attack", targetUid: "" })}
            />
            {/* skill mang theo */}
            {selUnit.skills.map((sk, idx) => {
              const chk = eng.canUseSkill(selUnit, idx);
              const cost = sk.def.cost[sk.lv - 1];
              const active = pending?.kind === "skill" && pending.skillIdx === idx;
              return (
                <SkillBtn
                  key={sk.def.id}
                  icon={sk.def.icon}
                  cost={cost}
                  active={active}
                  disabled={!chk.ok}
                  reason={!chk.ok ? chk.reason : undefined}
                  onUse={() => chk.ok && chooseAction({ kind: "skill", skillIdx: idx })}
                  onInspect={() => setSkillInfo(sk.def.id)}
                  onReleaseInspect={() => setSkillInfo(null)}
                />
              );
            })}
            <div className="flex-1" />
            <Btn variant="ghost" className="shrink-0 !py-1.5 !text-xs" onClick={endTurnEarly}>
              Kết thúc lượt
            </Btn>
          </div>
        ) : (
          <div className="flex items-center gap-2 text-xs text-slate-500 py-1.5">
            <span className="animate-pulse">
              {eng.snapshot().status !== "running"
                ? "Trận đấu kết thúc"
                : eng.phase === "enemy"
                  ? "Địch đang hành động..."
                  : busy
                    ? "Đang thực hiện..."
                    : "Chọn một tướng để hành động"}
            </span>
            <div className="flex-1" />
            <Btn variant="ghost" className="!py-1.5" onClick={endTurnEarly} disabled={eng.phase !== "player" || eng.snapshot().status !== "running" || busy}>
              Kết thúc lượt
            </Btn>
          </div>
        )}
      </div>

      {/* targeting hint */}
      <AnimatePresence>
        {pending && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="absolute bottom-16 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2 rounded-full bg-indigo-500/90 px-4 py-1.5 text-xs font-bold shadow-xl"
          >
            <Icn name="target" className="w-3.5 h-3.5" /> Chọn mục tiêu...
            <button onClick={() => setPending(null)} className="ml-1 rounded-full bg-white/20 p-0.5">
              <Icn name="x" className="w-3 h-3" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* result overlay */}
      <AnimatePresence>
        {result && (
          <ResultPanel
            result={result}
            onRetry={() => {
              setResult(null);
              submittedRef.current = false;
              setFloats([]);
              setHits({});
              setLunges({});
              setSelectedUid(null);
              setPending(null);
              engineRef.current = null;
              const teamChars = (player?.team ?? [])
                .map((id) => characters.find((c) => c.id === id))
                .filter((c): c is NonNullable<typeof c> => !!c)
                .slice(0, 5);
              const eng2 = new BattleEngine(teamChars.map((c, i) => makePlayerUnit(c, CHAR_MAP.get(c.defId)!, items, i)), stage);
              engineRef.current = eng2;
              const d: Record<string, DispUnit> = {};
              for (const u of eng2.units) d[u.uid] = { hp: u.hp, alive: u.alive };
              setDisp(d);
              setSnapVersion((v) => v + 1);
              void (async () => {
                await fetchState();
                const evs = eng2.startSidePhase("player");
                await playEvents(evs, true);
                // (Watchdog sẽ tự đổ xúc xắc nhân vật đầu khi đánh lại)
              })();
            }}
            onExit={() => setView("stages")}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

// ================================ unit card =================================
function UnitCard(props: {
  unit: BattleUnit;
  disp?: DispUnit;
  floats: Float[];
  hitCount: number;
  lungeCount: number;
  targeted: boolean;
  selectable: boolean;
  selected?: boolean;
  acted?: boolean;
  dimmed?: boolean;
  flip?: boolean;
  onClick: () => void;
}) {
  const { unit: u, disp, floats, hitCount, lungeCount, targeted, selectable, selected, acted, dimmed, flip, onClick } = props;
  const d = disp ?? { hp: u.hp, alive: u.alive };
  const frozen = d.alive && u.effects.some((e) => e.type === "freeze" && e.turns > 0);
  const taunting = d.alive && u.effects.some((e) => e.type === "taunt" && e.turns > 0);

  return (
    <motion.button
      onClick={onClick}
      animate={hitCount > 0 ? { x: [0, -6, 6, -3, 0] } : {}}
      key={`hit-${hitCount}`}
      transition={{ duration: 0.35 }}
      className={clsx(
        "relative flex flex-col items-center gap-1 p-1.5 rounded-2xl transition-all w-[19vw] max-w-[110px] min-w-[64px]",
        targeted && "cursor-crosshair",
        dimmed && "pointer-events-none",
      )}
    >
      {targeted && (
        <motion.div
          animate={{ scale: [1, 1.12, 1], opacity: [0.6, 1, 0.6] }}
          transition={{ repeat: Infinity, duration: 0.9 }}
          className="absolute inset-0 rounded-2xl border-2 border-rose-400 z-0"
          style={{ boxShadow: "0 0 18px rgba(251,113,133,0.5)" }}
        />
      )}
      {selected && !targeted && (
        <motion.div
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ repeat: Infinity, duration: 1.2 }}
          className="absolute inset-0 rounded-2xl border-2 border-indigo-400 z-0"
          style={{ boxShadow: "0 0 18px rgba(129,140,248,0.5)" }}
        />
      )}
      {selectable && !targeted && !selected && !acted && (
        <div className="absolute inset-0 rounded-2xl border border-white/20 z-0" />
      )}

      {/* floats */}
      <div className="absolute -top-2 left-1/2 -translate-x-1/2 z-20 pointer-events-none flex flex-col items-center">
        <AnimatePresence>
          {floats.map((f, i) => (
            <motion.span
              key={f.id}
              initial={{ opacity: 0, y: 8, scale: 0.6 }}
              animate={{ opacity: 1, y: -26 - i * 16, scale: 1 }}
              exit={{ opacity: 0, y: -40 }}
              className={clsx("flex items-center gap-1 font-black whitespace-nowrap", f.big ? "text-lg" : "text-xs")}
              style={{ color: f.color, textShadow: `0 0 10px ${f.color}` }}
            >
              {f.icon && <Icn name={f.icon} className="w-3 h-3" />}
              {f.text}
            </motion.span>
          ))}
        </AnimatePresence>
      </div>

      {/* model nhân vật toàn thân (UnitFigure) — idle/attack/hit/die + overlay hiệu ứng */}
      <UnitFigure
        icon={u.icon}
        element={u.element}
        rarity={u.rarity}
        side={u.side}
        dead={!d.alive}
        artPath={u.bodyArt ?? u.art}
        animFrames={u.animFrames}
        hitCount={hitCount}
        lungeCount={lungeCount}
        frozen={frozen}
        shocked={isShocked(u) && d.alive}
        taunting={taunting}
        statuses={d.alive ? u.effects.filter((e) => e.turns > 0).map((e) => e.type) : []}
        flip={flip}
      />

      <div className="w-full space-y-0.5">
        <Bar value={d.hp} max={maxHp(u)} color={d.hp / maxHp(u) < 0.3 ? HP_LOW : HP_COLOR} height={5} />
      </div>

      {/* effect icons */}
      <div className="flex gap-0.5 h-3.5">
        {u.effects
          .filter((e) => e.turns > 0 || e.type === "shield")
          .slice(0, 5)
          .map((e, i) => {
            const meta = EFFECT_META[e.type];
            return (
              <span key={i} className="w-3.5 h-3.5 rounded flex items-center justify-center" style={{ background: `${meta.color}22` }} title={EFFECT_LABEL[e.type]}>
                <Icn name={meta.icon} className="w-2.5 h-2.5" style={{ color: meta.color }} />
              </span>
            );
          })}
      </div>

      {/* name + acted */}
      <div className={clsx("text-[9px] font-bold truncate max-w-full", acted && d.alive ? "text-slate-600" : "text-slate-300")}>
        {u.name} {u.rarity === "SSR" && <span style={{ color: RARITY_COLORS.SSR }}>★</span>}
      </div>
    </motion.button>
  );
}

// ============================= skill icon button ============================
/** Nút skill CHỈ ICON (không chữ, không tên):
 *  - chạm nhanh  → dùng skill / chọn mục tiêu
 *  - NHẤN GIỮ   → hiện mô tả chi tiết; NHẢ TAY → mất (thân thiện mobile) */
function SkillBtn(props: {
  icon: string;
  cost: number;
  active?: boolean;
  disabled?: boolean;
  reason?: string;
  onUse: () => void;
  onInspect?: () => void;
  onReleaseInspect?: () => void;
}) {
  const { icon, cost, active, disabled, reason, onUse, onInspect, onReleaseInspect } = props;
  const holdTimer = useRef<number | null>(null);
  const heldRef = useRef(false);
  const activeRef = useRef(false);

  const clearHold = () => {
    if (holdTimer.current) {
      window.clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
  };

  const down = () => {
    if (disabled) return;
    heldRef.current = false;
    activeRef.current = true;
    clearHold();
    if (!onInspect) return;
    // nhấn giữ 240ms → mở mô tả (chưa kích hoạt skill)
    holdTimer.current = window.setTimeout(() => {
      heldRef.current = true;
      onInspect();
    }, 240);
  };

  const up = () => {
    if (!activeRef.current) return;
    activeRef.current = false;
    clearHold();
    if (heldRef.current) {
      // vừa xem mô tả → nhả tay = đóng mô tả, không dùng skill
      heldRef.current = false;
      onReleaseInspect?.();
    } else {
      // chạm nhanh → dùng skill
      onUse();
    }
  };

  const cancel = () => {
    if (!activeRef.current) return;
    activeRef.current = false;
    clearHold();
    if (heldRef.current) onReleaseInspect?.();
    heldRef.current = false;
  };

  const bad = disabled || reason === "shock" || reason === "noTarget";

  return (
    <div className="relative shrink-0 select-none touch-none">
      <button
        onPointerDown={down}
        onPointerUp={up}
        onPointerLeave={cancel}
        onPointerCancel={cancel}
        onContextMenu={(e) => e.preventDefault()}
        className={clsx(
          "w-11 h-11 md:w-12 md:h-12 rounded-xl border flex items-center justify-center transition-all",
          active
            ? "border-indigo-300 bg-indigo-500/35 shadow-lg shadow-indigo-500/40 ring-1 ring-indigo-300"
            : bad
              ? "border-white/10 bg-white/[0.03] opacity-45"
              : "border-white/15 bg-white/[0.06] hover:bg-white/12 active:scale-95",
        )}
      >
        <Icn name={icon} className="w-5 h-5 md:w-6 md:h-6" style={{ color: bad ? "#64748b" : "#a5b4fc" }} />
        {/* chi phí xúc xắc nhỏ góc dưới */}
        <span
          className={clsx(
            "absolute -bottom-1 -right-1 min-w-[15px] h-[15px] px-0.5 rounded-md text-[8px] font-black flex items-center justify-center border",
            bad ? "bg-slate-800/90 border-white/10 text-slate-500" : "bg-cyan-950/90 border-cyan-400/40 text-cyan-300",
          )}
        >
          {cost}
        </span>
        {/* trạng thái khóa */}
        {reason === "shock" && (
          <span className="absolute -top-1.5 -left-1.5 w-4 h-4 rounded-full bg-yellow-400 flex items-center justify-center">
            <Icn name="zap" className="w-2.5 h-2.5 text-yellow-950" />
          </span>
        )}
        {reason === "noTarget" && (
          <span className="absolute -top-1.5 -left-1.5 w-4 h-4 rounded-full bg-slate-600 flex items-center justify-center">
            <Icn name="target" className="w-2.5 h-2.5 text-slate-200" />
          </span>
        )}
      </button>
    </div>
  );
}

// ================================ result ====================================
// ================================== dice ====================================
const DIE_FACES = ["\u2680", "\u2681", "\u2682", "\u2683", "\u2684", "\u2685"];
function DiceDie({ value, rolling }: { value: number; rolling?: boolean }) {
  return (
    <motion.span
      initial={{ rotate: -120, opacity: 0 }}
      animate={{ rotate: 0, opacity: 1, y: [0, -6, 0] }}
      transition={{ type: "spring", stiffness: 300, damping: 14 }}
      className="w-20 h-20 md:w-24 md:h-24 rounded-2xl bg-white text-slate-900 flex items-center justify-center text-5xl md:text-6xl font-black shadow-2xl"
    >
      {DIE_FACES[Math.max(0, Math.min(5, value - 1))]}
    </motion.span>
  );
}

function ResultPanel({ result, onRetry, onExit }: { result: Reward; onRetry: () => void; onExit: () => void }) {
  const drops: ItemDef[] = result.dropped.map((id) => ITEM_MAP.get(id)).filter((d): d is ItemDef => !!d);
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 z-40 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <motion.div
        initial={{ scale: 0.85, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        transition={{ type: "spring", stiffness: 200, damping: 20 }}
        className={clsx(
          "w-full max-w-md rounded-3xl border p-6 text-center shadow-2xl",
          result.victory ? "border-amber-400/40 bg-gradient-to-b from-amber-500/10 to-[#12152a]" : "border-rose-500/30 bg-gradient-to-b from-rose-500/10 to-[#12152a]",
        )}
      >
        <motion.div
          initial={{ rotate: -10, scale: 0 }}
          animate={{ rotate: 0, scale: 1 }}
          transition={{ delay: 0.15, type: "spring", stiffness: 260 }}
          className={clsx(
            "w-16 h-16 mx-auto rounded-2xl flex items-center justify-center mb-3",
            result.victory ? "bg-amber-400/20 text-amber-300" : "bg-rose-500/20 text-rose-300",
          )}
        >
          <Icn name={result.victory ? "crown" : "skull"} className="w-8 h-8" />
        </motion.div>
        <h2 className={clsx("text-2xl font-black tracking-widest", result.victory ? "text-amber-300" : "text-rose-300")}>
          {result.victory ? "CHIẾN THẮNG" : "THẤT BẠI"}
        </h2>
        <p className="text-xs text-slate-400 mt-1">{result.victory ? "Toàn đội nhận được chiến lợi phẩm!" : "Đừng bỏ cuộc — nâng cấp tướng rồi quay lại!"}</p>

        <div className="grid grid-cols-3 gap-2 mt-4">
          <div className="rounded-xl bg-white/[0.05] border border-white/8 p-2.5">
            <Icn name="star" className="w-4 h-4 mx-auto text-emerald-300 mb-1" />
            <div className="font-black text-emerald-300">+{result.exp}</div>
            <div className="text-[9px] text-slate-400 uppercase">EXP</div>
          </div>
          <div className="rounded-xl bg-white/[0.05] border border-white/8 p-2.5">
            <Icn name="coins" className="w-4 h-4 mx-auto text-amber-300 mb-1" />
            <div className="font-black text-amber-300">+{result.goldGain}</div>
            <div className="text-[9px] text-slate-400 uppercase">Vàng</div>
          </div>
          <div className="rounded-xl bg-white/[0.05] border border-white/8 p-2.5">
            <Icn name="gem" className="w-4 h-4 mx-auto text-cyan-300 mb-1" />
            <div className="font-black text-cyan-300">+{result.gemsGain}</div>
            <div className="text-[9px] text-slate-400 uppercase">Ngọc</div>
          </div>
        </div>

        {result.levelups.length > 0 && (
          <div className="mt-3 rounded-xl border border-indigo-400/30 bg-indigo-500/10 p-2.5 text-xs text-indigo-200 font-bold">
            {result.levelups.map((l) => {
              return <div key={l.id}>Lên cấp! {l.from} → {l.to} — chỉ số cơ bản tăng, +1 điểm kỹ năng</div>;
            })}
          </div>
        )}

        {drops.length > 0 && (
          <div className="mt-3">
            <div className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-1.5">Trang bị rơi ra</div>
            <div className="flex flex-wrap justify-center gap-1.5">
              {drops.map((d, i) => (
                <span
                  key={i}
                  className="flex items-center gap-1 rounded-lg border px-2 py-1 text-[10px] font-bold"
                  style={{ borderColor: `${RARITY_COLORS[d.rarity]}55`, color: RARITY_COLORS[d.rarity], background: `${RARITY_COLORS[d.rarity]}11` }}
                >
                  <Icn name={d.icon} className="w-3 h-3" /> {d.name}
                </span>
              ))}
            </div>
          </div>
        )}

        <div className="flex gap-2 mt-5">
          {!result.victory && (
            <Btn variant="gold" className="flex-1" onClick={onRetry}>
              <Icn name="rotate-ccw" className="w-4 h-4" /> Đánh lại
            </Btn>
          )}
          {result.victory && (
            <Btn variant="ghost" className="flex-1" onClick={onRetry}>
              <Icn name="rotate-ccw" className="w-4 h-4" /> Đánh lại
            </Btn>
          )}
          <Btn variant="primary" className="flex-1" onClick={onExit}>
            Tiếp tục
          </Btn>
        </div>
      </motion.div>
    </motion.div>
  );
}
