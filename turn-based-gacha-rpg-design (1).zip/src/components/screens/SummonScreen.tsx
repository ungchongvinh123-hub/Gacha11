"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import clsx from "clsx";
import { useGame } from "@/game/store";
import { Btn, Icn, Modal, Portrait, Stars, RARITY_GRADIENT, Chip } from "../ui";
import { CHARACTERS, CHAR_MAP } from "@/game/data/characters";
import { GACHA_COST, GACHA_RATES, Rarity, RARITY_COLORS } from "@/game/types";
import { sfx } from "@/game/sfx";

interface PullResult {
  defId: string;
  rarity: Rarity;
  isDupe: boolean;
  newId: number;
}

export default function SummonScreen() {
  const { player, mutate, toast } = useGame();
  const [busy, setBusy] = useState(false);
  const [results, setResults] = useState<PullResult[] | null>(null);
  const [revealIdx, setRevealIdx] = useState(0);
  const [showRates, setShowRates] = useState(false);

  const hasSSR = results?.some((r) => r.rarity === "SSR");
  const bestRarity = results?.reduce<Rarity>(
    (acc, r) => (r.rarity === "SSR" ? "SSR" : r.rarity === "SR" && acc !== "SSR" ? "SR" : acc),
    "R",
  );

  async function pull(count: 1 | 10) {
    if (busy) return;
    if ((player?.gems ?? 0) < GACHA_COST * count) {
      toast(`Không đủ ngọc! Cần ${GACHA_COST * count} ngọc`, "error");
      return;
    }
    setBusy(true);
    sfx("gacha");
    try {
      const data = await mutate<{ results: PullResult[] }>("gacha", { count });
      setResults(data.results);
      setRevealIdx(0);
      setTimeout(() => setRevealIdx(1), 450);
      const t = setInterval(() => {
        setRevealIdx((i) => {
          if (i >= data.results.length) {
            clearInterval(t);
            return i;
          }
          return i + 1;
        });
      }, 260);
    } catch {
      /* toast handled */
    } finally {
      setBusy(false);
    }
  }

  const pool = { R: 0, SR: 0, SSR: 0 };
  for (const c of CHARACTERS) pool[c.rarity]++;

  return (
    <div className="min-h-full">
      {/* banner */}
      <div className="relative h-56 md:h-72 overflow-hidden">
        <img src="/images/gacha-banner.jpg" alt="" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0b0e1a] via-[#0b0e1a]/30 to-transparent" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-4">
          <motion.div
            animate={{ rotate: [0, 8, -8, 0], scale: [1, 1.06, 1] }}
            transition={{ repeat: Infinity, duration: 5 }}
            className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-gradient-to-br from-amber-300 to-fuchsia-500 flex items-center justify-center shadow-2xl shadow-fuchsia-500/40 mb-3"
          >
            <Icn name="dices" className="w-7 h-7 text-white" />
          </motion.div>
          <h2 className="text-2xl md:text-3xl font-black tracking-widest text-white drop-shadow-lg">CỔNG TRIỆU HỒI</h2>
          <p className="text-slate-300 text-xs md:text-sm mt-1">30 anh hùng thuộc 3 class đang chờ lừa gọi</p>
          <button
            onClick={() => setShowRates(true)}
            className="mt-2 text-[11px] text-cyan-300 underline underline-offset-2 hover:text-cyan-200"
          >
            Xem tỉ lệ & danh sách tướng
          </button>
        </div>
      </div>

      {/* pull buttons */}
      <div className="max-w-xl mx-auto px-4 -mt-6 relative z-10 grid grid-cols-2 gap-3">
        {([1, 10] as const).map((n) => (
          <motion.button
            key={n}
            whileTap={{ scale: 0.95 }}
            disabled={busy}
            onClick={() => pull(n)}
            className={clsx(
              "relative overflow-hidden rounded-2xl border p-4 text-center transition-all",
              n === 10
                ? "bg-gradient-to-b from-amber-300/90 to-amber-600 border-amber-200/50 text-amber-950 shadow-xl shadow-amber-500/25 hover:brightness-110"
                : "bg-gradient-to-b from-indigo-400/90 to-indigo-700 border-indigo-300/40 text-white shadow-xl shadow-indigo-500/25 hover:brightness-110",
              busy && "opacity-50",
            )}
          >
            <div className="text-lg font-black">x{n}</div>
            <div className="flex items-center justify-center gap-1 text-sm font-bold mt-0.5">
              <Icn name="gem" className={clsx("w-4 h-4", n === 10 ? "text-amber-900" : "text-cyan-200")} />
              {(GACHA_COST * n).toLocaleString()}
            </div>
            {n === 10 && <div className="text-[10px] font-bold mt-1 opacity-80">ĐẢM BẢO ≥1 TƯỚNG SR+</div>}
          </motion.button>
        ))}
      </div>

      {/* featured rarity strip */}
      <div className="max-w-4xl mx-auto px-4 mt-8 pb-10">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-bold uppercase tracking-[0.2em] text-slate-400">Tướng SSR — tỉ lệ 3%</h3>
          <Chip color={RARITY_COLORS.SSR}>Cực hiếm</Chip>
        </div>
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
          {CHARACTERS.filter((c) => c.rarity === "SSR").map((c) => (
            <div key={c.id} className="rounded-xl border border-amber-400/30 bg-gradient-to-b from-amber-400/10 to-transparent p-2 flex flex-col items-center gap-1.5">
              <Portrait icon={c.icon} element={c.element} rarity="SSR" size={48} artPath={c.art} />
              <div className="text-[11px] font-bold text-center leading-tight">{c.name}</div>
              <div className="text-[9px] text-slate-400 text-center leading-tight">{c.title}</div>
            </div>
          ))}
        </div>
      </div>

      {/* reveal overlay */}
      <AnimatePresence>
        {results && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className={clsx("fixed inset-0 z-50 flex flex-col items-center justify-center p-4 backdrop-blur-md bg-black/80")}
          >
            {hasSSR && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: [0, 0.8, 0.4, 0.8] }}
                transition={{ duration: 1.2 }}
                className="absolute inset-0 pointer-events-none"
                style={{ background: "radial-gradient(circle at 50% 40%, rgba(251,191,36,0.25), transparent 60%)" }}
              />
            )}
            <div className="relative w-full max-w-3xl">
              <h3 className="text-center font-black text-xl mb-4 tracking-widest" style={{ color: RARITY_COLORS[bestRarity!] }}>
                {bestRarity === "SSR" ? "CỰC PHẨM XUẤT HIỆN!" : bestRarity === "SR" ? "TƯỚNG HIẾM!" : "KẾT QUẢ TRIỆU HỒI"}
              </h3>
              <div className={clsx("grid gap-2", results.length > 1 ? "grid-cols-5" : "grid-cols-1 max-w-[130px] mx-auto")}>
                {results.map((r, i) => {
                  const def = CHAR_MAP.get(r.defId)!;
                  const shown = i < revealIdx;
                  return (
                    <motion.div
                      key={i}
                      initial={{ rotateY: 90, scale: 0.6, opacity: 0 }}
                      animate={shown ? { rotateY: 0, scale: 1, opacity: 1 } : {}}
                      transition={{ type: "spring", stiffness: 260, damping: 20 }}
                      className={clsx(
                        "relative rounded-xl border bg-gradient-to-b p-2 flex flex-col items-center gap-1 aspect-[3/4.2] justify-center",
                        RARITY_GRADIENT[r.rarity],
                      )}
                      style={{
                        borderColor: `${RARITY_COLORS[r.rarity]}66`,
                        boxShadow: shown ? `0 0 18px ${RARITY_COLORS[r.rarity]}55` : undefined,
                        opacity: shown ? 1 : 0.15,
                      }}
                    >
                      {shown ? (
                        <>
                          {r.rarity !== "R" && (
                            <motion.span
                              initial={{ scale: 0 }}
                              animate={{ scale: [0, 1.6, 1] }}
                              className="absolute inset-0 rounded-xl pointer-events-none"
                              style={{ boxShadow: `0 0 30px 4px ${RARITY_COLORS[r.rarity]}66` }}
                            />
                          )}
                          <Portrait icon={def.icon} element={def.element} rarity={r.rarity} size={44} artPath={def.art} />
                          <div className="text-[10px] font-bold text-center leading-tight mt-1">{def.name}</div>
                          <Stars rarity={r.rarity} />
                          <span
                            className="absolute top-1 right-1 text-[8px] font-black px-1 rounded"
                            style={{ background: r.isDupe ? "#64748b33" : "#4ade80", color: r.isDupe ? "#94a3b8" : "#052e16" }}
                          >
                            {r.isDupe ? "TRÙNG" : "MỚI"}
                          </span>
                        </>
                      ) : (
                        <div className="text-2xl font-black text-white/20">?</div>
                      )}
                    </motion.div>
                  );
                })}
              </div>
              <div className="flex justify-center gap-3 mt-6">
                {revealIdx < results.length && results.length > 1 && (
                  <Btn variant="ghost" onClick={() => setRevealIdx(results.length)}>
                    Bỏ qua
                  </Btn>
                )}
                <Btn
                  variant="gold"
                  onClick={() => {
                    sfx(revealIdx && hasSSR ? "ssr" : bestRarity === "SR" ? "rare" : "click");
                    setResults(null);
                  }}
                >
                  Nhận tướng
                </Btn>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* rates modal */}
      {showRates && (
        <Modal onClose={() => setShowRates(false)} wide>
          <div className="p-5 overflow-y-auto">
            <h3 className="font-black text-lg mb-3">Tỉ lệ triệu hồi</h3>
            <div className="grid grid-cols-3 gap-2 mb-5">
              {(["SSR", "SR", "R"] as Rarity[]).map((r) => (
                <div key={r} className="rounded-xl border p-3 text-center" style={{ borderColor: `${RARITY_COLORS[r]}55`, background: `${RARITY_COLORS[r]}11` }}>
                  <div className="font-black text-xl" style={{ color: RARITY_COLORS[r] }}>
                    {(GACHA_RATES[r] * 100).toFixed(0)}%
                  </div>
                  <div className="text-xs font-bold mt-0.5">{r}</div>
                  <div className="text-[10px] text-slate-400">{pool[r]} tướng</div>
                </div>
              ))}
            </div>
            <p className="text-xs text-slate-400 mb-4">Quay 10 lần đảm bảo ít nhất 1 tướng SR trở lên. Tướng càng hiếm chỉ số càng cao. Tướng trùng lặp được giữ nguyên như một bản sao độc lập — có thể xây nhiều đội khác nhau.</p>
            <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2">
              {CHARACTERS.map((c) => (
                <div key={c.id} className="flex flex-col items-center gap-1 p-1.5 rounded-lg border border-white/8 bg-white/[0.03]">
                  <Portrait icon={c.icon} element={c.element} rarity={c.rarity} size={36} artPath={c.art} />
                  <span className="text-[9px] font-semibold text-center leading-tight">{c.name}</span>
                </div>
              ))}
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
