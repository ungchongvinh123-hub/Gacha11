"use client";

import { useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import clsx from "clsx";
import { useGame, type View } from "@/game/store";
import { Icn } from "./ui";
import RotatePrompt from "./RotatePrompt";
import HomeScreen from "./screens/HomeScreen";
import SummonScreen from "./screens/SummonScreen";
import RosterScreen from "./screens/RosterScreen";
import TeamScreen from "./screens/TeamScreen";
import StagesScreen from "./screens/StagesScreen";
import InventoryScreen from "./screens/InventoryScreen";
import BattleScreen from "./screens/BattleScreen";
import ShopScreen from "./screens/ShopScreen";
import { sfx } from "@/game/sfx";

const NAV: { view: View; icon: string; label: string }[] = [
  { view: "home", icon: "house", label: "Sảnh" },
  { view: "summon", icon: "dices", label: "Triệu Hồi" },
  { view: "roster", icon: "users", label: "Tướng" },
  { view: "team", icon: "swords", label: "Đội Hình" },
  { view: "stages", icon: "play", label: "Chiến" },
  { view: "inventory", icon: "backpack", label: "Kho Đồ" },
  { view: "shop", icon: "coins", label: "Cửa Hàng" },
];

export default function GameShell() {
  const { loaded, view, setView, player, fetchState, toasts } = useGame();

  useEffect(() => {
    fetchState().catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!loaded || !player) {
    return (
      <div className="fixed inset-0 flex flex-col items-center justify-center gap-4 bg-[#0b0e1a]">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 2.4, ease: "linear" }}
          className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-fuchsia-600 flex items-center justify-center shadow-2xl shadow-indigo-500/40"
        >
          <Icn name="sparkles" className="w-8 h-8 text-white" />
        </motion.div>
        <div className="text-xs uppercase tracking-[0.4em] text-slate-400">Triệu Hồi Kỷ Nguyên</div>
        <div className="text-slate-500 text-sm animate-pulse">Đang tải dữ liệu thế giới...</div>
      </div>
    );
  }

  const inBattle = view === "battle";

  return (
    <div className="fixed inset-0 bg-[#0b0e1a] text-slate-100 flex flex-col overflow-hidden">
      {/* top bar */}
      {!inBattle && (
        <header className="h-12 shrink-0 flex items-center gap-3 px-3 md:px-5 border-b border-white/5 bg-[#0d1020]/90 backdrop-blur z-20">
          <div className="flex items-center gap-2 font-extrabold tracking-widest text-sm">
            <span className="w-7 h-7 rounded-lg bg-gradient-to-br from-indigo-500 to-fuchsia-600 flex items-center justify-center">
              <Icn name="sparkles" className="w-4 h-4" />
            </span>
            <span className="hidden sm:inline text-slate-200">TRIỆU HỒI KỶ NGUYÊN</span>
          </div>
          <div className="flex-1" />
          <div className="flex items-center gap-2 text-sm font-semibold">
            <span className="flex items-center gap-1.5 rounded-full bg-amber-400/10 border border-amber-400/20 px-3 py-1">
              <Icn name="coins" className="w-4 h-4 text-amber-300" />
              <span className="text-amber-200 tabular-nums">{player.gold.toLocaleString()}</span>
            </span>
            <span className="flex items-center gap-1.5 rounded-full bg-cyan-400/10 border border-cyan-400/20 px-3 py-1">
              <Icn name="gem" className="w-4 h-4 text-cyan-300" />
              <span className="text-cyan-200 tabular-nums">{player.gems.toLocaleString()}</span>
            </span>
          </div>
        </header>
      )}

      <div className="flex-1 flex min-h-0">
        {/* side nav */}
        {!inBattle && (
          <nav className="hidden md:flex w-16 lg:w-52 flex-col gap-1 p-2 lg:p-3 border-r border-white/5 bg-[#0d1020]/60">
            {NAV.map((n) => (
              <button
                key={n.view}
                onClick={() => {
                  sfx("click");
                  setView(n.view);
                }}
                className={clsx(
                  "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition-all",
                  view === n.view
                    ? "bg-indigo-500/20 text-indigo-200 border border-indigo-400/30 shadow-inner"
                    : "text-slate-400 hover:bg-white/5 hover:text-slate-200 border border-transparent",
                )}
              >
                <Icn name={n.icon} className="w-5 h-5 shrink-0" />
                <span className="hidden lg:inline">{n.label}</span>
              </button>
            ))}
          </nav>
        )}

        {/* content */}
        <main className="flex-1 min-w-0 overflow-y-auto relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={view + (useGame.getState().battleStageId ?? "")}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.22 }}
              className="min-h-full"
            >
              {view === "home" && <HomeScreen />}
              {view === "summon" && <SummonScreen />}
              {view === "roster" && <RosterScreen />}
              {view === "team" && <TeamScreen />}
              {view === "stages" && <StagesScreen />}
              {view === "inventory" && <InventoryScreen />}
              {view === "battle" && <BattleScreen />}
              {view === "shop" && <ShopScreen />}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* bottom nav (mobile) */}
      {!inBattle && (
        <nav className="md:hidden shrink-0 h-14 grid grid-cols-7 border-t border-white/10 bg-[#0d1020]/95 backdrop-blur z-20">
          {NAV.map((n) => (
            <button
              key={n.view}
              onClick={() => {
                sfx("click");
                setView(n.view);
              }}
              className={clsx(
                "flex flex-col items-center justify-center gap-0.5 text-[9px] font-bold uppercase tracking-wide",
                view === n.view ? "text-indigo-300" : "text-slate-500",
              )}
            >
              <Icn name={n.icon} className="w-5 h-5" />
              {n.label}
            </button>
          ))}
        </nav>
      )}

      {/* toasts */}
      <div className="fixed bottom-16 md:bottom-6 left-1/2 -translate-x-1/2 z-[70] flex flex-col gap-2 items-center pointer-events-none">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 16, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8 }}
              className={clsx(
                "px-4 py-2 rounded-xl text-sm font-semibold shadow-xl border backdrop-blur",
                t.kind === "error" && "bg-rose-500/20 border-rose-400/40 text-rose-200",
                t.kind === "success" && "bg-emerald-500/20 border-emerald-400/40 text-emerald-200",
                t.kind === "info" && "bg-indigo-500/20 border-indigo-400/40 text-indigo-200",
              )}
            >
              {t.msg}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
