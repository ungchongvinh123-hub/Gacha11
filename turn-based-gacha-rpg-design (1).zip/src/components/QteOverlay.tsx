"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import type { QteKind } from "@/game/types";

// ============================================================================
// QTE tối giản — không khung, không chữ, không che màn. Người chơi tự hiểu.
//
//  SKILL (chỉ skill được đánh dấu qte):
//   - tap     : 1 vòng tròn nhấp nháy → BẤM LIÊN TỤC, tối đa 10 lần.
//   - connect : 3 chấm sáng lần lượt ở vị trí ngẫu nhiên → VUỐT nối qua cả 3.
//   - charge  : vòng tụ lực phồng lên → BẤM khi khớp vòng đích (có thang: chuẩn/tốt/trật).
//
//  BỊ TẤN CÔNG (block):
//   - LUÔN là charge, nhưng CHỈ 2 kết quả: thành công (chặn ~30%) / trật (ăn đủ).
//   - Tiết tấu phồng vòng đổi liên tục theo đường cong ngẫu nhiên mỗi lần
//     (không bao giờ trùng), tốc độ NHANH, cửa chuẩn cực hẹp → khó.
// ============================================================================

export type QteMode = "skill" | "block";

export interface QteSpec {
  id: number;
  mode: QteMode;
  kind: QteKind;
  duration: number;
  /** Độ lệch chuẩn (0..1) — block cực hẹp */
  perfect: number;
  /** skill: ngưỡng tốt */
  great: number;
  /** skill: ngưỡng "được" */
  good: number;
  /** tap: số lần cần đạt (tối đa 10); connect: 3 */
  target: number;
  label: string;
}

export const QTE_MULT: Record<QteMode, { perfect: number; great: number; good: number; poor: number }> = {
  skill: { perfect: 1.3, great: 1.15, good: 1.0, poor: 0.6 },
  block: { perfect: 0, great: 0, good: 0, poor: 1 }, // CHỈ 2 mức: chặn=0 sát thương / trật=ăn 100%
};

const rand = (a: number, b: number) => a + Math.random() * (b - a);

export function makeQteSpec(mode: QteMode, kind?: QteKind): QteSpec {
  const id = Date.now() + Math.floor(Math.random() * 99999);
  const skill = mode === "skill";
  // Bị tấn công: LUÔN charge. Skill: loại được ấn định ở skill hoặc chọn ngẫu nhiên.
  const k: QteKind = skill ? (kind ?? (["tap", "connect", "charge"] as QteKind[])[Math.floor(Math.random() * 3)]) : "charge";

  if (k === "tap") {
    return { id, mode, kind: k, duration: rand(1500, 2100), perfect: 0, great: 0, good: 0, target: Math.min(10, 5 + Math.floor(Math.random() * 5)), label: "" };
  }
  if (k === "connect") {
    return { id, mode, kind: k, duration: rand(2000, 2600), perfect: 0, great: 0, good: 0, target: 3, label: "" };
  }
  // charge: block cực nhanh + cửa hẹp; skill dễ hơn chút
  return {
    id, mode, kind: k,
    duration: skill ? rand(1500, 2000) : rand(620, 980),
    perfect: skill ? 0.09 : 0.045,
    great: skill ? 0.17 : 0.045,
    good: skill ? 0.28 : 0.045,
    target: 1, label: "",
  };
}

/** block: CHỈ 2 mức — trong cửa chuẩn = chặn (0 sát thương), ngoài = trật (ăn 100%). */
function blockBinary(spec: QteSpec, dist: number): number {
  return dist <= spec.perfect ? 0 : 1;
}
function skillGrade(spec: QteSpec, dist: number): number {
  const s = dist <= spec.perfect ? 1 : dist <= spec.great ? 0.72 : dist <= spec.good ? 0.45 : 0.08;
  return s >= 0.8 ? QTE_MULT.skill.perfect : s >= 0.55 ? QTE_MULT.skill.great : s >= 0.3 ? QTE_MULT.skill.good : QTE_MULT.skill.poor;
}

export default function QteOverlay({ spec, onResult }: { spec: QteSpec; onResult: (mult: number) => void }) {
  const doneRef = useRef(false);
  const color = spec.mode === "skill" ? "#67e8f9" : "#fb7185";

  const [burst, setBurst] = useState<"good" | "mid" | "bad" | null>(null);
  const finish = (mult: number) => {
    if (doneRef.current) return;
    doneRef.current = true;
    // Ngưng lại 1 chút ở cuối QTE + hiệu ứng rõ để người chơi biết kết quả
    const good = spec.mode === "skill" ? mult >= 1.15 : mult <= 0.5;
    const bad = spec.mode === "skill" ? mult <= 0.6 : mult >= 0.95;
    setBurst(good ? "good" : bad ? "bad" : "mid");
    setTimeout(() => onResult(mult), 620);
  };

  // ================= TAP (≤10 lần) =================
  const [taps, setTaps] = useState(0);
  const tapsRef = useRef(0);
  useEffect(() => {
    if (spec.kind !== "tap") return;
    const t = setTimeout(() => finish(QTE_MULT.skill.poor), spec.duration);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [spec]);

  // ================= CONNECT (3 điểm) =================
  // 3 điểm ngẫu nhiên trong vùng tương tác; sinh 1 lần theo spec.id
  const [pts] = useState(() =>
    Array.from({ length: 3 }, () => ({
      x: 18 + Math.random() * 64, // % diện tích widget
      y: 18 + Math.random() * 64,
    })),
  );
  const litRef = useRef(0);
  const [lit, setLit] = useState(0);
  useEffect(() => {
    if (spec.kind !== "connect") return;
    // nháy thứ tự từng chấm 1 lúc đầu (gợi ý không lời)
    const iv = setInterval(() => {
      if (doneRef.current) { clearInterval(iv); return; }
      setOrder((o) => (o + 1) % 4);
    }, 260);
    const t = setTimeout(() => {
      if (litRef.current < 3) finish(QTE_MULT.skill.poor);
    }, spec.duration);
    return () => { clearInterval(iv); clearTimeout(t); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [spec]);
  const [order, setOrder] = useState(0); // 0..3 (3=đã nối xong)

  const onConnectMove = (x: number, y: number) => {
    if (spec.kind !== "connect" || doneRef.current) return;
    const cx = window.innerWidth / 2;
    const cy = window.innerHeight / 2;
    // quy đổi về vùng ~260px quanh tâm
    const dx = (x - cx) / 2.2;
    const dy = (y - cy) / 2.2;
    const ox = (dx + 130) / 260;
    const oy = (dy + 130) / 260;
    for (let i = 0; i < 3; i++) {
      const d2 = Math.pow(pts[i].x / 100 - ox, 2) + Math.pow(pts[i].y / 100 - oy, 2);
      if (d2 < 0.008) {
        const bit = 1 << i;
        if ((litRef.current & bit) === 0) {
          litRef.current |= bit;
          const c = [0, 1, 2].filter((n) => litRef.current & (1 << n)).length;
          setLit(c);
          if (c === 3) {
            setOrder(3);
            finish(QTE_MULT.skill.perfect);
          }
        }
        break;
      }
    }
  };

  // ================= CHARGE (tụ lực) =================
  const [r, setR] = useState(0);
  const targetR = 46; // vòng đích cố định
  const tapDone = useRef(false);
  useEffect(() => {
    if (spec.kind !== "charge") return;
    const st = performance.now();
    let raf = 0;
    // Đường cong tốc độ NGẪU NHIÊN mỗi lần: trộn ease-in/out + xóc nhẹ
    const ease = rand(0.4, 1.6); // nhịp phồng đổi liên tục, không trùng
    const loop = (now: number) => {
      const p = Math.min(1, (now - st) / spec.duration);
      if (p >= 1) { finish(spec.mode === "block" ? QTE_MULT.block.poor : QTE_MULT.skill.poor); return; }
      const e = p <= 0.5 ? Math.pow(p * 2, ease) / 2 : 1 - Math.pow((1 - p) * 2, ease) / 2;
      setR(e * (targetR + 34)); // phồng qua đích một chút
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [spec]);

  const tapCharge = () => {
    if (doneRef.current || tapDone.current) return;
    tapDone.current = true;
    const dist = Math.abs(r - targetR) / targetR;
    const mult = spec.mode === "block" ? blockBinary(spec, dist) : skillGrade(spec, dist);
    finish(mult);
  };

  // ================= pointer =================
  const onDown = (e: React.PointerEvent) => {
    if (spec.kind === "tap") { tapsRef.current = Math.min(10, tapsRef.current + 1); setTaps(tapsRef.current); if (tapsRef.current >= spec.target) finish(QTE_MULT.skill.perfect); }
    else if (spec.kind === "charge") tapCharge();
  };
  const onMove = (e: React.PointerEvent) => {
    if (spec.kind === "connect" && e.pointerType !== "mouse") onConnectMove(e.clientX, e.clientY);
  };
  const onDownMove = (e: React.PointerEvent) => {
    // dùng cho mouse connect: bấm-giữ di chuyển
    if (e.pointerType === "mouse") onConnectMove(e.clientX, e.clientY);
  };

  const progress = spec.kind === "tap" ? Math.min(1, taps / spec.target) : spec.kind === "connect" ? lit / 3 : 0;

  return (
    <div
      className="absolute inset-0 z-[36] pointer-events-auto touch-none select-none"
      onPointerDown={onDown}
      onPointerMove={onMove}
      onPointerUp={onDownMove}
      onPointerLeave={() => { if (spec.kind === "tap") finish(QTE_MULT.skill.good); }}
    >
      {/* ---------- TAP: vòng nhấp nháy, lấp đầy theo số lần ---------- */}
      {spec.kind === "tap" && (
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center justify-center w-44 h-44">
          <motion.div
            animate={{ scale: [1, 1.08, 1] }}
            transition={{ repeat: Infinity, duration: 0.5 }}
            className="absolute inset-0 rounded-full"
            style={{ border: `3px solid ${color}`, background: `radial-gradient(circle, ${color}${Math.round(progress * 90).toString(16).padStart(2, "0")}, transparent 72%)`, boxShadow: `0 0 30px ${color}55` }}
          />
          <div className="absolute bottom-1 left-1/2 -translate-x-1/2 flex gap-1">
            {Array.from({ length: Math.min(spec.target, 10) }).map((_, i) => (
              <span key={i} className="w-1 h-1 rounded-full" style={{ background: i < taps ? "#ffffff" : "#ffffff33" }} />
            ))}
          </div>
        </div>
      )}

      {/* ---------- CONNECT: 3 chấm, nháy thứ tự, vuốt nối ---------- */}
      {spec.kind === "connect" && (
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[240px] h-[240px]">
          {pts.map((p, i) => {
            const on = lit & (1 << i);
            const orderOn = order === i;
            return (
              <div
                key={i}
                className="absolute rounded-full"
                style={{
                  left: `${p.x}%`, top: `${p.y}%`, width: 34, height: 34, transform: "translate(-50%,-50%)",
                  background: on ? "#4ade80" : orderOn ? "#ffffff" : color,
                  boxShadow: orderOn ? `0 0 18px ${color}` : on ? "0 0 12px #4ade80" : `0 0 8px ${color}66`,
                  opacity: orderOn || on ? 1 : 0.7,
                }}
              />
            );
          })}
        </div>
      )}

      {/* ---------- CHARGE: vòng phồng + vòng đích ---------- */}
      {spec.kind === "charge" && (
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center w-44 h-44">
          {/* vòng đích */}
          <div className="absolute rounded-full border-2" style={{ width: targetR * 2, height: targetR * 2, borderColor: "#ffffff66", boxShadow: "0 0 10px #ffffff22" }} />
          {/* vòng phồng */}
          <motion.div className="absolute rounded-full" style={{ width: Math.max(4, r * 2), height: Math.max(4, r * 2), background: color, opacity: 0.55, boxShadow: `0 0 20px ${color}88` }} />
        </div>
      )}

      {/* Kết quả QTE: vòng loe + phản hồi rõ, ngưng lại ~0.6s rồi mới tung đòn */}
      {burst && (
        <>
          <motion.div
            initial={{ scale: 0.2, opacity: 0.95 }}
            animate={{ scale: 2.4, opacity: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 rounded-full border-4 pointer-events-none"
            style={{ borderColor: burst === "good" ? "#4ade80" : burst === "bad" ? "#f87171" : "#94a3b8", boxShadow: `0 0 40px ${burst === "good" ? "#4ade8066" : burst === "bad" ? "#f8717166" : "#94a3b866"}` }}
          />
          {spec.mode === "block" ? (
            <motion.span
              initial={{ scale: 0.6, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.15 }}
              className="absolute left-1/2 top-[58%] -translate-x-1/2 text-3xl md:text-4xl font-black tracking-wider pointer-events-none"
              style={{ color: burst === "good" ? "#4ade80" : "#f87171", textShadow: `0 0 20px ${burst === "good" ? "#4ade80" : "#f87171"}` }}
            >
              {burst === "good" ? "CHẶN!" : "TRỆT!"}
            </motion.span>
          ) : (
            <motion.span
              initial={{ scale: 0.6, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.15 }}
              className="absolute left-1/2 top-[58%] -translate-x-1/2 text-2xl md:text-3xl font-black tracking-wider pointer-events-none"
              style={{ color: burst === "good" ? "#4ade80" : burst === "bad" ? "#f87171" : "#94a3b8", textShadow: `0 0 18px ${burst === "good" ? "#4ade80" : burst === "bad" ? "#f87171" : "#94a3b8"}` }}
            >
              {burst === "good" ? "HOÀN HẢO" : burst === "bad" ? "TRỆT" : "ĐƯỢC"}
            </motion.span>
          )}
        </>
      )}
    </div>
  );
}
