"use client";

import type { CSSProperties, ReactNode } from "react";
import clsx from "clsx";
import {
  Anchor, Axe, Award, Backpack, Biohazard, Bird, Bomb, Bug, Castle, Cat, Check, ChevronDown,
  ChevronRight, ChevronsUp, CloudLightning, Coins, Cross, Crosshair, Crown, Dices, Droplets,
  FastForward, Feather, Flag, Flame, Flower, Gem, Ghost, Hammer, Heart, HeartPulse, House,
  Info, Leaf, Lock, Megaphone, Moon, MoonStar, Mountain, Music, Play, Plus, RotateCcw,
  Shield, ShieldHalf, Shirt, Skull, Snowflake, Sparkles, Sprout, Star, Sun, Sunrise, Sword,
  Swords, Syringe, Target, Tornado, TreePine, Users, Volume2, VolumeX, Wand, Wand2, Wind, X, Zap,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import type { ClassId, EffectType, Element, Rarity } from "@/game/types";
import { CLASS_LABEL, ELEMENT_COLORS, ELEMENT_LABEL, RARITY_COLORS } from "@/game/types";

export const ICONS: Record<string, LucideIcon> = {
  anchor: Anchor, axe: Axe, award: Award, backpack: Backpack, biohazard: Biohazard, bird: Bird,
  bomb: Bomb, bug: Bug, castle: Castle, cat: Cat, check: Check, "chevron-down": ChevronDown,
  "chevron-right": ChevronRight, "chevrons-up": ChevronsUp, "cloud-lightning": CloudLightning,
  coins: Coins, cross: Cross, crosshair: Crosshair, crown: Crown, dices: Dices, droplets: Droplets,
  "fast-forward": FastForward, feather: Feather, flag: Flag, flame: Flame, flower: Flower,
  gem: Gem, ghost: Ghost, hammer: Hammer, heart: Heart, "heart-pulse": HeartPulse, house: House,
  info: Info, leaf: Leaf, lock: Lock, megaphone: Megaphone, moon: Moon, "moon-star": MoonStar,
  mountain: Mountain, music: Music, mushroom: Sprout, play: Play, plus: Plus,
  "rotate-ccw": RotateCcw, shield: Shield, "shield-half": ShieldHalf, shirt: Shirt, skull: Skull,
  snowflake: Snowflake, sparkles: Sparkles, sprout: Sprout, star: Star, sun: Sun, sunrise: Sunrise,
  sword: Sword, swords: Swords, syringe: Syringe, target: Target, tornado: Tornado,
  "tree-pine": TreePine, users: Users, "volume-2": Volume2, "volume-x": VolumeX, wand: Wand,
  "wand-2": Wand2, wind: Wind, x: X, zap: Zap,
};

export function Icn({ name, className, style }: { name: string; className?: string; style?: CSSProperties }) {
  const Cmp = ICONS[name] ?? Sparkles;
  return <Cmp className={className} style={style} />;
}

// ------------------------------ effect meta --------------------------------
export const EFFECT_META: Record<EffectType, { icon: string; color: string }> = {
  burn: { icon: "flame", color: "#fb923c" },
  poison: { icon: "biohazard", color: "#4ade80" },
  freeze: { icon: "snowflake", color: "#7dd3fc" },
  shock: { icon: "zap", color: "#fde047" },
  regen: { icon: "sprout", color: "#86efac" },
  atkUp: { icon: "chevrons-up", color: "#fca5a5" },
  defUp: { icon: "shield", color: "#93c5fd" },
  atkDown: { icon: "feather", color: "#d8b4fe" },
  defDown: { icon: "shield-half", color: "#d8b4fe" },
  shield: { icon: "shield-half", color: "#7dd3fc" },
  taunt: { icon: "flag", color: "#f87171" },
  manaRegenUp: { icon: "droplets", color: "#67e8f9" },
  maxManaUp: { icon: "gem", color: "#67e8f9" },
};

// ------------------------------ rarity / class ------------------------------
export const RARITY_GRADIENT: Record<Rarity, string> = {
  R: "from-sky-500/30 to-sky-900/10",
  SR: "from-fuchsia-500/30 to-purple-900/10",
  SSR: "from-amber-400/40 to-yellow-900/10",
};

export const CLASS_META: Record<ClassId, { icon: string; color: string; label: string }> = {
  tank: { icon: "shield", color: "#60a5fa", label: CLASS_LABEL.tank },
  attacker: { icon: "sword", color: "#f87171", label: CLASS_LABEL.attacker },
  support: { icon: "sparkles", color: "#4ade80", label: CLASS_LABEL.support },
};

export function Stars({ rarity, className }: { rarity: Rarity; className?: string }) {
  const n = rarity === "SSR" ? 3 : rarity === "SR" ? 2 : 1;
  return (
    <div className={clsx("flex gap-0.5", className)}>
      {Array.from({ length: n }).map((_, i) => (
        <Star key={i} className="w-2.5 h-2.5" fill={RARITY_COLORS[rarity]} color={RARITY_COLORS[rarity]} />
      ))}
    </div>
  );
}

// ------------------------------- portrait ----------------------------------
/**
 * Khung ảnh đại diện:
 * - Có `artPath` (ảnh thật/placeholder) → render <img> phủ kín khung.
 * - Không có → fallback icon lucide màu theo hệ (không bao giờ vỡ layout).
 * Kích thước cố định theo `size` để sau này thay sprite 2D không ảnh hưởng layout.
 */
export function Portrait(props: {
  icon: string;
  element: Element;
  rarity?: Rarity;
  size?: number;
  dead?: boolean;
  className?: string;
  artPath?: string;
}) {
  const { icon, element, rarity, size = 56, dead, className, artPath } = props;
  const [c1, c2] = ELEMENT_COLORS[element];
  return (
    <div
      className={clsx(
        "relative rounded-xl overflow-hidden flex items-center justify-center shrink-0 select-none",
        dead && "grayscale opacity-40",
        className,
      )}
      style={{
        width: size,
        height: size,
        background: artPath
          ? "#0b0e1a"
          : `linear-gradient(140deg, ${c1}, #0b0e1a 70%)`,
        border: `2px solid ${rarity ? RARITY_COLORS[rarity] : c2}`,
        boxShadow: rarity ? `0 0 12px ${RARITY_COLORS[rarity]}44, inset 0 0 18px ${c2}33` : `inset 0 0 18px ${c2}33`,
      }}
    >
      {artPath ? (
        <img
          src={artPath}
          alt=""
          draggable={false}
          className="absolute inset-0 w-full h-full object-cover"
          style={{ filter: dead ? "grayscale(1)" : undefined }}
        />
      ) : (
        <Icn name={icon} style={{ color: c2, width: size * 0.5, height: size * 0.5, filter: `drop-shadow(0 0 6px ${c2})` }} />
      )}
      <div
        className="absolute bottom-0 right-0 w-1/3 h-1/3 rounded-tl-lg flex items-center justify-center"
        style={{ background: `${c2}26`, backdropFilter: "blur(2px)" }}
      >
        <ElementDot element={element} size={size * 0.18} />
      </div>
    </div>
  );
}

export function ElementDot({ element, size = 10 }: { element: Element; size?: number }) {
  return (
    <span
      className="rounded-full inline-block"
      style={{
        width: size,
        height: size,
        background: ELEMENT_COLORS[element][1],
        boxShadow: `0 0 6px ${ELEMENT_COLORS[element][1]}`,
      }}
      title={ELEMENT_LABEL[element]}
    />
  );
}

// --------------------------------- bars ------------------------------------
export function Bar({ value, max, color, bg = "rgba(255,255,255,0.08)", height = 6, className }: {
  value: number; max: number; color: string; bg?: string; height?: number; className?: string;
}) {
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0;
  return (
    <div className={clsx("rounded-full overflow-hidden", className)} style={{ background: bg, height }}>
      <div
        className="h-full rounded-full transition-all duration-500"
        style={{ width: `${pct}%`, background: color, boxShadow: `0 0 8px ${color}` }}
      />
    </div>
  );
}

export const HP_COLOR = "linear-gradient(90deg,#22c55e,#4ade80)";
export const HP_LOW = "linear-gradient(90deg,#ef4444,#f87171)";
export const MANA_COLOR = "linear-gradient(90deg,#0284c7,#38bdf8)";
export const EXP_COLOR = "linear-gradient(90deg,#f59e0b,#fbbf24)";

// --------------------------------- ui bits ---------------------------------
export function Btn({ children, onClick, disabled, variant = "primary", className, title }: {
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  variant?: "primary" | "ghost" | "gold" | "danger";
  className?: string;
  title?: string;
}) {
  return (
    <button
      title={title}
      disabled={disabled}
      onClick={onClick}
      className={clsx(
        "inline-flex items-center justify-center gap-1.5 rounded-xl font-semibold transition-all active:scale-95 select-none",
        "px-4 py-2 text-sm",
        variant === "primary" && "bg-indigo-500/90 hover:bg-indigo-400 text-white shadow-lg shadow-indigo-500/25",
        variant === "gold" && "bg-gradient-to-b from-amber-300 to-amber-500 text-amber-950 shadow-lg shadow-amber-500/30 hover:brightness-110",
        variant === "ghost" && "bg-white/5 hover:bg-white/10 text-slate-200 border border-white/10",
        variant === "danger" && "bg-rose-500/90 hover:bg-rose-400 text-white",
        disabled && "opacity-40 pointer-events-none",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Modal({ children, onClose, wide }: { children: ReactNode; onClose: () => void; wide?: boolean }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/70 backdrop-blur-sm" onClick={onClose}>
      <div
        className={clsx(
          "relative w-full rounded-2xl border border-white/10 bg-[#12152a] shadow-2xl max-h-[92vh] overflow-hidden flex flex-col",
          wide ? "max-w-4xl" : "max-w-lg",
        )}
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-3 right-3 z-10 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center"
        >
          <X className="w-4 h-4" />
        </button>
        {children}
      </div>
    </div>
  );
}

export function Chip({ children, color = "#94a3b8", className }: { children: ReactNode; color?: string; className?: string }) {
  return (
    <span
      className={clsx("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider", className)}
      style={{ background: `${color}1f`, color, border: `1px solid ${color}44` }}
    >
      {children}
    </span>
  );
}

export function SectionTitle({ children, right }: { children: ReactNode; right?: ReactNode }) {
  return (
    <div className="flex items-center justify-between mb-3">
      <h3 className="text-xs font-bold uppercase tracking-[0.2em] text-slate-400">{children}</h3>
      {right}
    </div>
  );
}
