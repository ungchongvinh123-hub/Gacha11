import { pgTable, serial, text, integer, jsonb, timestamp } from "drizzle-orm/pg-core";

export const players = pgTable("players", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().default("Triệu Hồi Sư"),
  gold: integer("gold").notNull().default(0),
  gems: integer("gems").notNull().default(0),
  team: jsonb("team").$type<number[]>().notNull().default([]),
  cleared: jsonb("cleared").$type<string[]>().notNull().default([]),
  createdAt: timestamp("created_at").defaultNow(),
});

export const characters = pgTable("characters", {
  id: serial("id").primaryKey(),
  playerId: integer("player_id").notNull(),
  defId: text("def_id").notNull(),
  level: integer("level").notNull().default(1),
  exp: integer("exp").notNull().default(0),
  spentPoints: integer("spent_points").notNull().default(0),
  skillLevels: jsonb("skill_levels").$type<Record<string, number>>().notNull().default({}),
  loadout: jsonb("loadout").$type<string[]>().notNull().default([]),
});

export const items = pgTable("items", {
  id: serial("id").primaryKey(),
  playerId: integer("player_id").notNull(),
  defId: text("def_id").notNull(),
  equippedBy: integer("equipped_by"),
  level: integer("level").notNull().default(0), // Cấp cường hóa (+1, +2, +3...)
});
