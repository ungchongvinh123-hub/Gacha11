import type { CapacitorConfig } from "@capacitor/cli";

/**
 * Cấu hình đóng gói Android (màn hình NGANG) cho game.
 *
 * LƯU Ý QUAN TRỌNG — game dùng server + database (tiến trình, tướng, đồ
 * không lưu local để chống hack). Khi đóng gói APK có 2 chế độ:
 *
 * 1) APK tải game từ backend đã deploy (khuyên dùng khi test):
 *    - Bỏ comment `url` bên dưới và điền địa chỉ backend thật
 *      (VD: https://ten-mien-cua-ban.com). App chỉ là lớp webview.
 *    - LƯU Ý: link preview e2b chỉ sống trong 1 lượt chat — KHÔNG dùng làm backend cho APK.
 *
 * 2) APK chạy file tĩnh local (offline demo UI thuần):
 *    - Để nguyên (không url) + build bằng bản export tĩnh. API/DB sẽ không hoạt động —
 *      chỉ xem được giao diện. Muốn chơi thật phải dùng chế độ 1.
 */
const config: CapacitorConfig = {
  appId: "com.thieuhuoikynnguyen.game",
  appName: "Triệu Hồi Kỷ Nguyên",
  webDir: "out",
  // ----- MÀN HÌNH NGANG: đã ép trong AndroidManifest.xml (screenOrientation) -----
  android: {
    allowMixedContent: true,
  },
  // server: {
  //   url: "https://BACKEND_CUA_BAN.example.com",
  //   cleartext: true,
  // },
};

export default config;
